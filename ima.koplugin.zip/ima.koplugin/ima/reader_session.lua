--[[--
IMA 阅读会话：知识库列表 → KOReader 原生阅读器 → 回到知识库列表。

链路本身很短，但有三处必须显式处理，否则在「觅阅桌面」这套环境下会退化成
一堆说不清的现象。以下三点均为 2026-10-07 在 Libra 2 + 实测日志上定位：

1) 文档版面（→ 曾出现「点屏幕翻页信息不完整 / 整页被压得看不清 / 正文太小 /
   「重排」后满屏空格」）
   先纠正一个早期误判：知识库里的研报**不是**"公众号长图截图"，而是
   **Chrome/Edge 网页打印**出来的 PDF —— 实测 Producer = "Skia/PDF m154"、
   Creator = "Mozilla/5.0 (Windows NT 10.0)"，内容流里字体对象 6 个
   （Type0/CJK）、BT/Tj 文本操作符上百个、位图图像对象 0 个，也就是
   **纯文字 + 矢量图表**；每份都是单页超长（598×2838~5548pt）。
   正文实测 18pt、页面宽 598pt，按内容宽铺满后落到 1264px 屏上只有 9.1pt
   （约 3.2mm）高 —— 能看，但吃力。

   v0.6.2 / v0.6.3 试过用 KOReader 的「重排」（kopt_text_wrap = 1）把正文放大，
   上机实测是灾难，**本版彻底放弃**。两条原因都是 PDF 引擎层的硬约束，
   不是参数没调好，记在这里免得下次又试一遍：
     · 慢：重排要处理整页（单页 5548pt 高 + 大量矢量图），实测打开一份要
       56 秒（crash.log：16:05:23 开始，16:06:18 才 `Restoring user input`）。
     · **满屏空格**：KOReader 把文档语言（kopt_doc_language）默认成 "eng"，
       而 KoptInterface:createContext 只在语言是 chi_sim / chi_tra / jpn / kor
       时才调 `kc:setCJKChar()`。于是 k2pdfopt 拿中文当拉丁文排版，按"词"
       断行，再叠加默认的 justification = 3（full，两端对齐）—— 中文就被
       拆成一格一格的空隙。
   结论（也是本项目的硬约束）：**不替用户决定版面**。
   默认档「跟随系统默认」= 一个 zoom 键都不写，文档打开的样子跟平时在
   KOReader / 觅阅里打开一本书完全一致；要更大的字，用阅读器自带的
   「排版」面板调（觅阅那层接管已在本次会话里摘除，该面板打得开）。
   另外还必须**撤销**历史版本写进边车的重排残留，否则老文档会继续按重排
   打开 —— 依旧是慢 + 满屏空格（见 _writeLayout）。

1b) 翻页重叠：归零 → 恰好一行 → **按行网格对齐**（v0.6.2 / v0.6.17 / v0.6.19）
   重叠量来源有两个：
     · 连续视图（kopt_page_scroll=1，本机默认）→ ReaderPaging.overlap，
       init 时被赋为 Screen:scaleBySize(DOVERLAPPIXELS)（默认 30，换算后 64）。
       ⚠️ 它的单位是**页面坐标 pt**，不是像素（见 LINE_HEIGHT_PT 的注释）。
     · 整页视图（kopt_page_scroll=0）→ 1 − zoom_overlap_v/100，边车里是 36%。
   前者只能运行时改实例字段（不是文档设置项，见 enforceContinuousPaging）；
   后者顺手写进文档设置（见 _writeLayout）。
   · v0.6.2 ~ v0.6.16：两者都**归零** —— 治好了「翻页与上一页重复」，却换来
     新毛病：重叠为 0 时翻页步长正好等于屏高，任何**跨越屏底边的那一行**被切成
     两半（上半截留在上一屏、下半截掉到下一屏）。用户报的「页面最下方的字不完整、
     字的一部分显示在下一页」就是它。又因为行距与屏高不整除，切口**逐屏漂移**，
     于是表现成"有时"才出现（正好切在行间隙的那几屏看不出来）。
   · v0.6.17 ~ v0.6.18：改成**恰好一行高**（22pt × zoom = 竖屏 47px）。
     方向对，**上机没效果**，因为想法本身不成立 —— 本库 PDF 的行距**不统一**
     （实测同时存在 21.75 / 21.0 / 34.5 / 35.25 / 53.46pt 五种：段内 21.75，
     标题前后 34.5 / 53.46…），固定量只可能对齐其中一种。
     离线模拟（outputs/_tools/overlap_sim.py，16 份文档 72~80 屏）证明：
     固定重叠取 0 ~ 71pt 里的**任何**值，新屏顶部切字率都稳定在 59%~73% ——
     用户说的"有时"就是这么来的（正好切在行间隙的那几屏看不出来）。
   · v0.6.19 起：**不要猜行距，直接问文档每一行在哪**。
     PdfDocument:getPageTextBoxes(page) 走 MuPDF 的 stext 设备（不经 k2pdfopt
     重排引擎，所以不会踩"重排 = 卡死"的雷，且有 DocCache 缓存），返回每行的
     y0/y1（页面坐标，与 view.visible_area 同坐标系）。翻页前据此把 overlap
     设成"让下一屏底部正好落在某个行顶"的值 ⇒ **屏底那一行永远完整**，
     且取区间内最大的行顶 ⇒ 重复量最小。细节与代价见 1c 节。
   ⚠️ 不要再退回 0（必然切字），也不要还给 KOReader 的 64pt：它一样会切字。

2) 觅阅（miuread）的阅读面板接管（→ 「无法更改字体大小」）
   觅阅在桌面模式下会把**任何** ReaderUI 的
     · 顶部中部 tap 区（overrides readermenu_tap / tap_forward / tap_backward）
     · ReaderMenu 的 onTapShowMenu / onSwipeShowMenu / onPressMenu /
       onKeyPressShowMenu 四个入口
   全部改接到自己的快捷面板；于是 KOReader 原生的字体/排版菜单（也就是
   「更改字体大小」）从任何一个入口都打不开，下拉也只会看到觅阅的面板。
   IMA 文档要的是**原生阅读器**，所以本次会话临时摘掉这层接管。
   只改内存里的引用，不碰觅阅的设置文件，也不改它的偏好；阅读器关闭后
   觅阅那份插件实例会被 PluginLoader:finalize() 回收，下一次阅读自然恢复。

3) 退出只能回觅阅首页（→ 「无法单独退出返回知识库列表」）
   觅阅还会把 readerui.onHome / showFileManager 接到自己的首页（它的日志里叫
   「native bookshelf redirected before FileManager」）。上面第 2 步把这两个
   还原成 KOReader 原生的，退出即回到正常的关闭流程；随后 reclaim 再把
   知识库列表抬回窗口栈顶层（不重新请求接口）。

4) 退回觅阅首页后「点不动」（→ 「从 ima 返回觅阅首页后页面卡死，任何点击都没反应」）
   打开任何阅读器时，觅阅都会 `HomeView.park()` 把首页「停放」在阅读器下面，
   其中一行是 `_miu_input_suspended = true`（home_view.lua:2095）；而
   `HomeWidget:handleEvent` 的第一行就是
   `if self._miu_input_suspended == true then return true end`
   （home_view.lua:836）—— **把一切输入原样吞掉**。
   解除它的只有 `HomeView.unpark()`，觅阅**只在自己那两条「恢复首页」的路径里**
   调用（`_complete_reader_close` main.lua:17108、`_restore_home_after_reader_close`
   main.lua:17685）。而上面第 3 步为了「能单独退出」，把觅阅的返回流程整条绕过了
   —— 日志里能直接对照：正常从觅阅开书退出会有
   `[ReaderClose] state home_surface_ready restoring parked MiuRead home`，
   IMA 这条路没有，取而代之的是 `home -> native reason= foreground native`。
   于是两次 unpark 都不会发生，首页带着"吞输入"标志留在窗口栈里；
   等它被抬到顶层（觅阅自己的手势桥 stabilize 就会 raise 它）就成了一个
   看得见、点不动的首页 —— 这正是用户看到的「卡死」。
   修法见 Session.unparkMiureadHome：退出后（阅读器确实已关闭时）用觅阅自己的
   公开 API 补一次解冻。幂等、不动窗口顺序、不写觅阅任何设置文件。
   （注：`_desktop_frozen` 那个标志只挡后台任务、不挡输入，且会被
   `_show_miuread_home_now` 自己 thaw，所以不是本次的原因。）

5) 阅读界面「顶部下滑」弹出的是 KOReader 菜单（→ 「从上往下滑显示的是 koreader
   的设置界面，我要改成返回上一层」）
   KOReader 的阅读器把屏幕**顶部 12.5% 条带**的下滑固定绑成了「打开菜单」：
   defaults.lua:59 `DTAP_ZONE_MENU = {x = 0, y = 0, w = 1, h = 1/8}`，
   readermenu.lua:98-174 用 `registerTouchZones` 把
   `readermenu_swipe` / `readermenu_ext_swipe`（以及同区的两个 pan）接到
   `ReaderMenu:onSwipeShowMenu`（readermenu.lua:478），后者只判断
   `ges.direction == "south"` 就 `onShowMenu()`。
   而**知识库列表里的"下滑"是返回上一层**（KOReader 自带的 `Menu:onSwipe`：
   `south → self:onClose()`，ui/widget/menu.lua:1492-1497）—— 同一个手势在
   两个界面里的含义正好相反，这就是用户看到的不一致。
   处理方式：把 ReaderMenu **实例**上的 `onSwipeShowMenu` 包一层，direction 是
   south 且本次阅读由 IMA 发起时改走 `Session.returnNow()`（与阅读器菜单里的
   「← 返回 IMA 知识库」完全同一条退出路径，所以落盘、抬回列表都不用另写）；
   其余方向原样交回 KOReader。**顶部"点按"不动**（`readermenu_tap` →
   `onTapShowMenu`），所以阅读器菜单依然打得开，只是不再抢"下滑"。
   为什么包实例方法、而不是重新 `registerTouchZones` 覆盖那几个 zone：
   原 zone 的 handler 是闭包，里面写的是 `self:onSwipeShowMenu(ges)` ——
   方法名在**调用时**才解析，所以实例上的赋值能活过
   `ReaderMenu:onSetDimensions`（旋屏、ReaderReady 都会把 zone 再注册一遍）；
   反之若自己去注册同名 zone，下一次 `initGesListener` 就把我们覆盖掉了。
   开关见 `pdf_swipe_back`（默认开），关掉即恢复原生行为。

6) 退出阅读器的一瞬间会「闪现 KOReader 文件列表」，之后列表再下滑也退到那里
   （→ 「下滑会闪现一下 koreader 的设置界面然后出现知识库列表，然后再点文档
   再下滑会返回到 koreader 的 ima 的缓存列表」）
   根因是**退出走了 `ReaderUI:onHome()`**（readerui.lua:929）：
     function ReaderUI:onHome()
         local file = self.document.file
         self:onClose()
         self:showFileManager(file)   -- ← 问题在这一行
         return true
     end
   而 `showFileManager(file)` 会 `file_chooser:changeToPath(文档所在目录)`；
   本插件的文档都下载在 `cache/ima/` 下 —— 于是 KOReader 会**新建一个
   FileManager 窗口、并把它的目录切到 cache/ima**（日志里能直接看到证据：
   退出那一刻 `[MiuRead][Startup] begin`、`[Customisable Sleep Screen]
   initialised` 整串重跑，说明 FileManager 与各插件的 init 被重新执行了一遍）。
   更要紧的是 `UIManager:show` 的插入规则是「插在**最上面那个非模态窗口**之上」
   （uimanager.lua:185-198），新建的 FileManager 于是被 push 到**知识库列表
   上面**：
     · 读者先看到一眼 KOReader 的文件列表，要等 1.8s 后 reclaim 才把它盖住
       —— 这就是"闪现"；
     · 那个 FileManager 会一直留在窗口栈里。于是"在知识库列表上再下滑"
       （KOReader 自带的 `Menu:onSwipe` → `onClose()`）露出来的就是
       cache/ima 的文件列表，而不是压在下面本该露出的觅阅首页。
   修法：退出只调 `ReaderUI:onClose()`，**不调 showFileManager**。onClose 里
   落盘、阅读进度、`CloseDocument` 事件、`saveSettings` 全都在，与 onHome 的
   前半段完全一致，差别只有"要不要顺手把 FileManager 拉出来"。不拉的时候，
   阅读器关掉后露出的就是**本来就压在下面的那个窗口** = 知识库列表本身：
   没有闪现，也不会凭空多出一个文件管理器。见 Session.closeReader。
   另外把 `readerui.onHome` 也改道到同一条路上（Session.installExitRouting）：
   KOReader 里其它"回家"入口（`ReaderBack` 在文档开头再返回一次会发
   `Event:new("Home")`，readerback.lua:173）也不会再拉出 FileManager。
   只在本次阅读由 IMA 发起时改道，普通书籍原样。

6b) 但**"不拉 FileManager"本身还不够** —— 觅阅会替我们拉，而且拉得更晚
   （v0.6.9 实测："打开文档下滑**直接**回到 cache/ima 的文件列表"）
   觅阅把 KOReader 的文件管理器当自己桌面模式的"底座"：阅读器一关，它就调
   `Plugin:_ensure_filemanager_base`（miuread main.lua:17572）把底座补回来，
   而那个函数在 `FileManager.instance` 不存在时走的是**创建分支**：
     local target = HOME_RETURN_FILE            -- 刚读过的那本书
     local dir    = target:match("^(.*)/[^/]+$")
     FileManager:showFiles(dir, target)         -- → UIManager:show(file_manager)
   `HOME_RETURN_FILE` 正是本插件下载的文档，于是 `dir` = `cache/ima`，
   而 `FileManager:showFiles` 结尾是 `UIManager:show(file_manager)`
   （frontend/apps/filemanager/filemanager.lua:1311-1330）—— 按 UIManager
   的插入规则，它被 push 到**知识库列表上面**。这就是"直接看到 cache/ima
   文件列表"。
   （v0.6.8 之所以看起来正常，是因为那版退出时走 onHome，KOReader 抢先建过
   FileManager；觅阅随后走的是 `conceal_under_home` 分支，只把**它自己的
   首页** raise 上来，不 show 文件管理器 —— 我们的 reclaim 再把列表盖上去
   就赢了。v0.6.9 不建 FileManager，觅阅于是走了创建分支。）
   所以 reclaim 必须做两件事，缺一不可：
     · 顶层是 KOReader 文件管理器（`FileManager.instance`）→ **直接收掉**，
       它不属于 IMA 的任何界面；
     · 顶层是觅阅恢复流程里的过渡层（`_miuread_transient` 等）→ **照样越过**，
       不能因为"那是觅阅的东西"就永远不抬 —— 它的出现时机恰好就是我们要
       把列表抬回顶层的时机。只有真正的模态对话框（`modal`）才让位。
   另外让 `scheduleReclaim` 带上令牌：`onCloseWidget` 与 `closeReader` 都会
   排定时器，两组交错会把 step 往前跳、吃掉 3.2s 那一拍并让校正窗口提前收口。

6c) 「用户关闭了列表」这个判定连续错过两次（v0.6.11 / v0.6.12），两次的
   现象都是：退出后先弹回 IMA 用户界面、再自动跳到 cache/ima 缓存列表，
   知识库文件列表始终不出现。
   v0.6.11 引入 close_callback → noteMenuClosed，前提是「close_callback
   走到 = 用户主动关」。这个前提是错的：**Menu:onMenuSelect（menu.lua:
   1374-1377）选中普通条目后也会调 close_callback** —— 先跑条目自己的
   callback（= 打开文档），后调 close_callback，而菜单**并没有关**、
   还留在窗口栈里。于是「从列表点开文档」被记成「用户主动关闭列表」，
   user_closed 置位并毒死整场阅读的抬回守护：退出后 reclaim 一行日志都
   没有（第一行就静默早退），列表虽然会自然露出来（菜单本来就压在阅读器
   下面），但随后被觅阅恢复的 cache/ima 文件管理器整个盖住。
   v0.6.12 的 nextTick 修的是另一个当时以为存在、实际不成立的问题
   （「手势泄漏」：UIManager:sendEvent 在派发前就锁定了 top_widget，
   阅读器在 handleEvent 返回 true 之前/之后离开窗口栈，事件都不会落到
   列表头上）。nextTick 本身无害且更稳 —— 避免在手势派发中途动窗口栈，
   sendEvent 那套 checked_widgets 哈希虽然兼容栈变动，何必去赌 —— 保留。
   真正的修复是三道（v0.6.13）：
     ① ima/ui/menu.lua：close_callback 里只有「菜单已不在窗口栈」才通知
       noteMenuClosed（onCloseAllMenus 先 UIManager:close 后回调；
       onMenuSelect 那次菜单还在栈里，天然可区分）；
     ② prepare() 复位 user_closed —— 只要是 IMA 发起的阅读，结束就必须
       抬回列表，双保险；
     ③ reclaim 的「收掉外来 FileManager」不再受 user_closed 门控，且
       noteMenuClosed 不再作废守护定时器 —— 用户下滑关掉列表后，露出的
       下一层不能被觅阅补回的 cache/ima 文件管理器盖死。
   （菜单按钮「← 返回 IMA 知识库」走的是 tap + `Menu:onMenuChoice`，
   本身就消费掉手势并关闭菜单，不需要延后，保持同步即可。）

6d) 最后一个「跳」：退出后约 1 秒飘来的**第二个 south swipe**（v0.6.13 证清）。
   ⚠️⚠️ **v0.6.16 更正：这一节的结论是错的，整段保留只为留证，别照着改代码。**
   手势探针（v0.6.14 就在跑）的真实数据显示：那些"第二个 swipe"**不是**同一次物理
   滑动被重复派发，而是**用户自己的下一划**。判别依据只在 `Contact:handleSwipe`
   （gesturedetector.lua:891）里 —— 它给 swipe 的 `pos` 用的是**起点**而不是抬手点
   （927-933 行有注释明说），于是两种手势的物理形态完全不同：
     · 退出阅读器那一划（「顶部下滑：返回知识库列表」那行记的）：pos.y ≈ 103~124、dist 72~95
     · 被"免打扰窗"吞掉的那些：pos.y ≈ 24~37（**屏幕最上沿**）、dist 260~484
   距离差 4~6 倍、起点差 70pt。一次物理滑动（且 `handleSwipe` 只在抬手时发一次、
   `GestureRange:match` 还要求 `gs.ges` 严格相等）不可能产生形态如此不同的两条事件。
   ⇒ v0.6.14 的"包装被绕过"、v0.6.15 的"三道拦截"都是**基于错误前提**的补救，
   它们真实的副作用是把用户的返回手势一起吞掉 —— 用户的评价是
   "从文档列表返回用户界面的触摸不能过快，过快会失效"。
   ⇒ v0.6.16 的对策：吞划窗口压到 **1.5s 且一击即止**、只挡滑动不挡点按；
   真正要修的是"关掉列表后露出来的是谁"（见 6e 的 v0.6.16 部分）。
   下面是原结论（错的那一版），仅作留证：
   v0.6.12/0.6.13 的关闭探针拿到 12 层调用栈，全貌是：
       handleInput → handleInputEvent → sendEvent
         → 列表 WidgetContainer:handleEvent
           → InputContainer:onGesture（inputcontainer.lua:269 的 ges_events 派发）
             → Menu:onSwipe（menu.lua:1486）
               → self:onClose()（1496 行）→ onCloseAllMenus → UIManager:close
   即：**列表当时就是顶层窗口，收到了一条真正的 `Swipe` 事件**。
   三处 KOReader 源码逐行核对，排除了「同一划被重复派发」：
     · `GestureRange:match`（ui/gesturerange.lua:21-24）要求 `gs.ges` 严格相等
       → 只有真正的 `swipe` 能进 `Menu.ges_events.Swipe`；
     · `UIManager:sendEvent`（uimanager.lua:901-930）只把事件交给**派发那一刻**
       的顶层非 toast 窗口
       → 阅读器那一划不可能"继续往下"落到列表上；
     · `Contact:handleSwipe`（gesturedetector.lua:891，注释 "Contact is up"）
       只在**抬手**时发一次 swipe。
   ⚠️ 另外注意：`Menu:onSwipe` 与 `EventListener:handleEvent` 里的调用都是
   **尾调用**（`return native_swipe(...)` / `return handler(...)`），所以
   `debug.traceback` 里**看不到**我们包装层那一帧 —— 不能据"栈里没有我们的文件"
   就断定包装没生效。v0.6.14 差点在这里判错。

   v0.6.14 的修法（记时钟起点 + `age < 1.6s` 算窗口内）**真机上没生效**：
   四次实测全部走到 `noteMenuClosed` 的「用户关闭了知识库列表」那一支，
   而"免打扰窗内：忽略"那条日志从未出现 —— clock 判定的窗口当时返回了 false。
   原因不明（`Device.total_standby_time`/`total_suspend_time` 确实存在且为数字），
   但既然不可靠，就不要再用时钟。

   v0.6.15 的修法 —— 三道拦截，全部与时间计算无关：
     · `state.handover` 布尔 + `UIManager:scheduleIn` 定时清除（KOReader 自己的
       调度器，不存在"算出来不在窗口内"）；
     · 列表实例 `onSwipe`（ima/ui/menu.lua）吞掉 south（第一道，可能被绕过）；
     · `noteMenuClosed` 直接忽略（不记成用户意图）；
     · **`UIManager:close` 闸口**（installCloseGuard）在免打扰期内**直接不放行**
       —— 唯一覆盖所有关闭路径的一道，前两道失手它也能兜住。
   免打扰期一过全部还原，用户之后主动下滑退出列表的手感分毫不变。
   期内同时开一个**手势探针**（installGestureProbe / GESTURE_PROBE_SECONDS），
   把每一条送到 `UIManager:sendEvent` 的 swipe/multiswipe/two_finger_swipe/
   pan_release/hold* 记一行（类型、方向、距离、落点、当时的顶层控件）。
   平时 `state.probe == false`、零开销；万一还有残留手势，crash.log 里直接能看到
   它是不是同一次物理滑动（对照 `顶部下滑` 那行记下的 dist/pos）。

6e) 「为什么总是闪一下 cache/ima 缓存列表」—— v0.6.15 找到的真因（与 6d) 无关）。
   阅读器一关，觅阅必然跑一遍「恢复原生界面」：
       [MiuRead][Navigation] reader -> native reason= foreground native
       [MiuRead][Startup] begin …（它把 home 插件整个重初始化一遍）
       [MiuRead][Navigation] native -> home reason= home plugin initialized
       [MiuRead][Home] FileManager base ready
       [MiuRead][ReaderClosePerf] FileManager base created show_ms= 169
       [MiuRead][Transition] complete native surface restored
   其中 `Plugin:_ensure_filemanager_base`（miuread main.lua:17573-17614）会
   **无条件 `UIManager:show` KOReader 的文件管理器**，并把目录切到本次文档所在的
   cache/ima。觅阅自己的注释写得很明白（main.lua:16673-16675）：
     *"Never suppress KOReader's native transition. It owns document teardown
       and FileManager creation; MiuRead only observes the stable docless
       surface and raises the parked home afterwards."*
   也就是说这一下**不是我们能拦的**（拦了就破坏 KOReader 自己的拆除流程），
   事后去关它永远慢一拍 —— 这就是"总是闪一下缓存列表"的来源。

   修法 = **把列表钉在窗口栈最上层**（`Menu.modal = true`，见 HANDOVER_PIN_MENU）。
   `UIManager:show`（uimanager.lua:186-199）的插入规则是「插在**最上面那个非
   modal 窗口之上**」，所以只要列表是 modal，觅阅随后 show / raise 的任何非
   modal 窗口（文件管理器底座、它随后 raise 的首页）都会被插到列表**下面** ——
   不是"抢得快"，而是**根本盖不上来**。纯 z-order 保证，与时间、与谁先谁后无关。
   只在免打扰期内钉；打开阅读器之前（`Session.prepare`）必须摘，否则阅读器
   会被列表盖住。

   v0.6.16 的两条修法（钉 modal 只是其中一半，单靠它不够）：
     ① **要钉就钉全部**：`Session.pinMenu` 改成把 `Imenu.menus()` 里**所有**还活着
        的列表一起钉成 modal（只钉最上面那层时，底座会落到那层列表之下、而更下一
        层的列表仍在它下面 —— 于是"关掉文档列表、露出知识库用户界面"这一步会先
        露出 cache/ima，这就是"从文档列表返回用户界面时闪现缓存列表"）。
        `is_foreign_overlay` 同步改成"排除我们**所有**的列表"，否则列表会把自己判成
        该让位的模态对话框 → reclaim 自锁死。
     ② **关列表时同步收掉它**（真正的修复，与①无关也生效）：`UIManager:close` 闸口
        在关掉我们**任一**列表的那一刻，先 `sweep_file_managers()` 把窗口栈里所有
        KOReader 文件管理器收掉，再让它真的关。为什么这样就一定不闪：
          · `UIManager:close`（uimanager.lua:232-280）只改窗口栈 + `setDirty`，
            真正的绘制延后到 `_repaint()`（1237）；
          · `handleInput` 的循环是「先 `_checkTasks()` + `_repaint()`，
            再 `Input:waitEvent`」（1500-1522）。
        两者结合 ⇒ 同一次同步调用里收掉它，它**一帧都不会被画出来**。
        v0.6.15 是等 reclaim 那一拍（约 +1s）才收，那一秒就是用户看到的"闪现"。
     ③ **两个窗口刻意不同长**：钉子 4.0s（`HANDOVER_PIN_SECONDS`）必须活到觅阅
        **+2.3~2.6s** 补出文件管理器底座之后，否则底座会插到所有列表之上把列表盖死；
        而吞划窗口只留 1.5s（`HANDOVER_QUIET_SECONDS`）且一击即止。合成一个窗口
        会让"不吞用户手势"和"底座别盖上来"二选一。

   `modal` 在前端只被 `UIManager:show` 的插栈逻辑读（外加键盘/确认框等本身就是
   modal 的控件；多个 modal 共存是 KOReader 的常规用法），给 `Menu` 加这一字段
   没有别的副作用。

模块级状态说明：KOReader 每打开一次阅读器都会新建一份插件实例，实例字段活不过
这一次打开；而这里的状态要横跨「列表 → 阅读器 → 列表」三段，所以放在模块级
（require 缓存）而不是插件实例上。
--]]--

local logger    = require("logger")
local UIManager = require("ui/uimanager")
local _         = require("gettext")

local Config = require("ima.config")

local Session = {}

--- 阅读器关闭后，把列表抬回顶层的校正时间点（秒）。
---
--- 这些拍点要**盖住觅阅恢复桌面那条流水线**，而它比想象的慢（v0.6.10 真机实测）：
---   +1.5s  我们的列表已经在顶层（closeReader 里那次立刻抬回就够）
---   +2.55s 觅阅才确认"阅读器真的关闭了"（`wait_ms= 2552`）
---   +3.0s  觅阅 `reader -> native` → 重建插件 → `FileManager base created`
---           ← 文件管理器就是在这一刻被 show 到我们列表**上面**的
---   +4.0s  觅阅 `native -> home`，它自己的首页也起来了
--- 所以拍点必须**密**：既要在 2.4s 前确认列表还在，又要在 3.0~4.0s 之间
--- 把文件管理器按住 —— v0.6.10 的 5.0s 那一拍太晚，实测文件管理器在屏幕上
--- 停了将近 3 秒（20:30:04 创建 → 20:30:07 才被我们收掉）。
---
--- 最后一次（8.5s）同时是 Session.unparkMiureadHome 的兜底（见文件头 4）。
local RECLAIM_DELAYS = { 0.8, 1.6, 2.4, 2.9, 3.4, 4.0, 4.8, 5.8, 7.0, 8.5 }

----------------------------------------------------------------
-- 打开文档时的版面
----------------------------------------------------------------
-- 默认是 **不覆盖任何设置**：知识库里的文档就跟平时在 KOReader / 觅阅里
-- 打开一本书完全一样。曾经这里强制写过「整页显示」，结果是灾难 ——
-- 知识库里的 PDF 大多是**单页超长图**（实测 598×5548pt，宽高比 1:9.3），
-- 整页塞进 7 寸屏等于把宽度压到 1/9 屏，字完全看不清。
--
-- 所以：默认跟随系统；只有用户显式选了别的，才动手写。
-- 键名直接沿用 KOReader 的 zoom_mode 取值，方便对照阅读器里的排版菜单。
--
-- v0.6.2 / v0.6.3 曾在这里追加一档 reflow（正文重排，用来把正文放大）。
-- 上机实测两宗罪：打开要 56 秒；且因为 kopt_doc_language 默认 "eng"、
-- k2pdfopt 不按 CJK 断行，中文被排成满屏空格（详见文件头 1)）。
-- **已整档移除**，连同它的四个字号参数 —— 字号这件事交回阅读器自带的
-- 「排版」面板，插件不再插手。
local ZOOM_CYCLE = { "default", "contentwidth", "pagewidth", "page" }
--- 校验用的查找表。刻意写成字面量而不是遍历 ZOOM_CYCLE 生成：
--- 本模块里 `_` 是 gettext 函数，`for _, name in ipairs(...)` 会把它遮蔽成
--- 数字下标，之后任何 `_("...")` 都会抛 "attempt to call upvalue '_'
--- (a number value)" 直接崩掉 KOReader（v0.4.0 的教训，见 README）。
--- 这张表与 ZOOM_CYCLE 必须保持一致。
local ZOOM_IS_VALID = {
    default      = true,
    contentwidth = true,
    pagewidth    = true,
    page         = true,
}
local ZOOM_LABEL = {
    default      = "跟随系统默认（推荐）",
    contentwidth = "适应内容宽度",
    pagewidth    = "适应页宽",
    page         = "整页显示",
}
--- 允许「现场校正」的档位。
--- 「跟随系统默认」不在其中：它一个 zoom 键都没写，现场去设只会把 "default"
--- 这个**非法模式**塞进 ReaderZooming —— `ReaderZooming:onSetZoomMode` 不校验
--- 取值，会把 self.zoom_mode / view.zoom_mode 直接改成 "default"。
local ZOOM_ENFORCEABLE = {
    contentwidth = true,
    pagewidth    = true,
    page         = true,
}
local ZOOM_SETTING = "pdf_open_zoom"

--- 历史版本（v0.6.2 / v0.6.3）写进边车的「正文重排」残留键。
---
--- 光把档位移出不够：这些键会**继续生效**，文档照样按重排打开（慢 + 满屏空格）。
--- 所以每次套用版面时都顺手把它们清掉，等于给老文档做一次一次性回退。
--- 注意用下标循环，别用 `for _, key in ipairs(...)` —— 本模块的 `_` 是 gettext。
local LEGACY_REFLOW_KEYS = {
    "kopt_font_size",
    "kopt_line_spacing",
    "kopt_word_spacing",
    "kopt_page_margin",
}

--- 关掉「翻页内容连续」时要归还的重叠值。
--- 36 是 KOReader 自己给新文档写的默认值（koptoptions 里 Zoom Overlap 的
--- 默认档就是 36%），既不是 0 也不是 ReaderZooming 的类默认 40 —— 归还默认
--- 就归还这个数，免得"关掉开关"反而变成另一种非默认状态。
local OVERLAP_DEFAULT = 36

--- 一行正文的**排印行距**（pt，PDF 页面坐标）。
---
--- 实测：设备上 16 份样本 PDF 的正文相邻行顶差中位数都是 **21.75pt**
--- （浏览器打印的同源 PDF，正文字号 13.5pt）。它有两个用途：
---   · 连续视图拿不到行网格时的**兜底**重叠量（见 Session._alignOverlap）；
---   · 整页视图换算百分比时的分子（见 Session._pinOverlap）。
---
--- ⚠️ 它是**页面坐标 pt**，而连续视图的 ReaderPaging.overlap 是**屏幕像素**：
---    readerview.lua:761 `visible_area:setSizeTo(self.dimen)`（dimen = 屏幕像素），
---    readerpaging.lua:932-946 里两者直接相减。所以给 overlap 赋值前要 × zoom，
---    别把这个 pt 值直接塞进去。
---
--- ⚠️ 但"恰好一行"这个量**治不了**本库的切字问题 —— 行距不统一（实测同时存在
---    21.75 / 21.0 / 34.5 / 35.25 / 53.46pt 五种），固定量只可能对齐其中一种。
---    真正生效的是按行网格现算的动态值（见 1c 节与 Session._alignOverlap），
---    这个常量只是"拿不到行网格"时的兜底。
local LINE_HEIGHT_PT = 21.75

--- 拿不到 ReaderZooming:getZoom 时的兜底缩放（竖屏 contentwidth：1264 ÷ 598）。
local ZOOM_FALLBACK = 2.113

--- 拿不到视口高时，整页视图重叠的兜底百分比。
--- 竖屏一行约 46px ÷ 视口 1680px ≈ 2.7%，取 4% 留余量。
local OVERLAP_PERCENT_FALLBACK = 4

--- 「翻页不切断文字」的开关键。默认开。
--- 关掉它才会退回 KOReader 原生的重叠行为。
--- 键名沿用 v0.6.2 的 pdf_continuous_paging，免得老用户的设置失效。
local CONTINUOUS_SETTING = "pdf_continuous_paging"

--- 「阅读界面顶部下滑 = 返回知识库列表」的开关键。默认开。
---
--- KOReader 原生把顶部条带的下滑绑成「打开菜单」，而知识库列表里下滑是
--- 「返回上一层」—— 同一个手势两处含义相反。开这一项后，本次阅读（由 IMA
--- 发起）里顶部下滑也变成返回列表；关掉即恢复原生行为（见文件头 5)。
--- 顶部**点按**打开菜单不受本开关影响。
local SWIPE_BACK_SETTING = "pdf_swipe_back"

----------------------------------------------------------------
-- 打开文档自动横屏 / 退出恢复
----------------------------------------------------------------
-- 为什么需要它：本库的文档是 598pt 宽的固定版面，竖屏 contentwidth 下缩放只有
--    视口宽px ÷ 页宽pt = 1264 ÷ 598 = 2.113  → 18pt 正文等效 9.13pt
-- 横屏则是 1680 ÷ 598 = 2.809 → 12.14pt，正好 **1.33×**，而且**完全不需要重排**
-- —— 这台设备上「重排 = 崩溃」，所以横屏是放大正文唯一安全的手段。
--
-- 实现走 **KOReader 自己的文档级旋转**，而不是运行时去拧屏幕：
--   · 旋转本来就是文档级的 —— `ReaderView:onReadSettings`(readerview.lua:968-975)
--     按 `kopt_rotation_mode`(边车) > 全局同名键 > 竖屏 取值并应用；
--     `ReaderView:onSaveSettings`(1219-1222) 退出时又把当前旋转写回边车。
--   · 所以我们只要在**打开之前**把边车写成横屏（prepare → seedDocumentDefaults，
--     这条路在 showReader 之前跑），KOReader 自己就横屏打开了。
--   · 它是文档级设置 ⇒ **只影响 IMA 打开的这一份文档**，别的书一点不受影响。
--
-- 退出恢复为什么要自己动手：`FileManager:showFiles`(filemanager.lua:1311) 里
-- 确实有一句 `self:setRotationMode()`（把屏幕恢复到 `fm_rotation_mode`，默认竖屏），
-- 但**它只在新建 FileManager 实例时才跑** —— 而 IMA 的退出路径刻意**不新建**
-- FileManager（只调 ReaderUI:onClose，见 closeReader）。那条原生恢复不会执行，
-- 于是必须在 Session.restoreRotation 里补一次，且**必须在 onClose 返回之后**
-- （时序原因见那个函数的注释）。
--
-- ⚠️ 三个"锁"要分清（`screen_rotation_menu_table.lua`）：
--     · `input_ignore_gsensor`  忽略加速度计事件 ── 只挡**传感器**
--     · `input_lock_gsensor`    把自动旋转锁在当前朝向 ── 只挡**传感器**
--     · `lock_rotation`         「跨视图保持当前旋转」── 这个**会**让 readerview
--                               整个跳过读/写 `kopt_rotation_mode`（968 / 1220 行）
--   前两个不影响本功能（"读别的书时锁了竖屏"正是这一种）；第三个开着时文档级
--   设置会被无视，此时靠 Session.enforceSeededRotation 在打开后现场补一次。
--
-- 「打开文档自动横屏（退出恢复）」的开关键。
--
-- ⚠️ v0.6.19 起**默认开**。v0.6.18 时默认关，理由是"别悄悄改变阅读姿态" ——
-- 但实测反馈证明这个保守选择只是让功能"看起来没做"：用户要求的就是打开 IMA
-- 文档即横屏，而默认关 ⇒ 他没去翻设置项 ⇒ 打开文档当然不转 ⇒ 判定为"没生效"。
-- 横屏在本库是刚需（竖屏 contentwidth 只等效 9.13pt 正文，横屏 12.14pt），
-- 且它是**文档级**设置、退出就恢复，不会影响别的书 —— 默认开才是对的选择。
local ROTATION_SETTING = "pdf_auto_landscape"

--- 横屏取值。KOReader 用 LinuxFB 常量：**偶数=竖、奇数=横**
--- （readerview.lua:907 的注释原文 "Portraits are even, Landscapes are odds"）。
--- `optionsutil.rotation_modes` = { CCW 3, UPRIGHT 0, **CW 1**, UPSIDE_DOWN 2 }，
--- 取 1 = DEVICE_ROTATED_CLOCKWISE（顺时针 90°，设备向右转）。
local ROTATION_LANDSCAPE = 1

--- 竖屏取值（DEVICE_ROTATED_UPRIGHT = 0）。关掉开关时用它把边车归还成竖屏。
local ROTATION_UPRIGHT = 0

--- 顶部下滑退出阅读器之后的「退出余波免打扰」（秒）。
---
--- 真机实测（v0.6.11 ~ v0.6.14 连查四轮）：一次「文档下滑 = 返回列表」会在阅读器
--- 关掉之后 ~1s 再给列表送来**第二个 south swipe**；列表的 `Menu:onSwipe`
--- （menu.lua:1486，south → `self:onClose()` 在 1496 行）把它当「返回上一层」，
--- 于是刚露出来的**文档列表**被关掉、露出下一层，用户看到的就是
--- "下滑 → 知识库用户界面 → 缓存列表闪现 → 停在知识库用户界面"。
--- 12 层调用栈（v0.6.14 拿到）证明它是一条**真实的新输入事件**：
--- `handleInput → handleInputEvent → sendEvent → 列表 handleEvent
---  → Menu:onSwipe → Menu:onClose → onCloseAllMenus → UIManager:close`。
---
--- ⚠️ v0.6.14 的手法（记一个时钟起点，`age < 1.6` 算窗口内）**真机上没生效**：
--- 实测每次都走到 `noteMenuClosed` 的「用户关闭了知识库列表」那一支，而
--- 「免打扰窗内：忽略」那条日志**从来没出现过** —— 说明 clock 判定的窗口当时
--- 返回了 false。既然原因不明，就不要再依赖它。
---
--- v0.6.15 改成**完全不依赖时钟**：
---   · 一个布尔 `state.handover`，由 `UIManager:scheduleIn` 定时清除（KOReader
---     自己的调度器，不会再出现"算出来不在窗口内"这种事）；
---   · **三道拦截**：列表 `onSwipe`（吞掉）、`noteMenuClosed`（不记成用户意图）、
---     `UIManager.close` 闸口（**直接不放行** —— 覆盖一切关闭路径）。
--- ⚠️⚠️ **v0.6.16：上面这一整段判断被推翻了，看这里。**
---
--- 手势探针（v0.6.14 就在跑）的真实数据说明那些"第二个 south swipe"**不是**同一次
--- 物理滑动被重复派发，而是**用户自己的下一划**。判别依据只在
--- `Contact:handleSwipe`（gesturedetector.lua:891）里 —— 它给 swipe 的 `pos`
--- 用的是**起点**而不是抬手点（927-933 行有注释明说）：
---   · 退出阅读器那一划（我们记在「顶部下滑：返回知识库列表」）：pos.y ≈ 103~124、dist 72~95
---   · 被这道窗口吞掉的那些：pos.y ≈ 24~37（屏幕最上沿）、dist 260~484
--- 距离差 4~6 倍、起点差 70pt —— 物理形态完全不同。
--- ⇒ 窗口的副作用是**把用户的返回手势一起吞了**（用户原话："触摸不能过快，过快会失效"），
---   而这正是它一开始想解决的问题的反面。
---
--- v0.6.16 的对策：**把窗口压到最小，一击即止**。
---   · 长度 1.5s（覆盖探针实测到的 +0s / +1s 那种紧随其后的滑动）；
---   · 吞掉**一条** south swipe 立刻结束窗口 —— 最多只吞用户一下，绝不会连续吞；
---   · 不再用 `UIManager.close` 闸口拦关闭（那会把"点标题栏 X"也拦掉），
---     只拦**滑动**这一条路，点按始终畅通。
local HANDOVER_QUIET_SECONDS = 1.5

--- 是否"一击即止"：吞掉第一条 south swipe 后立刻结束免打扰期。
--- 见 HANDOVER_QUIET_SECONDS 的说明 —— 窗口存在的意义已经被数据否掉了，
--- 留着只是给"紧跟退出那一瞬"的滑动留一点点缓冲，不能再多。
local HANDOVER_ONE_SHOT = true

--- 「钉顶层 + 扫全栈」的窗口（秒）——**与上面那个吞划窗口刻意分开，别合并**。
---
--- 为什么不能跟着缩到 1.5s：觅阅补回 KOReader 文件管理器底座是**异步**的，
--- 真机日志实测发生在退出后 **+2.3 ~ +2.6s**：
---     [MiuRead][Home] FileManager base ready
---     [MiuRead][ReaderClosePerf] FileManager base created show_ms= 132
--- 钉子必须一直有效到那一刻，否则底座会按插栈规则插到**所有列表之上**，把文档
--- 列表盖死 —— 那正是 v0.6.13 ~ v0.6.15 一直在治的病。
--- 所以：钉子留 4.0s（够到 +2.6s 并留余量），吞划只留 1.5s 且一击即止。
local HANDOVER_PIN_SECONDS = 4.0

--- 免打扰期顺带开一个手势探针（秒），比窗口略长。
--- 探针把每一条送到 UIManager 的手势事件（swipe / multiswipe / two_finger_swipe /
--- pan_release / hold*）记一行日志，撞上残余手势时能在 crash.log 里直接看到
--- 它的类型、方向、落点和当时的顶层控件。平时 `state.probe == false`，零开销。
local GESTURE_PROBE_SECONDS = 3.0

--- 免打扰期内是否把知识库列表**钉在窗口栈最上层**（`Menu.modal = true`）。
---
--- 这是 v0.6.15 的主修复，理由是「为什么总闪一下 cache/ima 缓存列表」：
--- 觅阅在阅读器关闭后必然跑一遍「恢复原生界面」（日志时序
--- `reader -> native` → 重建 FileManager 底座 → `native -> home`），其中
--- `Plugin:_ensure_filemanager_base`（miuread main.lua:17573-17614）会
--- **无条件 `UIManager:show` KOReader 的文件管理器**，目录切到本次文档所在的
--- cache/ima。觅阅自己的注释写得很清楚：
---   *"Never suppress KOReader's native transition. It owns document teardown
---     and FileManager creation; MiuRead only observes the stable docless
---     surface and raises the parked home afterwards."*
--- 也就是说这一下**我们拦不住**（拦了就破坏 KOReader 自己的拆除流程），
--- 事后去关它永远慢一拍 —— 这就是"总是闪一下缓存列表"的来源。
---
--- 而 `UIManager:show`（uimanager.lua:186-199）的插栈规则是
--- 「插在**最上面那个非 modal 窗口之上**」。所以只要把列表标成 `modal`，
--- 觅阅随后 show / raise 的任何非 modal 窗口（文件管理器底座、它随后 raise
--- 的首页）都会被插到列表**下面** —— 不是"抢得快"，而是**根本盖不上来**。
--- 纯 z-order 保证，与时间、与谁先谁后都无关。
---
--- 只在免打扰期内钉：平时列表是普通窗口，进度条 / 对话框 / 阅读器照旧压在它
--- 上面，行为一点不改。见 Session.pinMenu。
---
--- ⚠️ v0.6.16：只钉**最上面那一层**不够 —— 插栈规则会把觅阅补回的 FileManager
--- 放到那一层列表之下，**而更下一层的列表仍在它下面**，于是"关掉文档列表、露出
--- 知识库用户界面"这一步会先露出 cache/ima（用户报的"闪现"，而且"不是每一次都如此"，
--- 取决于觅阅补底座时窗口开没开）。现在 `Session.pinMenu` 会把 `Imenu` 里
--- **所有还活着的列表**一起钉住，FileManager 只能落到全部列表之下。
local HANDOVER_PIN_MENU = true

--- 写在文档边车里的「本插件上次给它套用的版面档位」。
---
--- 有了它才能区分两种情况：
---   · 用户改了插件设置里的版面 → 下次打开要重新套用（否则改了没反应）；
---   · 用户只是在阅读器里手动调了缩放 → 不动它，尊重用户的调整。
--- 只靠"有没有边车文件"是分不出这两种情况的（读者一打开就有边车了）。
local LAYOUT_STAMP = "ima_layout"

--- 只有这些格式才认 zoom_mode。
--- （EPUB/TXT 走 CREngine 排版引擎，没有这一项。）
local ZOOMABLE_EXT = { pdf = true, djvu = true, djv = true }

local state = {
    active = false,   -- 本次阅读是否由 IMA 发起（阅读器一关就复位）
    path   = nil,     -- 正在阅读的本地文件
    menu   = nil,     -- 列表控件：阅读器关闭后要抬回顶层
    seeded = false,   -- 本次是否写入了文档默认阅读设置
    zoom_choice = nil, -- 本次写进去的版面（供 enforceSeededZoom 兜底校对）
    step   = 0,       -- 已排队的抬回次数
    hinted = false,   -- 「怎么翻页 / 怎么退出」只在每次启动提示一次
    -- 关闭阅读器后进入「校正窗口」，期间 reclaim 可以把被盖住的列表抬回来。
    -- 与 active 分开是因为：active 必须在阅读器关掉时就复位，否则**下一本
    -- 普通书籍**的阅读器菜单里也会冒出「← 返回 IMA 知识库」；而抬回列表
    -- 这件事要一直有效到觅阅把自己的首页恢复完（约 1.7s 之后）。
    reclaim_pending = false,
    -- 抬回定时器的令牌：同一轮里可能被排两队（onCloseWidget 与 closeReader），
    -- 只有令牌最新的一队有效，否则 step 会被交错推进（见 scheduleReclaim）。
    reclaim_token = 0,
    -- 用户**主动**关掉了列表（下滑 / 点 X → Menu:onSwipe → onClose →
    -- onCloseAllMenus → close_callback，且菜单已不在窗口栈）。此后**抬回**
    -- 一律收手 —— 绝不能把用户刚关掉的界面又强行 show 回来；但校正窗口内
    -- 的「收掉外来文件管理器」照做（见 reclaim ①）。
    --
    -- v0.6.10 真机实测：退出阅读器后停在知识库列表，此时用户再下滑关掉列表，
    -- 守护定时器那一拍发现"列表不在窗口栈里"就把**用户刚关掉的**界面重新
    -- show 了出来 —— 用户看到的是"下滑 → 露出下一层 → 又被弹回列表"。
    -- 由 Session.noteMenuClosed 置位；rememberMenu（换了一层列表）与
    -- prepare（打开新文档，见 6c 双保险）时复位。
    user_closed = false,
    -- 「吞 south swipe」是否开着（见 HANDOVER_QUIET_SECONDS，1.5s + 一击即止）。
    -- 由 Session.armSwipeHandover 置真、由 scheduleIn 的定时器或"吞了一条"
    -- 置假（都不依赖时钟）。
    handover = false,
    -- 吞划窗口的令牌：每次开窗 +1，在途的旧定时器醒来时靠它作废自己。
    handover_token = 0,
    -- 「钉顶层 + 扫全栈」是否开着（见 HANDOVER_PIN_SECONDS，4.0s）。
    -- **与 handover 刻意分开**：钉子要活到觅阅 +2.6s 补出文件管理器底座为止，
    -- 而吞划窗口必须短。两者用同一段逻辑会让"不吞用户手势"和"底座别盖上来"
    -- 二选一 —— 分开就都能满足。
    pinned = false,
    pin_token = 0,
    -- 手势探针是否开着（见 GESTURE_PROBE_SECONDS）。平时 false，零开销。
    probe = false,
    -- 本次阅读是否启用了「打开文档自动横屏」（见 ROTATION_SETTING）。
    -- 由 prepare 快照，abort / 退出时复位。
    rotation_on = false,
    -- **进入本次阅读之前**的屏幕旋转，退出时恢复到它（见 restoreRotation）。
    -- nil = 没记下（开关关着，或当时取不到屏幕旋转）⇒ 退出时一律不动屏幕。
    rotation_before = nil,
    -- 本次阅读里各页的「行网格」（行顶 + 行底，页面 pt，按行顶升序），
    -- 见 Session._lineGrid。按页号懒加载后缓存；nil = 还没取过。换文档时由 prepare 丢弃。
    line_grids = nil,
    -- 「翻页对齐」诊断日志还剩几条可打（见 Session._alignOverlap）。
    -- 只打前若干次：够看清 y0 有没有在动、zoom 是竖屏还是横屏。
    align_logs = nil,
}

----------------------------------------------------------------
-- 小工具
----------------------------------------------------------------

local function reader_open()
    local ok, ReaderUI = pcall(require, "apps/reader/readerui")
    if not ok or type(ReaderUI) ~= "table" then return false end
    local ui = ReaderUI.instance
    return ui ~= nil and ui.document ~= nil
end

--- 取 KOReader 的 Screen（`Device.screen`）。取不到返回 nil。
---
--- 惰性 + pcall：旋转是可选功能，桩环境或极老版本没有 screen 时，
--- 整条旋转链都必须安静跳过，绝不能连累"打开文档"本身。
local function ima_screen()
    local ok, Device = pcall(require, "device")
    if not ok or type(Device) ~= "table" then return nil end
    local screen = Device.screen
    if type(screen) ~= "table" then return nil end
    return screen
end

--- 顶层那个「会收到输入」的控件（跳过 toast：按约定 toast 永不拦截事件）。
local function topmost_widget()
    local stack = UIManager._window_stack
    if type(stack) ~= "table" then return nil end
    for i = #stack, 1, -1 do
        local widget = stack[i] and stack[i].widget
        if widget and not widget.toast then return widget end
    end
    return nil
end

--- 我们自己的列表里，当前还活在窗口栈里的那些（`Imenu.menus()`）。
--- 拿不到时返回空表：一律当"没有我们的列表"，走保守分支。
local function our_menus()
    local ok, Imenu = pcall(require, "ima.ui.menu")
    if not ok or type(Imenu) ~= "table" or type(Imenu.menus) ~= "function" then
        return {}
    end
    local ok_menus, menus = pcall(Imenu.menus)
    if not ok_menus or type(menus) ~= "table" then return {} end
    return menus
end

--- 这个控件是不是我们自己创建的列表。
--- 比 `widget == state.menu` 宽：**所有**还活着的列表都算 —— v0.6.16 起它们会被
--- 一起钉成 modal，凡是要"排除我们自己的窗口"的地方都必须一致，否则自锁死。
local function is_our_menu(widget)
    if widget == nil then return false end
    -- 兜底：`Session.rememberMenu` 直接登记过的那一层（测试与老路径会这么用）。
    if widget == state.menu then return true end
    local ok, Imenu = pcall(require, "ima.ui.menu")
    if not ok or type(Imenu) ~= "table" or type(Imenu.isOurs) ~= "function" then
        return false
    end
    local ok_ours, ours = pcall(Imenu.isOurs, widget)
    return ok_ours and ours == true
end

--- 顶层是不是「用户主动打开的、要独占输入的东西」。
--- 只有真正的**模态对话框**才算 —— 抢了它会把对话框压到底下。
---
--- 刻意**不**把觅阅的 `_miuread_transient` / `_miuread_modal_surface` 算进来：
--- 那些是觅阅「退出阅读器」恢复流程里的过渡层（文件管理器底座、读者恢复面），
--- 而它们出现的时机恰好就是我们要把列表抬回顶层的时机。认它们就等于永远
--- 抬不动 —— v0.6.9 实测结果正是如此（退出后直接停在 cache/ima 文件列表）。
local function is_foreign_overlay(widget)
    -- ⚠️ 必须排除我们**自己所有的**列表：v0.6.15 起列表会在「退出余波免打扰」期
    -- 被钉成 `modal`（见 HANDOVER_PIN_MENU）。不排除的话，列表自己就会被判成
    -- "不该抢的模态对话框"，reclaim 反而不敢把它抬回来 —— 自锁死。
    return widget ~= nil and widget.modal == true and not is_our_menu(widget)
end

--- 窗口控件的类型名。只用于日志，写坏了也不能连累 reclaim。
local function widget_name(widget)
    if widget == nil then return "nil" end
    local ok, name = pcall(function()
        if widget.name then return tostring(widget.name) end
        local class = widget.getClass and widget.getClass()
        if class and class.name then return tostring(class.name) end
        return (tostring(widget):gsub("^table: ", ""))
    end)
    return tostring(ok and name or "?")
end

--- 窗口栈快照（从底到顶，跳过 toast），失败返回占位串。
--- 这个只出现在诊断日志里 —— reclaim 的每一步早退都打一次，
--- 下次再出问题就能一眼看出"顶层到底是谁"。
local function stack_summary()
    local ok, summary = pcall(function()
        local stack = UIManager._window_stack
        if type(stack) ~= "table" then return "<无窗口栈>" end
        local parts = {}
        for i = 1, #stack do
            local widget = stack[i] and stack[i].widget
            if widget and not widget.toast then
                parts[#parts + 1] = widget_name(widget)
            end
        end
        return table.concat(parts, " < ")
    end)
    return tostring(ok and summary or "?")
end

--- 顶层是不是 KOReader 的文件管理器。
--- 含觅阅 `_ensure_filemanager_base` 补回来的那个「底座」—— 它是同一个单例。
local function is_file_manager(widget)
    if widget == nil then return false end
    local ok, FileManager = pcall(require, "apps/filemanager/filemanager")
    if not ok or type(FileManager) ~= "table" then return false end
    return FileManager.instance == widget
end

--- 窗口栈里所有 KOReader 文件管理器窗口（从顶到底）。
---
--- 为什么不能只看栈顶（v0.6.15）：列表被钉成 modal 之后，觅阅补回的文件管理器
--- 底座是插在列表**下面**的 —— 栈顶是列表，`topmost_widget()` 永远看不到它。
--- 于是"扫全栈"就成了必须的。
--- @param above Widget|nil 只看位于这个控件**之上**的那些；nil 表示整个栈都要
local function filemanager_windows(above)
    local found = {}
    local stack = UIManager._window_stack
    if type(stack) ~= "table" then return found end
    for i = #stack, 1, -1 do
        local widget = stack[i] and stack[i].widget
        if above ~= nil and widget == above then break end
        if widget ~= nil and is_file_manager(widget) then
            found[#found + 1] = widget
        end
    end
    return found
end

--- 把窗口栈里所有觅阅补回来的 KOReader 文件管理器收掉，返回收掉几个。
---
--- **必须在同一个同步调用里做完**：`UIManager:close`（uimanager.lua:232-280）只改
--- 窗口栈 + `setDirty`，真正的绘制延后到 `_repaint()`（1237）；而 `handleInput`
--- 的循环是「先 `_checkTasks()` + `_repaint()`，再 `Input:waitEvent`」（1500-1522）。
--- 两者结合 ⇒ 在关掉列表的同一个调用里把它收掉，它**一帧都不会被画出来**。
--- v0.6.15 是等 reclaim 那一拍（+1s）才收，那一秒就是用户看到的"闪现"。
--- @param reason string 记日志用
--- @return number 收掉了几个
local function sweep_file_managers(reason)
    local found = filemanager_windows(nil)
    if #found == 0 then return 0 end
    logger.info("[ima] 收掉 " .. tostring(#found)
        .. " 个觅阅补回的 KOReader 文件管理器（" .. tostring(reason)
        .. "；窗口栈 = " .. stack_summary() .. "）")
    for index = 1, #found do
        pcall(UIManager.close, UIManager, found[index])
    end
    return #found
end

local function miuread_plugin(readerui)
    local ok, PluginLoader = pcall(require, "pluginloader")
    if not ok or type(PluginLoader) ~= "table" then return nil end
    if type(PluginLoader.getPluginInstance) ~= "function" then return nil end
    local ok_get, plugin = pcall(PluginLoader.getPluginInstance, PluginLoader, "miuread")
    if not ok_get or type(plugin) ~= "table" then return nil end
    -- 只认挂在**当前这份**阅读器上的实例：每开一次阅读器都会新建一份，
    -- 别去动上一轮遗留的、或者文件管理器那一份。
    if readerui and plugin.ui ~= readerui then return nil end
    return plugin
end

----------------------------------------------------------------
-- 会话状态
----------------------------------------------------------------

--- 打开阅读器**之前**调用。
--- @param path 即将打开的本地文件绝对路径
function Session.prepare(path)
    state.active = true
    state.path   = tostring(path or "")
    state.seeded = false
    state.zoom_choice = nil
    state.step   = 0
    state.reclaim_pending = false
    -- 换了文档 ⇒ 上一份的行网格全部作废（见 Session._lineGrid / _alignOverlap）。
    state.line_grids = nil
    state.align_logs = nil
    -- 复位「用户主动关闭」标记（v0.6.13 双保险之二）：
    -- 只要是从 IMA 打开的文档，阅读结束后就必须把列表抬回来。
    -- v0.6.11/0.6.12 漏了这一步 —— 点开文档时 Menu:onMenuSelect 会调
    -- close_callback（菜单并没关，见 ima/ui/menu.lua），noteMenuClosed 把
    -- 它误记成「用户主动关闭」，于是整场阅读期间 reclaim 被 user_closed
    -- 毒死，退出后列表永远不回来。保险之一在 ima/ui/menu.lua 的
    -- close_callback（只认「菜单已不在窗口栈」的关闭）。
    state.user_closed = false
    -- 换了一次阅读 → 上一轮的退出余波免打扰与探针（见 HANDOVER_QUIET_SECONDS）
    -- 作废：用户已经在做别的事了。
    state.handover = false
    state.pinned = false
    state.probe = false
    -- ⚠️ 摘掉列表上的"钉子"（见 HANDOVER_PIN_MENU）。**必须在这里**：
    -- 阅读器是 `ReaderUI:showReaderCoroutine` 用 `UIManager:show(reader)`
    -- （readerui.lua:791）挂上去的，而插栈规则是"插在最上面那个**非 modal**
    -- 窗口之上"。列表要是还钉着，阅读器就会被盖在列表**后面**。
    -- prepare 是唯一一个「打开阅读器之前」的必经点（ima/views/reader.lua 两处
    -- 调用都在 openLocal 之前）。
    pcall(Session.pinMenu, false)
    -- 记录「进入本次阅读之前」的屏幕旋转，退出时恢复到它（见 restoreRotation）。
    -- 快照只能在这里取：prepare 是打开阅读器**之前**的唯一必经点，此刻屏幕
    -- 还是用户进来时的姿态。只在开关开着时记 —— 关着时我们一个键都不碰。
    state.rotation_on = Session.autoLandscape()
    state.rotation_before = nil
    if state.rotation_on then
        local Screen = ima_screen()
        if Screen and type(Screen.getRotationMode) == "function" then
            local ok_mode, mode = pcall(Screen.getRotationMode, Screen)
            if ok_mode then state.rotation_before = mode end
        end
    end
    -- 写文档设置失败绝不能连累「打开文档」本身：这一步只是可选覆盖，
    -- 失败了阅读器照样能开，按系统默认显示而已。
    pcall(Session.seedDocumentDefaults, state.path)
end

--- 打开失败时收尾，避免状态残留到下一次（否则下次会话会误以为还在 IMA 阅读中）。
function Session.abort()
    state.active = false
    state.path   = nil
    state.seeded = false
    state.zoom_choice = nil
    state.step   = 0
    state.reclaim_pending = false
    -- 同理摘钉子：打开失败也不能让列表把后面的界面盖住。
    pcall(Session.pinMenu, false)
    state.handover = false
    state.pinned = false
    state.probe = false
    -- 旋转：打开失败没改过屏幕，清掉快照即可（别让下一轮误恢复）。
    state.rotation_on = false
    state.rotation_before = nil
    -- 打开失败这条路同样要让觅阅首页解冻：觅阅在阅读器创建期间就把首页 park 了，
    -- 失败退出不会走 watchClose 那条链，不解冻就会留下「点不动的首页」。
    -- 稍微延后一点，避开 ReaderUI 拆除的那几拍。
    UIManager:scheduleIn(2.0, function()
        pcall(Session.unparkMiureadHome)
    end)
end

--- 记录当前列表控件。由 ima/ui/menu.lua 的 Imenu.show 每次调用，
--- 于是状态里拿到的永远是「用户最后看到的那一层列表」。
function Session.rememberMenu(menu)
    if menu then
        state.menu = menu
        -- 换了一层列表（进/出知识库）→ 重新开始守护。
        state.user_closed = false
    end
end

--- 列表被**用户主动**关掉。
---
--- 由 ima/ui/menu.lua 包装 `Menu.close_callback` 后调用 —— 只有「菜单已经
--- 不在窗口栈里」的 close_callback 才是用户主动关闭（Menu:onCloseAllMenus
--- **先** `UIManager:close(self)`、**后**调 close_callback；而 Menu:onMenuSelect
--- 选中条目后调的那次菜单还留在栈里，已经被 menu.lua 那边过滤掉了）。
---
--- ⚠️ v0.6.13 起**不再**作废抬回定时器 / 校正窗口（v0.6.11 那一刀切的
--- `reclaim_token+1` + `reclaim_pending=false` 把「收掉觅阅补回的
--- cache/ima 文件管理器」也一起杀掉了 —— 用户刚下滑露出的下一层随即被
--- 文件管理器盖住，等于「下滑退不出去」）。守护继续跑完校正窗口，
--- 但 user_closed=true 让 reclaim 只做文件管理器卫生、不再抬 / 重显列表。
--- @return boolean 是否记下了这次主动关闭
function Session.noteMenuClosed(menu)
    if menu ~= nil and menu ~= state.menu then return false end
    -- 吞划窗口内的"关闭"**不可能是**用户意图 —— 用户那一划用在退出阅读器上了。
    -- （窗口只有 1.5s 且一击即止，所以这条很少命中；见 HANDOVER_QUIET_SECONDS。）
    if Session.inSwipeHandover() then
        logger.info("[ima] 退出余波：忽略这次「关闭列表」（紧跟在退出之后）")
        return false
    end
    -- ⚠️ v0.6.16：这里**不再** `pinMenu(false)`。被关掉的这个控件已经不在窗口栈里，
    -- 它身上的 `modal` 没有任何作用；而 `pinMenu` 现在会作用于**所有**还活着的列表，
    -- 在这里调等于把下一层列表的钉子也一起拔了，白白丢掉窗口剩下的保护。
    -- 摘钉子只由 prepare / abort / 钉顶层窗口到期三处负责。
    state.user_closed = true
    logger.info("[ima] 用户关闭了知识库列表 → 停止抬回（外来文件管理器仍会被收掉）")
    return true
end

function Session.isActive()
    return state.active
end

----------------------------------------------------------------
-- 1) 文档打开时的版面
----------------------------------------------------------------

--- 当前选择的版面（设置界面读它做显示）。
---
--- 键不存在、或者存的是历史值（v0.6.2/0.6.3 的 "reflow"）时，都回落到
--- 「跟随系统默认」—— 也就是用户说的「文档显示正常」的那一档。
function Session.zoomChoice()
    local v = Config.get():getString(ZOOM_SETTING, "default")
    if ZOOM_IS_VALID[v] then return v end
    return "default"
end

function Session.zoomLabel(choice)
    local label = ZOOM_LABEL[choice or Session.zoomChoice()] or ZOOM_LABEL.default
    return _(label)
end

--- 把选择往前推一格，返回新值。设置界面里那一行用它。
function Session.cycleZoom()
    local cur = Session.zoomChoice()
    local next_choice = ZOOM_CYCLE[1]
    for i, name in ipairs(ZOOM_CYCLE) do
        if name == cur then
            next_choice = ZOOM_CYCLE[i % #ZOOM_CYCLE + 1]
            break
        end
    end
    Config.get():setString(ZOOM_SETTING, next_choice)
    return next_choice
end

----------------------------------------------------------------
-- 1a) 翻页为什么会有重复（v0.6.2 起修，v0.6.4 加固）
----------------------------------------------------------------
-- 用户报的「翻页时内容会有一部分和上一页重复，不同文档重复量还不一样」，
-- 根因是**固定像素**的重叠，不是百分比：
--
--   · KOReader 的 PDF 有两种视图（kopt_page_scroll）：
--       1 = 连续（continuous）→ ReaderPaging:onScrollPageRel
--       0 = 整页（page）      → ReaderPaging:onGotoPageRel
--   · 连续视图的重叠量取自 ReaderPaging.overlap，它在 init 时被赋成
--       Screen:scaleBySize(G_defaults:readSetting("DOVERLAPPIXELS"))  -- 默认 30
--     于是在 300dpi 的 Libra 2 上是个**固定像素值**。翻一屏只前进
--     「屏高 − 30px」，这 30px 就是重复的那一条。
--   · 整页视图的重叠量才是百分比：1 − zoom_overlap_v/100（默认 36%）。
--
-- 固定像素正好解释「不同文档重复量看起来不一样」——30px 在高字号文档里
-- 只够一两行，在低字号文档里能盖住三四行。
--
-- 所以两处都要覆盖成 0：
--   · 文档级 kopt_zoom_overlap_h/v（治整页视图，且顺手让它在文档间一致）
--   · 运行时 readerui.paging.overlap / readerui.zooming.zoom_overlap_*（治连续视图）
-- 后者见 enforceContinuousPaging，它对**已有边车的历史文档**同样生效，
-- 并在 onViewRecalculate 上再钉一道（旋屏/改模式会重算布局）。
function Session._writeLayout(ds, choice, continuous)
    -- ① 翻页重叠（v0.6.17：从「归零」改成「恰好一行高」）。
    --    文档级这两个键只对**整页视图**（kopt_page_scroll=0）有意义 —— 连续视图的
    --    重叠量在 ReaderPaging.overlap 上，那不是文档设置项，只能在运行时改
    --    （见 enforceContinuousPaging）。所以这里写什么都会被运行时覆盖，
    --    真正生效的是 _pinOverlap 算出来的「一行高」：
    --      开 → 0（占位；运行时再覆盖成一行高对应的小百分比）
    --      关 → 归还 KOReader 自己的默认 36/36
    ds:saveSetting("kopt_zoom_overlap_h", continuous and 0 or OVERLAP_DEFAULT)
    ds:saveSetting("kopt_zoom_overlap_v", continuous and 0 or OVERLAP_DEFAULT)

    -- ② 回退历史版本（v0.6.2 / v0.6.3）写下的「正文重排」。
    --    非重排档**必须显式把 kopt_text_wrap 关掉**：边车里残留的 text_wrap = 1
    --    会继续生效，文档照样按重排打开（慢 + 满屏空格），用户会以为升级没作用。
    --    四个字号参数则连键一起删掉，让它们回到 KOReader 自己的默认
    --    （重排关着的时候它们本来也不生效，留着只会误导）。
    ds:saveSetting("kopt_text_wrap", 0)
    for i = 1, #LEGACY_REFLOW_KEYS do
        ds:delSetting(LEGACY_REFLOW_KEYS[i])
    end

    if choice == "default" then
        -- 「跟随系统默认」= 把这些键**删掉**，让 KOReader 回落到全局默认。
        -- 只写死值不行：本机默认是 contentwidth，用户以后要是改了全局默认，
        -- 文档里那串死值就不会跟着变了。
        ds:delSetting("zoom_mode")
        ds:delSetting("normal_zoom_mode")
        -- ⚠️ 这两个也必须一起删。v0.6.2 / v0.6.3 在重排档下写过
        --    zoom_mode = "page"，而 ReaderZooming 会顺手把 genus/type 改成
        --    4/2（page 的组合）。只删 zoom_mode 的话，ReaderZooming:onReadSettings
        --    会退回 genus/type 再算一次 —— 依旧是「整页显示」，7 寸屏上正文
        --    会被压到看不清（正是 v0.6.0 那次翻车的样子）。
        --    删干净后 `or 3`（content）+ 缺省 type=width 会算回 contentwidth。
        ds:delSetting("kopt_zoom_mode_genus")
        ds:delSetting("kopt_zoom_mode_type")
    else
        ds:saveSetting("zoom_mode",        choice)
        ds:saveSetting("normal_zoom_mode", choice)
    end
end

--- 打开前按用户的选择写入版面。
---
--- 判断依据是边车里的 LAYOUT_STAMP，而不是"有没有边车文件"：
---   · 没写过 / 写的是别的档位 → 重新套用（用户刚改了插件设置，要生效）
---   · 已经是同一档位         → 不动（用户后来在阅读器里手动调过，要尊重）
--- 顺带：换了档位（或换了「翻页连续」开关）就会重新套用一次，历史版本留下的
--- 重排残留也就跟着被清掉 —— 这是一次性的迁移，之后指纹稳定下来就不再动手。
---
--- ⚠️ 真正生效的键是 normal_zoom_mode，不是 zoom_mode：
---    ReaderKoptListener:onReadSettings 按 normal_zoom_mode 设一次，
---    ReaderZooming:onReadSettings 再按边车里的 zoom_mode 设一次（后者落后手）。
---    只写 zoom_mode 的话会被盖掉，白写。
---    —— 实测日志里「setting zoom mode to pagewidth」后面紧跟
---       「setting zoom mode to contentwidth」就是这两次调用。
--- @return string
function Session.layoutStamp(choice, continuous)
    local flag = continuous and "1" or "0"
    return tostring(choice) .. "|" .. flag
end

function Session.seedDocumentDefaults(path)
    local choice     = Session.zoomChoice()
    local continuous = Config.get():getBool(CONTINUOUS_SETTING, true)
    local landscape  = Session.autoLandscape()

    local ext = tostring(path):lower():match("%.([%a%d]+)$")
    if not ext or not ZOOMABLE_EXT[ext] then return false end

    local ok_req, DocSettings = pcall(require, "docsettings")
    if not ok_req or type(DocSettings) ~= "table" then return false end

    local ok_open, ds = pcall(DocSettings.open, DocSettings, path)
    if not ok_open or type(ds) ~= "table" then
        logger.warn("[ima] 无法写入文档阅读设置", tostring(ds))
        return false
    end

    local stamp = Session.layoutStamp(choice, continuous)
    local ok_read, applied = pcall(ds.readSetting, ds, LAYOUT_STAMP)
    local stamp_same = ok_read and applied == stamp

    -- 旋转（见 ROTATION_SETTING）**不**沿用版面那条「档位没变就不动」的规矩：
    --   · 开着 → 每次打开都核对一遍。用户完全可能在阅读器里手动转回竖屏，而退出时
    --     `ReaderView:onSaveSettings` 会把那个值写进边车；不核对的话「自动横屏」
    --     会在下一次打开时**静默失效**，而用户只会觉得"这功能时灵时不灵"。
    --   · 关着 → 只在档位变化那一次把键**归还**（删掉），之后完全交给 KOReader：
    --     用户手动转出来的横屏能被正常记住，我们不再多嘴。
    local rot_dirty = false
    if landscape then
        local ok_rot, current = pcall(ds.readSetting, ds, "kopt_rotation_mode")
        if not ok_rot or current ~= ROTATION_LANDSCAPE then
            ds:saveSetting("kopt_rotation_mode", ROTATION_LANDSCAPE)
            rot_dirty = true
        end
    elseif not stamp_same then
        pcall(ds.delSetting, ds, "kopt_rotation_mode")
    end

    if stamp_same and not rot_dirty then return false end

    local wrote_layout = false
    local ok = pcall(function()
        if not stamp_same then
            Session._writeLayout(ds, choice, continuous)
            ds:saveSetting(LAYOUT_STAMP, stamp)
            wrote_layout = true
        end
        ds:flush()
    end)
    if ok then
        if wrote_layout then
            state.seeded = true
            state.zoom_choice = choice
            logger.info("[ima] 文档版面：" .. choice .. " " .. path)
        end
        if rot_dirty then
            logger.info("[ima] 文档旋转：以横屏打开（退出时恢复屏幕）")
        end
    else
        logger.warn("[ima] 写入文档阅读设置失败", path)
    end
    return ok
end

--- 兜底校正：万一写了还是没生效（比如用户把 normal_zoom_mode 的键名
--- 在别的版本里改了），这里现场再设一次。只在**本次刚写过**的文档上做，
--- 不会覆盖用户自己对某个文档的手动调整。
function Session.enforceSeededZoom(readerui)
    if not state.seeded or not readerui then return end
    local want = state.zoom_choice
    -- 只有三种「真实 zoom 模式」可以现场校正：
    --   · "default"：一个 zoom 键都没写，没有可校正的目标，而且
    --     ReaderZooming:onSetZoomMode **不校验取值** —— 去设 "default"
    --     会把 self.zoom_mode / view.zoom_mode 真的改成 "default"（非法值）。
    --   · 历史值 "reflow"（老配置升级上来时 state 里可能有）：同上，不能设。
    if not want or not ZOOM_ENFORCEABLE[want] then return end
    local view = readerui.view
    if not view or not view.zoom_mode or view.zoom_mode == want then return end
    local zooming = readerui.zooming
    if zooming and type(zooming.setZoomMode) == "function" then
        pcall(zooming.setZoomMode, zooming, want)
        logger.info("[ima] 版面未生效，已现场纠正（原为 " .. tostring(view.zoom_mode) .. "）")
    end
end

--- 兜底校正：开关开着、但打开后屏幕不是横屏 → 现场补一次。
---
--- 什么时候会走到这里（两条的表现都是"设备还是竖着的"）：
---   ① 用户开着「跨视图保持当前旋转」(`lock_rotation`) —— readerview.lua:968 会
---      **整个跳过**从边车取 `kopt_rotation_mode`，"读别的书时锁了竖屏"正是这一种；
---   ② 边车写入因为任何原因没生效。
---
--- 走 KOReader 自己的事件、而不是直接拧屏幕：`ReaderView:onSetRotationMode`
--- （readerview.lua:892-897）除了 `Screen:setRotationMode` 还会 `self:rotate()`
--- 把布局整个重算、再全屏重绘（900-920）—— 少任何一步画面都会错位。
--- 它内部自带 `mode ~= old_mode` 判断，所以已经是横屏时是 no-op（不弹通知、不重绘）。
function Session.enforceSeededRotation(readerui)
    if not state.rotation_on then return end
    if not readerui or type(readerui.handleEvent) ~= "function" then return end
    local Screen = ima_screen()
    if not Screen or type(Screen.getRotationMode) ~= "function" then return end
    local ok, current = pcall(Screen.getRotationMode, Screen)
    -- 取不到当前旋转就**什么都不做**：猜一个值去拧屏幕，比不生效坏得多
    -- （可能把用户自己转好的姿态强行改掉）。同理见 imageviewer 那两处开关。
    if not ok then return end
    if current == ROTATION_LANDSCAPE then return end
    local ok_req, Event = pcall(require, "ui/event")
    if not ok_req or type(Event) ~= "table" then return end
    pcall(readerui.handleEvent, readerui,
        Event:new("SetRotationMode", ROTATION_LANDSCAPE))
    logger.info("[ima] 打开后不是横屏，已现场补一次旋转")
end

--- 退出时把屏幕旋转恢复到「进入本次阅读之前」的值。
---
--- 为什么必须自己动手：`FileManager:showFiles`(filemanager.lua:1311) 里那句
--- `self:setRotationMode()` 才是 KOReader 原生的恢复点，而它**只在新建 FileManager
--- 实例时执行** —— IMA 的退出路径刻意不新建 FileManager（见 closeReader），
--- 所以那条路不会跑。
---
--- ⚠️ **时序是命门**：必须在 `ReaderUI:onClose` **返回之后**才能动屏幕。
--- onClose 内部会 `saveSettings()`（readerui.lua:871；`dialog == self` 时由
--- `UIManager:close` 触发的 onFlushSettings 代劳）→ `ReaderView:onSaveSettings`
--- 把**当前屏幕旋转**写回边车。此刻屏幕还是横屏 ⇒ 边车记的也是横屏 ✓。
--- 要是提前恢复成竖屏，边车就被改写成竖屏，**下次打开不会自动横屏了**。
---
--- 恢复目标是 `state.rotation_before`（prepare 时快照的进入前状态），不是
--- `fm_rotation_mode` —— 这样"用户本来就横屏用文件浏览器"的情形也能原样还原。
function Session.restoreRotation()
    local before = state.rotation_before
    state.rotation_before = nil
    if before == nil then return false end
    local Screen = ima_screen()
    if not Screen or type(Screen.getRotationMode) ~= "function"
        or type(Screen.setRotationMode) ~= "function" then
        return false
    end
    local ok, current = pcall(Screen.getRotationMode, Screen)
    if not ok then return false end
    if current == before then return false end
    pcall(Screen.setRotationMode, Screen, before)
    pcall(UIManager.setDirty, UIManager, nil, "full")
    logger.info("[ima] 退出阅读器：屏幕旋转已恢复（"
        .. tostring(current) .. " → " .. tostring(before) .. "）")
    return true
end

--- 打开文档时先把翻页重叠装好，让翻页不切断文字。
---
--- 为什么必须做成运行时而不只是写文档设置：
---   1) 用户已有的文档早就带着边车了，不会再走写盘那一步；
---   2) 连续视图用的是 ReaderPaging.overlap（屏幕像素），**不是**文档设置项，
---      写盘也写不进去，只能在实例上改。
--- 只改本次阅读器实例的字段，不碰 G_defaults，也不影响其它书。
function Session.enforceContinuousPaging(readerui)
    if not Config.get():getBool(CONTINUOUS_SETTING, true) then return end
    if not readerui then return end

    local paging  = readerui.paging
    local zooming = readerui.zooming

    -- ① 按行网格把翻页入口包起来（真正解决"页末字被切"的那一条）。
    Session.installPagingAlign(readerui)

    -- ② 连续视图的兜底值 + 整页视图的百分比，都在 _pinOverlap 里。
    --    它同时负责"防住旋屏/换模式带来的重算"，所以下面还要在
    --    onViewRecalculate 上再钉一道。
    --    这一路**不碰** paging.overlap —— 那个值现在是按行动态算的，
    --    周期性重置会把刚算好的对齐值冲掉。
    if paging and not paging._ima_overlap_pinned
        and type(paging.onViewRecalculate) == "function" then
        paging._ima_overlap_pinned = true
        local original = paging.onViewRecalculate
        paging.onViewRecalculate = function(self, ...)
            local result = original(self, ...)
            pcall(Session._pinOverlap, self, readerui.zooming)
            return result
        end
    end

    Session._pinOverlap(paging, zooming)
end

--- 当前缩放 = 视口宽px ÷ 页宽pt（ReaderZooming:getZoom）。拿不到就用兜底值。
local function ima_current_zoom(zooming)
    if zooming and type(zooming.getZoom) == "function" then
        local ok, z = pcall(zooming.getZoom, zooming)
        if ok and type(z) == "number" and z > 0 then return z end
    end
    return ZOOM_FALLBACK
end

--- 视口高度（像素）。拿不到返回 nil，调用方退让到 OVERLAP_PERCENT_FALLBACK。
local function ima_viewport_height()
    local ok, device = pcall(require, "device")
    if ok and type(device) == "table" and device.screen
        and type(device.screen.getHeight) == "function" then
        local ok2, h = pcall(device.screen.getHeight, device.screen)
        if ok2 and type(h) == "number" and h > 0 then return h end
    end
    return nil
end

--- 两个重叠来源的兜底/换算：
---   · 连续视图 ReaderPaging.overlap —— **只在第一次**给个「恰好一行」的像素兜底
---     （真正生效的量由 installPagingAlign 每次翻页前按行网格现算）；
---   · 整页视图 zoom_overlap_* —— 「一行高」对应的百分比。
---
--- 整页视图的单位是**百分比**（readerpaging.lua:963-964
--- `v_progress = 1 - zoom_overlap_v/100` ⇒ 步长 = 屏高 × v_progress），
--- 所以 v = 一行高 ÷ 屏高 × 100 —— 两边都是像素，比值与单位无关。
---
--- ⚠️ 连续视图那个值**不能反复赋值**：本函数还会被 onViewRecalculate 调用，
--- 无条件写会把刚按行算好的动态值冲回兜底，所以用 `_ima_overlap_fallback` 打标记。
---
--- ⚠️ 为什么不是 0：见文件头 1b。0 会让翻页步长正好等于屏高，跨屏的那一行必被切断。
function Session._pinOverlap(paging, zooming)
    if paging and not paging._ima_overlap_fallback then
        paging._ima_overlap_fallback = true
        local fallback_px = math.ceil(LINE_HEIGHT_PT * ima_current_zoom(zooming))
        paging.overlap = fallback_px
        logger.info(string.format(
            "[ima] 翻页重叠兜底 = 一行高 %dpx（连续视图；行网格取到后按行对齐）",
            fallback_px))
    end

    if not zooming then return end

    local zoom     = ima_current_zoom(zooming)
    local line_px  = LINE_HEIGHT_PT * zoom      -- 一行在屏幕上有多少像素
    local vh       = ima_viewport_height()
    local percent  = OVERLAP_PERCENT_FALLBACK
    if vh then
        percent = math.max(1, math.ceil(line_px / vh * 100))
    end

    if zooming.zoom_overlap_h ~= 0 then
        zooming.zoom_overlap_h = 0
    end
    if zooming.zoom_overlap_v ~= percent then
        local before = zooming.zoom_overlap_v
        zooming.zoom_overlap_v = percent
        logger.info(string.format(
            "[ima] 翻页重叠 = 一行高 %d%%（整页视图；原 %s，视口高 %s）",
            percent, tostring(before), tostring(vh)))
    end
end

----------------------------------------------------------------
-- 1c) 翻页按行网格对齐（v0.6.19 起；v0.6.20 修掉「位置取错」）
----------------------------------------------------------------
-- 为什么固定重叠量治不好「页末字被切成两半」：
--   本库的 PDF 是网页打印件，**行距根本不统一**。实测 16 份样本里同时存在
--   21.75 / 21.0 / 34.5 / 35.25 / 53.46pt 五种行顶间距（正文段内 21.75、
--   标题前后 34.5 / 53.46…）。固定重叠最多只能对齐其中一种：按 21.75 给，
--   碰到 35.25 的间距就回退不够，新屏顶部照样落在行内。
--   离线按真实行框跑的模拟（outputs/_tools/overlap_sim.py，16 份文档 72~80 屏）
--   印证了这一点：固定重叠取 0 ~ 71pt 里的**任何**值，「新屏顶部切字率」都在
--   59% ~ 73% 之间 —— 这就是用户说的「有时」。
--
-- 解法：不要猜行距，**直接问文档每一行在哪**。
--   PdfDocument:getPageTextBoxes(page)（pdfdocument.lua:101）走的是 MuPDF 的
--   stext 设备（ffi/mupdf.lua:503 的 page_mt:getPageText），**不经过 k2pdfopt
--   重排引擎** —— 所以既不会踩到本设备上「重排 = 卡死」那颗雷，结果还会被
--   DocCache 按 file+page 缓存一份。返回的每个 line 带 x0/y0/x1/y1，
--   单位是**页面坐标（zoom=1.0）**。
--
-- ⚠️⚠️ v0.6.19 **上机无效的根因：滚动位置取错了字段**。
--   v0.6.19 读的是 `paging.visible_area`，但那是
--   `ReaderView:recalculate()`（readerview.lua:761）产出的**一块贴着页面原点的、
--   屏幕大小的矩形** —— 它只在「尺寸/缩放变化」时被重算
--   （`ReaderPaging:onViewRecalculate` 只在收到 `ViewRecalculate` 事件时写它），
--   **翻页过程中它一动不动**。连续视图下它的 `y` 永远等于 `page_area.y`（= 0）。
--   ⇒ y0 恒为 0 ⇒ 查询区间 (H, 2H] 恒定 ⇒ 算出来的 overlap 每次都是同一个数
--   ⇒ **又退化成了固定重叠量**，等于什么都没修。实测日志印证：每次开文档都只打印
--   一次「行网格：第 1 页 N 行」，之后翻多少屏都不再有新值。
--
--   真正的滚动位置在 **`view.page_states[#].visible_area.y`** —— 这正是
--   `ReaderPaging:onScrollPageRel`（readerpaging.lua:921-937）自己取的那个
--   `last_page_state.visible_area`：它按 `offset.y = last_visible_area.h - overlap`
--   把「当前屏最下面那一页块」整体下移一步，所以它的 `.y` 就是当前屏顶在页面里的
--   位置（屏幕像素）。我们**必须和它取同一个字段**，否则算出来的步长对不上。
--
-- 单位换算（readerview.lua:414 的原文就是这条式子）：
--   `page_y = (state.visible_area.y + screen_y - state.offset.y) / state.zoom`
--   屏内相对量里 `state.offset.y` 会约掉，所以对「屏顶 / 屏底」这一对差值而言：
--   屏幕像素 ↔ 页面 pt 就是差一个 `state.zoom`（`view.state.zoom`，与 page_area
--   同源，不要另调 `zooming:getZoom()` —— 那会带 `view:onBBoxUpdate` 副作用）。
--   行网格按 pt 缓存也正合适：旋屏只改 zoom，表不用重取。
--
-- 对齐规则（每次**向下**翻页前重算一次重叠量）：
--   设当前屏顶 y0、屏高 H（屏幕像素），E = H / zoom 是屏高（页面 pt）。
--   不干预时下一屏底部落在 y0 + 2H —— 那是任意位置，切在行中间的概率约八成。
--   改成让下一屏底部落在**某个行顶 f**（f 为页面 pt）上：
--   于是 overlap = y0 + 2H − f×zoom ∈ [0, H)，步长 = H − overlap。
--     · 屏底落在行顶 ⇒ 该屏最后一行是**完整的**（正是用户要的）；
--     · 相邻两屏必然重叠（y0_{k+1} ≤ f_k·zoom − H ≤ y0_k + H），
--       所以从第二屏起**不可能有任何一行被切**（不只是"底部那行"）。
--
--   上限怎么取（这一步 v0.6.20 才想清楚）：
--     · 默认 cap = edge + E（edge = 当前屏底）⇒ f 取区间里**最大**的行顶，
--       重复量最小、步长接近满屏；
--     · 但如果当前屏底**正骑在某一行的身上**（说明上一屏把它切了），就必须让
--       那一行在下一屏完整重现：「下一屏顶 ≤ 该行顶」⇔「下一屏底 ≤ 该行顶 + E」
--       ⇒ cap = 该行顶 + E。这只是把上限往回挪一点点（一行距离 ≪ 一屏），
--       步长仍然接近满屏，却能救回被切掉的那半行。
--   ⚠️ 唯一救不回来的是**打开文档后的第一屏**：它的屏顶只能是 y0 = 0，
--      屏底必定落在任意位置。要对齐就得把页面顶部裁掉一截（丢掉文档开头），
--      不能接受。但**第一次翻页**就会按上面的规则把那一行救回来。
local EDGE_TOL = 0.35    -- 判「屏底骑在某一行上」的容差（页面 pt）

--- 最大的下标 i 使 sorted[i] < value；没有则 nil。
local function ima_binsearch_index_lt(sorted, value)
    local lo, hi, best = 1, #sorted, nil
    while lo <= hi do
        local mid = math.floor((lo + hi) / 2)
        if sorted[mid] < value then
            best = mid
            lo = mid + 1
        else
            hi = mid - 1
        end
    end
    return best
end

--- 最大的下标 i 使 sorted[i] <= value；没有则 nil。
local function ima_binsearch_index_le(sorted, value)
    local lo, hi, best = 1, #sorted, nil
    while lo <= hi do
        local mid = math.floor((lo + hi) / 2)
        if sorted[mid] <= value then
            best = mid
            lo = mid + 1
        else
            hi = mid - 1
        end
    end
    return best
end

--- 取某一页的行网格：`{ tops = {行顶…}, bots = {行底…} }`（页面坐标 pt，按行顶升序）。
--- 拿不到返回 nil。
---
--- 结果按页号缓存在 state.line_grids 里；`false` 表示"这一页试过了，没有"。
--- 全程 pcall：这是可选增强，任何一步失败都只是退回固定一行高，绝不能连累翻页。
--- @param pageno number|nil 省略时用文档当前页
function Session._lineGrid(readerui, pageno)
    local doc = readerui and readerui.document
    if type(doc) ~= "table" or type(doc.getPageTextBoxes) ~= "function" then
        return nil
    end

    if type(pageno) ~= "number" or pageno < 1 then
        pageno = 1
        if type(doc.getCurrentPage) == "function" then
            local ok_page, page = pcall(doc.getCurrentPage, doc)
            if ok_page and type(page) == "number" and page >= 1 then pageno = page end
        end
    end

    local grids = state.line_grids
    if not grids then
        grids = {}
        state.line_grids = grids
    end
    local cached = grids[pageno]
    if cached ~= nil then return cached or nil end

    local grid
    local ok_boxes, boxes = pcall(doc.getPageTextBoxes, doc, pageno)
    if ok_boxes and type(boxes) == "table" then
        local n = #boxes
        if n > 0 then
            -- 先收成 {top, bot} 对，按 top 排序（行框互不重叠 ⇒ 按 top 排等于按 bot 排），
            -- 再拆成两个平行数组：tops 供二分查找，bots 供「这一行被切了吗」判断。
            local spans = {}
            for i = 1, n do
                local line = boxes[i]
                local y = line and line.y0
                if type(y) == "number" then
                    local b = line.y1
                    spans[#spans + 1] = { y, (type(b) == "number" and b >= y) and b or y }
                end
            end
            if #spans > 0 then
                table.sort(spans, function(a, b) return a[1] < b[1] end)
                local tops, bots = {}, {}
                for i = 1, #spans do
                    tops[i] = spans[i][1]
                    bots[i] = spans[i][2]
                end
                grid = { tops = tops, bots = bots }
            end
        end
    end

    grids[pageno] = grid or false
    if grid then
        logger.info(string.format("[ima] 行网格：第 %d 页 %d 行", pageno, #grid.tops))
    else
        logger.info(string.format(
            "[ima] 行网格：第 %d 页取不到，翻页退回固定一行高", pageno))
    end
    return grid
end

--- 翻页前按行网格重算重叠量。
---
--- 只处理 diff > 0（向下翻）：向上翻是对称的，让 KOReader 按当前 overlap 退回去
--- 即可；用户读到页末被切的那一屏只可能是"向下翻到的新屏"。
function Session._alignOverlap(readerui, paging, diff)
    if type(diff) ~= "number" or diff <= 0 then return end
    if not Session.continuousPaging() then return end
    if type(paging) ~= "table" then return end

    -- ⚠️ 关键：要和 ReaderPaging:onScrollPageRel 取**同一个**字段。
    --    它用 `table.remove(self.view.page_states)` 拿到"最下面那一页块"，
    --    所以我们的包装在它之前跑时，`page_states[#]` 就是它将要用的那个。
    local view = paging.view
    if type(view) ~= "table" then return end
    local states = view.page_states
    if type(states) ~= "table" or #states ~= 1 then
        -- 一屏里跨了两页（>1 块）时，"下一屏底部该落在哪一页的行顶"是有歧义的；
        -- 本库文档是单页超长版式（doc_pages = 1），走不到这里。不动，保持原样。
        return
    end
    local st = states[1]
    local sv = st and st.visible_area
    if type(sv) ~= "table" then return end

    local y0, h = sv.y, sv.h        -- 屏幕像素（与 paging.overlap 同单位）
    if type(y0) ~= "number" or type(h) ~= "number" or h <= 0 then return end

    -- `view.state.zoom` 与 `view.page_area` 同源（getPageArea(page, zoom, rotation)），
    -- 直接取它，别再调 `zooming:getZoom()` —— 那条路会顺带跑 `view:onBBoxUpdate`。
    local zoom = view.state and view.state.zoom
    if type(zoom) ~= "number" or zoom <= 0 then
        zoom = ima_current_zoom(readerui and readerui.zooming)
    end
    if not (zoom > 0) then return end

    local pageno = (type(st.page) == "number" and st.page >= 1) and st.page or nil
    local grid = Session._lineGrid(readerui, pageno)
    if not grid then return end
    local tops, bots = grid.tops, grid.bots
    if type(tops) ~= "table" or #tops == 0 then return end

    local line_px = math.ceil(LINE_HEIGHT_PT * zoom)   -- 兜底：恰好一行
    local E    = h / zoom                              -- 屏高（页面 pt）
    local edge = (y0 + h) / zoom                       -- 当前屏底（页面 pt）

    -- 默认上限：不干预时下一屏底的位置（= 当前屏底 + 一个屏高）。
    local cap = edge + E

    -- 当前屏底若骑在某一行的身上（上一屏把它切成了两半），必须让那一行在下一屏
    -- 完整重现 —— 把上限收到「该行顶 + 一个屏高」。
    local cut = ima_binsearch_index_lt(tops, edge)
    if cut and bots[cut] and bots[cut] > edge + EDGE_TOL then
        cap = tops[cut] + E
    end

    local fi = ima_binsearch_index_le(tops, cap)
    if not fi or tops[fi] <= edge then
        -- 这一屏到下一屏之间一个行顶都没有（整段空白 / 一整张图），
        -- 没有可对齐的目标，退回「恰好一行」。
        paging.overlap = line_px
        return
    end

    local f = tops[fi]
    local overlap = (y0 + 2 * h) - f * zoom
    if overlap < 0 or overlap >= h then return end
    paging.overlap = overlap

    -- 诊断：只打前若干次，够看清「y0 到底动没动 / zoom 是竖屏还是横屏」就行。
    if (state.align_logs or 0) < 12 then
        state.align_logs = (state.align_logs or 0) + 1
        logger.info(string.format(
            "[ima] 翻页对齐：页顶 %dpx 屏高 %dpx zoom=%.3f 屏底 %.1fpt → 对齐到 %.1fpt（重叠 %dpx）",
            math.floor(y0), math.floor(h), zoom, edge, f, math.floor(overlap)))
    end
end

--- 把连续视图的翻页入口包一层：每次翻页前按行网格把 overlap 调好。
---
--- 只包**实例**上的 onScrollPageRel —— 连续视图的翻页正是走它
--- （readerpaging.lua:574-575：`self.view.page_scroll` 为真时 onGotoViewRel 直接
--- 转给它；点击/按键/滑动翻页都从这里过）。不动类方法、不碰其它书。
function Session.installPagingAlign(readerui)
    if not Session.continuousPaging() then return end

    local paging = readerui and readerui.paging
    if not paging or paging._ima_align_installed then return end
    if type(paging.onScrollPageRel) ~= "function" then return end

    paging._ima_align_installed = true
    local original = paging.onScrollPageRel
    paging.onScrollPageRel = function(self, page_diff, no_page_turn)
        pcall(Session._alignOverlap, readerui, self, page_diff)
        return original(self, page_diff, no_page_turn)
    end
    logger.info("[ima] 翻页已按行网格对齐（屏幕底部不再切断文字）")
end

----------------------------------------------------------------
-- 2) 摘掉觅阅对本次阅读的接管
----------------------------------------------------------------

function Session.liftMiureadHooks(readerui)
    if not readerui then return end

    local plugin = miuread_plugin(readerui)
    if not plugin then return end

    -- ① 已经装上的那套挂钩：摘掉
    if type(plugin._uninstall_reader_toolbar_hooks) == "function" then
        pcall(plugin._uninstall_reader_toolbar_hooks, plugin, readerui, "ima external document")
    end

    -- ② 挡住后续的重新安装。
    --    「reader ready」「旋屏（reader geometry committed）」「resume into reader」
    --    都会再同步一次挂钩，只摘不挡等于白摘。
    if type(plugin._sync_reader_toolbar_hooks) == "function" and not plugin._ima_blocked then
        plugin._ima_blocked = true
        local original = plugin._sync_reader_toolbar_hooks
        plugin._sync_reader_toolbar_hooks = function(self, reason)
            if state.active then return false end
            return original(self, reason)
        end
    end

    -- ③ 退出通道还原成 KOReader 原生的（否则一律弹回觅阅首页）
    if type(readerui._miuread_original_onHome) == "function" then
        readerui.onHome = readerui._miuread_original_onHome
    end
    if type(readerui._miuread_original_showFileManager) == "function" then
        readerui.showFileManager = readerui._miuread_original_showFileManager
    end

    logger.info("[ima] 本次阅读使用 KOReader 原生阅读器（已临时摘除觅阅阅读面板接管）")
end

----------------------------------------------------------------
-- 3) 关闭 → 抬回知识库列表
----------------------------------------------------------------

function Session.watchClose(readerui)
    if not readerui or type(readerui.onCloseWidget) ~= "function" then return end
    if readerui._ima_watch_installed then return end
    readerui._ima_watch_installed = true

    -- 只写实例字段：ReaderUI 是 prototype 继承出来的表，instance 上的赋值
    -- 不会污染共享原型。
    local original = readerui.onCloseWidget
    readerui.onCloseWidget = function(self, ...)
        local result
        if original then result = original(self, ...) end
        -- 阅读器已经拆掉：
        --   · active 立刻复位（否则下一本普通书籍的菜单会多出 IMA 条目）
        --   · 同时打开「校正窗口」，等觅阅把首页恢复完再把列表抬回来
        state.active = false
        state.reclaim_pending = true
        pcall(Session.scheduleReclaim)
        return result
    end
end

--- 重新排一轮「关掉阅读器之后把列表抬回顶层」的校正定时器。
---
--- 令牌是必须的：`watchClose` 的 onCloseWidget 与 `closeReader` 都会调本函数，
--- 两组定时器交错时 `state.step` 会被后一组冲掉 —— 结果 3.2s 那一拍被跳过、
--- 校正窗口在 5.0s（而不是 7.5s）就收口，觅阅补回文件管理器的那个时刻正好
--- 落在窗口之外。带上令牌后只有最后排的那一组有效。
function Session.scheduleReclaim()
    state.step = 0
    state.reclaim_token = (state.reclaim_token or 0) + 1
    Session._reclaimStep(state.reclaim_token)
end

function Session._reclaimStep(token)
    if token ~= state.reclaim_token then return end    -- 已被更新的一组取代

    local next_step = state.step + 1
    local delay = RECLAIM_DELAYS[next_step]
    if not delay then
        -- 校正窗口结束。注意是**在最后一次抬回之后**才收窗：
        -- 觅阅恢复首页会分几拍走完，中途可能再 raise 一次把我们盖住。
        state.reclaim_pending = false
        logger.info("[ima] 抬回校正窗口结束，窗口栈 = " .. stack_summary())
        return
    end
    state.step = next_step
    UIManager:scheduleIn(delay, function()
        if token ~= state.reclaim_token then return end
        pcall(Session.reclaim)
        -- 与抬列表同拍做，见文件头 4)：把觅阅 park 首页时挂起的输入放开。
        pcall(Session.unparkMiureadHome)
        pcall(Session._reclaimStep, token)
    end)
end

--- 把列表控件抬回顶层。
--- 只做「抢回被盖住的位置」：不重建列表、不发请求；已经在顶层时什么都不做。
---
--- 每一步早退都写日志（见文件头 6b 与 stack_summary）：这个方法以前是静默的，
--- 出问题时只能靠推测定位 —— 而"退出后停在 cache/ima 文件列表"整整查了两轮。
---
--- v0.6.13 的结构（顺序有意为之）：
---   ① 觅阅补回的 KOReader 文件管理器底座（cache/ima）**不受 user_closed
---      门控、一律收掉** —— 它盖住的不一定是列表，也可能是用户刚下滑露出
---      的下一层（kb_list / 首页）。收掉外来文件管理器永远不违背用户意图；
---      反过来，v0.6.11/0.6.12 把它和「停止抬回」绑在一起，结果是用户
---      下滑退出列表后，露出的下一层随即被 cache/ima 盖死，等于退不出去。
---   ② 之后才看 user_closed：用户主动关掉的界面不去复活（绝不能把用户
---      刚关掉的又强行 show 回来）。
--- @return boolean 是否发生了抬起
function Session.reclaim()
    if not state.reclaim_pending then
        logger.dbg("[ima] 抬回：校正窗口已过，不动手")
        return false
    end
    if reader_open() then
        logger.info("[ima] 抬回：阅读器又打开了，让位")
        return false
    end

    local menu = state.menu

    -- ① 外来文件管理器卫生（不设防，见函数头注释）。
    --
    -- v0.6.15 起列表会被钉成 modal，觅阅补回的文件管理器底座因此插在列表**下面**，
    -- `topmost_widget()` 永远看不到它 —— 所以**钉顶层期内**整个栈扫一遍收干净
    -- （留着它在栈里，等列表退场时就会被露出来，那就是"闪现 cache/ima 缓存列表"）。
    -- 钉顶层期过了退回旧行为：只收栈顶那个，不去动觅阅自己的层级。
    --
    -- ⚠️ 这里用的是 `state.pinned`（≈4s，覆盖觅阅 +2.6s 才补出底座），**不是**
    -- 那个 1.5s 的吞划窗口 —— 两者刻意分开，见 HANDOVER_PIN_SECONDS 的说明。
    local found_n = 0
    if state.pinned == true then
        found_n = sweep_file_managers("钉顶层期内，扫全栈")
    elseif is_file_manager(topmost_widget()) then
        found_n = sweep_file_managers("只收栈顶")
    end
    local top = topmost_widget()
    if found_n > 0 and menu ~= nil and top == menu then
        logger.info("[ima] 已回到知识库列表（收掉 FileManager 后自然露出）")
        return true
    end

    -- ② 用户自己关掉的界面不去复活（见 state.user_closed / noteMenuClosed）。
    --    ⚠️ 免打扰期内那次「关闭」是顶部下滑退出的余波，不是用户意图
    --    （见 HANDOVER_QUIET_SECONDS）—— 此时必须照常把列表抬回来，否则文档列表
    --    再也不会出现（v0.6.13 的实测现象就是"先弹到知识库用户界面，
    --    文档列表自始至终没出现"）。
    if state.user_closed then
        if not Session.inSwipeHandover() then return false end
        logger.info("[ima] 抬回：免打扰期内的「关闭」是退出余波，照常抬回列表")
    end

    if not menu then
        logger.info("[ima] 抬回：还没有记录过知识库列表")
        return false
    end

    if not UIManager:isWidgetShown(menu) then
        -- 列表被整个从窗口栈里拿掉了（觅阅桌面模式接管时会清场）。
        -- 这时候"抬"无从谈起 —— 只能重新显示一次。
        logger.info("[ima] 知识库列表已不在窗口栈里，重新显示")
        if not pcall(UIManager.show, UIManager, menu) then return false end
        if not UIManager:isWidgetShown(menu) then return false end
        top = topmost_widget()
    end

    if top == menu then
        -- 拍点加密后这条会非常频繁，降到 dbg（crash.log 是 INFO 级，看不到）。
        logger.dbg("[ima] 抬回：列表已在顶层，无需动作")
        return true
    end

    -- 真的模态对话框让位（用户可能正在输入）；觅阅的过渡层不让（见 is_foreign_overlay）。
    if is_foreign_overlay(top) then
        logger.info("[ima] 抬回：顶层是模态对话框（" .. widget_name(top) .. "），暂不抢")
        return false
    end

    local ok, Imenu = pcall(require, "ima.ui.menu")
    if not ok or type(Imenu.raise) ~= "function" then return false end

    if Imenu.raise(menu) then
        logger.info("[ima] 已回到知识库列表（越过 " .. widget_name(top) .. "）")
        return true
    end
    logger.warn("[ima] 抬回失败：窗口栈 = " .. stack_summary())
    return false
end

----------------------------------------------------------------
-- 3a) 关闭闸口：关列表时顺手清掉缓存列表 + 诊断「谁关掉了知识库列表」
----------------------------------------------------------------
-- ⚠️ **v0.6.16 起它不再拦任何关闭。** v0.6.15 用它拦下"免打扰期内对列表的关闭"，
-- 副作用是把"点标题栏 X"也一起拦了 —— 用户的原话是"触摸不能过快，过快会失效"。
-- 而拦那一划的理由（"同一划被重复派发"）已经被手势探针的数据推翻，见文件头 6d)。
--- 关闭闸口（只包一层 `UIManager:close`）。两件事：
---
--- ① **在关掉我们任一列表的同一个同步调用里，把觅阅补回的 KOReader 文件管理器
---    收掉**（`sweep_file_managers`）。这就是"从文档列表返回知识库用户界面时会
---    闪现一下 cache/ima 缓存列表"的正解：`UIManager:close` 只改窗口栈 +
---    `setDirty`，真正的绘制延后到 `_repaint()`（uimanager.lua:1237），而
---    `handleInput` 是「先 `_checkTasks()` + `_repaint()`，再 `Input:waitEvent`」
---    （1500-1522）—— 所以**在同一次调用里**把文件管理器也摘掉，它一帧都画不出来。
---    v0.6.15 是等 reclaim 那一拍（约 +1s）才收，那一秒就是用户看到的"闪现"。
---
--- ② 诊断：记录「谁关掉了列表」的调用栈（warn 级）。KOReader 自己的
---    `UIManager:close` 只写 `logger.dbg`（uimanager.lua:237），而设备日志是 INFO
---    级，所以 v0.6.9~v0.6.11 三轮查这件事都只能靠猜，每猜一次就要重打包上机。
function Session.installCloseGuard()
    if type(UIManager.close) ~= "function" then return false end
    -- 标记名一路走过来的语义：`_ima_close_spy`（v0.6.11 只观察）→
    -- `_ima_close_guard`（v0.6.15 会拦）→ 现在既不拦也不只是观察（清理 + 诊断）。
    -- 名字保持不变，热重载后装的仍是同一层。
    if UIManager._ima_close_guard == true then return true end

    local original = UIManager.close
    UIManager.close = function(self, widget, ...)
        if widget ~= nil and is_our_menu(widget) then
            -- ① 先清掉夹在窗口栈里的缓存列表，**再**让列表真的关 —— 顺序有意为之：
            --    这样"顶层是文件管理器"这个中间态一秒都不会存在（连一帧都画不到）。
            pcall(sweep_file_managers, "关闭列表前清掉夹在中间的")
            -- ② 诊断：把调用栈写进日志。
            local ok, trace = pcall(debug.traceback, "", 2)
            local where = ""
            if ok and type(trace) == "string" then
                local lines, kept = {}, 0
                for line in trace:gmatch("[^\n]+") do
                    -- 12 层：v0.6.12 实测 6 层不够 —— 列表在退出 ~1 秒后被一个
                    -- south swipe 关掉，栈正好在第 6 层被截断，看不到事件是
                    -- 从哪里（sendEvent / 定时器 / 觅阅）派发给列表的。
                    kept = kept + 1
                    if kept > 12 then break end
                    lines[#lines + 1] = (line:gsub("^%s+", ""))
                end
                where = table.concat(lines, " | ")
            end
            logger.warn("[ima] 诊断：知识库列表被关闭，调用栈 = " .. where)
        end
        return original(self, widget, ...)
    end
    UIManager._ima_close_guard = true
    return true
end

----------------------------------------------------------------
-- 3b) 退出阅读器：只关阅读器，不把 FileManager 拉出来
----------------------------------------------------------------
-- 详见文件头 6)。一句话：ReaderUI:onHome() 会在 onClose() 之后顺手
-- `showFileManager(当前文档)`，于是 KOReader 新建一个 FileManager 并把目录切到
-- cache/ima（本插件的文档目录），再按 UIManager:show 的规则插到**知识库列表
-- 上面** —— 既造成"关掉阅读器先闪一下文件列表"，也让那个 FileManager 永久留在
-- 窗口栈里（之后在列表上再下滑就会退到它）。
-- 只调 onClose 就没有这些问题：阅读器关掉后露出的是本来就压在下面的窗口。

--- 关闭阅读器，让下面的窗口（知识库列表）自己露出来。
---
--- onClose 是**同步**收残骸的：`UIManager:close(self.dialog)` →
--- `handleEvent("CloseWidget")` → 实例上的 onCloseWidget（watchClose 里已经
--- 把 active / reclaim_pending 设好）→ 所以这里可以立刻抬一次列表，不用等。
--- @return boolean 是否成功发起关闭
function Session.closeReader(readerui)
    if not readerui or type(readerui.onClose) ~= "function" then return false end
    if not pcall(readerui.onClose, readerui) then return false end

    -- 立刻抢回顶层（本来就在顶层时 reclaim 自己会早退），
    -- 之后几拍留给「觅阅恢复停靠首页」的兜底。
    pcall(Session.reclaim)
    pcall(Session.scheduleReclaim)
    return true
end

--- 把 `readerui.onHome` 改道到 closeReader。
---
--- KOReader 里"回主页"这条语义 = "退出阅读器"，但原生实现会拉出 FileManager。
--- 除了本插件自己的入口，`ReaderBack`（在文档开头再"返回"一次）也会发
--- `Event:new("Home")`（readerback.lua:173），最终落到同一个方法上，
--- 所以这里统一改道。
---
--- 三条自我约束：
---   · 只有 `state.active`（本次阅读由 IMA 发起）时改道，普通书籍一点没变；
---   · 兜底调用的是**捕获下来的原生 onHome**，不是 `self.onHome` ——
---     否则一旦 onClose 失败就是无限递归；
---   · 幂等：实例上留标记，重复调用直接返回。
function Session.installExitRouting(readerui)
    if not readerui or type(readerui.onHome) ~= "function" then return false end
    if readerui._ima_exit_routed then return true end

    local native_home = readerui.onHome
    readerui._ima_native_onHome = native_home   -- 兜底用，避免递归

    readerui.onHome = function(self, ...)
        if state.active and Session.closeReader(self) then
            logger.info("[ima] 退出阅读器（不拉出 FileManager）")
            return true
        end
        return native_home(self, ...)
    end
    readerui._ima_exit_routed = true
    return true
end

--- 给 onClose 包一层：**原函数返回之后**再恢复屏幕旋转（见 restoreRotation 的时序）。
---
--- 为什么包 onClose 而不是只写在 closeReader 里：onClose 是**所有**退出路径的
--- 汇合点 —— 我们的 onHome 改道、ReaderBack 的 Home 事件、阅读器菜单里的退出、
--- 以及 KOReader 内部任何直接调用，只挂这一处就不会漏；而 closeReader 自己也是
--- 调 readerui.onClose，于是自动被覆盖，不必重复写一遍。
---
--- 幂等：实例上留标记，重复调用直接返回。
function Session.installRotationRestore(readerui)
    if not readerui or type(readerui.onClose) ~= "function" then return false end
    if readerui._ima_rotation_routed then return true end

    local native_close = readerui.onClose
    readerui.onClose = function(self, ...)
        local ok, err = pcall(native_close, self, ...)
        -- ⚠️ 必须正好在这个位置（原函数已返回）。早一步会把边车里的旋转改写成
        -- 竖屏 —— onClose 内部才做 saveSettings，那一步之前屏幕还不能动。
        pcall(Session.restoreRotation)
        if not ok then error(err) end
        return nil
    end
    readerui._ima_rotation_routed = true
    return true
end

----------------------------------------------------------------
-- 4) 给觅阅首页解冻（否则退回首页后点击全无反应）
----------------------------------------------------------------
-- 详见文件头 4)。一句话：打开阅读器时觅阅会把首页 park 掉
-- （`_miu_input_suspended = true`），而 `HomeWidget:handleEvent` 会因为那个标志
-- **把所有输入原样吞掉**；解除它的 `HomeView.unpark()` 只存在于觅阅自己那两条
-- 「恢复首页」的路径里，而 IMA 的退出恰恰绕过了那两条路径。这里用觅阅的
-- 公开 API 补一次解冻。
--
-- 三条自我约束：
--   · 只在「阅读器确实已关闭」时动手（reader_open()），绝不打扰正常阅读；
--   · 只认 `is_parked()`：没被 park 就什么都不做（幂等，反复调用无副作用）；
--   · 只清输入挂起标志 + 一次重绘，**不动窗口顺序**（不 raise、不抢前台），
--     更不写觅阅的任何设置文件。觅阅若改了内部结构，这里安静退出，不去猜字段名。
function Session.unparkMiureadHome()
    if reader_open() then return false end

    -- 惰性 require：觅阅没装、或它自己的 home_view 还没被加载时直接跳过。
    local ok_req, HomeView = pcall(require, "miuread.home_view")
    if not ok_req or type(HomeView) ~= "table" then return false end
    if type(HomeView.is_parked) ~= "function" or type(HomeView.unpark) ~= "function" then
        return false
    end

    local ok_parked, parked = pcall(HomeView.is_parked)
    if not ok_parked or parked ~= true then return false end

    local ok_unpark = pcall(HomeView.unpark)
    if ok_unpark then
        logger.info("[ima] 觅阅首页已解冻（unpark），避免退回首页后输入被吞")
    else
        logger.warn("[ima] 觅阅首页解冻失败")
    end
    return ok_unpark
end

----------------------------------------------------------------
-- 5) 阅读界面顶部下滑 = 返回知识库列表
----------------------------------------------------------------
-- 详见文件头 5)。一句话：KOReader 把屏幕顶部 12.5% 条带（DTAP_ZONE_MENU）
-- 的下滑固定绑给了「打开菜单」（ReaderMenu:onSwipeShowMenu，只认
-- direction == "south"），而知识库列表里"下滑"是「返回上一层」
-- （KOReader 自带的 Menu:onSwipe：south → onClose()）。本次阅读由 IMA 发起时，
-- 把阅读器里那一划也改成"返回上一层"，两处手感就一致了。

--- 顶部下滑返回列表的开关（默认开）。
function Session.swipeBackEnabled()
    return Config.get():getBool(SWIPE_BACK_SETTING, true)
end

--- 翻转开关，返回新值。设置界面那一行用它。
function Session.toggleSwipeBack()
    local cfg = Config.get()
    local next_value = not cfg:getBool(SWIPE_BACK_SETTING, true)
    cfg:setBool(SWIPE_BACK_SETTING, next_value)
    return next_value
end

--- 现在是否在「吞 south swipe」的小窗口内。见 HANDOVER_QUIET_SECONDS（1.5s，一击即止）。
---
--- 注意它**只管吞划**；「钉顶层 / 扫全栈」是另一个更长的窗口，见
--- `state.pinned` 与 HANDOVER_PIN_SECONDS。两者刻意分开。
---
--- v0.6.15 起**不再有任何时间计算**：只看一个布尔，清除由 `UIManager:scheduleIn`
--- 负责。（v0.6.14 用「起始时刻 + age < 1.6」判定，真机上四次实测全部落空，
--- 而"窗口内"的分支从未走到 —— 与其继续猜时钟，不如不用时钟。）
function Session.inSwipeHandover()
    return state.handover == true
end

--- 现在是否处于「钉顶层 / 扫全栈」窗口内（见 HANDOVER_PIN_SECONDS）。
function Session.isPinnedWindow()
    return state.pinned == true
end

--- 把**我们所有还活着的列表**钉在窗口栈上层 / 摘掉钉子。见 HANDOVER_PIN_MENU。
---
--- `UIManager:show`（uimanager.lua:186-199）把新窗口插在「最上面那个非 modal
--- 窗口之上」；所以只要列表都是 modal，觅阅随后 show / raise 的任何非 modal 窗口
--- （文件管理器底座、它随后 raise 的首页）都只能插到列表**下面** —— 不是"抢得快"，
--- 而是**根本盖不上来**。纯 z-order 保证，与时间、与谁先谁后都无关。
---
--- ⚠️ v0.6.16 改成钉**全部**列表：只钉最上面那一层时，底座会落到那层列表之下、
--- **而更下一层的列表仍在它下面** → "关掉文档列表、露出知识库用户界面"这一步
--- 就会先露出 cache/ima。见 HANDOVER_PIN_MENU 的说明。
---
--- ⚠️ 打开阅读器之前必须摘（`Session.prepare` / `abort` 已做），否则阅读器会被
--- 列表盖在后面。
--- @param on boolean
--- @return boolean 是否真的改到了（至少钉/摘了一层）
function Session.pinMenu(on)
    if not HANDOVER_PIN_MENU then return false end

    local changed = 0
    local menus = our_menus()
    for i = 1, #menus do
        menus[i].modal = on and true or nil
        changed = changed + 1
    end
    if changed > 0 then return true end

    -- 登记表为空时的兜底：只钉最近记住的那一层（测试与老路径会这么用）。
    local menu = state.menu
    if type(menu) ~= "table" then return false end
    menu.modal = on and true or nil
    return true
end

--- 开始一轮「退出余波」（钉顶层 + 打开手势探针 + 一条吞划缓冲）。
--- 由顶部下滑那条路径调用，且**必须在关闭阅读器之前** —— 这样觅阅随后
--- `UIManager:show` 的文件管理器底座与它 raise 的首页都插在列表下面。
---
--- 不依赖时钟：置布尔 + 排 `scheduleIn` 定时清除。每次开窗把 token 推进一格，
--- 在途的旧定时器醒来时靠 token 作废自己（幂等）。
---
--- ⚠️ 两个窗口**刻意不同长**（见 HANDOVER_PIN_SECONDS）：
---   · 钉子 4.0s —— 必须活到觅阅 +2.6s 补出文件管理器底座之后；
---   · 吞划 1.5s 且一击即止 —— 只在"刚退出那一瞬"挡一下，不能吞用户的操作。
--- @return boolean 是否真的开了窗（没有列表可选时为 false）
function Session.armSwipeHandover()
    state.handover = true
    state.probe = true
    state.handover_token = (state.handover_token or 0) + 1
    local token = state.handover_token

    state.pinned = true
    state.pin_token = (state.pin_token or 0) + 1
    local pin_token = state.pin_token

    local pinned = Session.pinMenu(true)
    logger.info("[ima] 退出余波：吞划窗口 " .. tostring(HANDOVER_QUIET_SECONDS)
        .. "s / 钉顶层 " .. tostring(HANDOVER_PIN_SECONDS)
        .. "s（列表钉顶层=" .. tostring(pinned) .. "）")

    UIManager:scheduleIn(HANDOVER_QUIET_SECONDS, function()
        if state.handover_token ~= token then return end
        state.handover = false
        logger.info("[ima] 退出余波：吞划窗口结束")
    end)
    UIManager:scheduleIn(HANDOVER_PIN_SECONDS, function()
        if state.pin_token ~= pin_token then return end
        state.pinned = false
        Session.pinMenu(false)
        logger.info("[ima] 退出余波免打扰：结束（列表恢复普通层级）")
    end)
    UIManager:scheduleIn(GESTURE_PROBE_SECONDS, function()
        if state.handover_token ~= token then return end
        state.probe = false
    end)
    return true
end

--- 吞划窗口内，把「列表上的 south 滑动」挡掉（不关列表）。
---
--- 由 ima/ui/menu.lua 给每个列表实例的 `onSwipe` 包一层后调用 —— 包里那一层
--- 只在窗口内生效，一过原样交回 KOReader 的 `Menu:onSwipe`，用户之后主动下滑
--- 退出列表的手感分毫不变。
---
--- ⚠️ v0.6.16：**只有"滑动"这一条路会被挡**（用户点标题栏 X 永远畅通），并且
--- **一击即止**（`HANDOVER_ONE_SHOT`）—— 吞掉一条立刻收窗，最多只影响用户一下。
--- 这是 v0.6.15 那句"被绕过"的更正：探针数据显示当时那条 traceback 其实是
--- **窗口之外**的一次滑动，包装从来没被绕过（见文件头 6d）。
--- @param direction string 滑动方向（原始值，未做镜像翻转）
--- @return boolean 是否吞掉了这一划
function Session.swallowHandoverSwipe(direction)
    if not Session.inSwipeHandover() then return false end
    -- `Menu:onSwipe` 用 Bidi.flipDirectionIfMirroredUILayout 先翻转再比较，
    -- 这里照做，否则镜像界面（阿拉伯语等）下会把方向判反、漏吞。
    local flipped = direction
    local ok, Bidi = pcall(require, "ui/bidi")
    if ok and type(Bidi) == "table" and type(Bidi.flipDirectionIfMirroredUILayout) == "function" then
        local ok_f, value = pcall(Bidi.flipDirectionIfMirroredUILayout, direction)
        if ok_f and value then flipped = value end
    end
    if flipped ~= "south" then return false end
    logger.info("[ima] 退出余波：吞掉列表上这一划（紧跟在退出之后）")
    if HANDOVER_ONE_SHOT then
        -- 一击即止：立刻收窗（吞划窗口），让用户的下一次滑动一定畅通。
        -- 钉子**不动** —— 它管的是"底座别盖上来"，与吞划是两件事。
        state.handover = false
        state.handover_token = (state.handover_token or 0) + 1   -- 作废在途定时器
        logger.info("[ima] 退出余波：已吞一条，立刻收窗（一击即止）")
    end
    return true
end

--- 会进探针日志的手势类型。
--- 刻意不含 `touch` / `pan`：它们在滑动过程中每帧都来，会把日志刷爆。
local PROBE_GES = {
    swipe = true, multiswipe = true, two_finger_swipe = true,
    pan_release = true, hold = true, hold_start = true, hold_release = true,
}

--- 免打扰期记录每条手势事件（只记上面那几种）。
--- 开关是 `state.probe`，由 armSwipeHandover 开、scheduleIn 关（不依赖时钟）。
function Session._probeGesture(event)
    if state.probe ~= true then return end
    if type(event) ~= "table" or event.handler ~= "onGesture" then return end
    local ges = event.args and event.args[1]
    if type(ges) ~= "table" or not PROBE_GES[ges.ges] then return end
    local pos = ges.pos
    logger.info("[ima][手势探针] ges=" .. tostring(ges.ges)
        .. " dir=" .. tostring(ges.direction)
        .. " dist=" .. tostring(ges.distance)
        .. " pos=" .. tostring(pos and pos.x) .. "," .. tostring(pos and pos.y)
        .. " 顶层=" .. widget_name(topmost_widget()))
end

--- 装手势探针。只包一层 `UIManager:sendEvent`，探针关着时透传（一次比较的开销）。
--- **只观察，不改变任何行为与返回值** —— 它是唯一能事后分辨"两条 swipe 是不是同一次
--- 物理滑动"的手段（对照 `顶部下滑` 与 `吞掉列表上这一划` 两行记下的 dist/pos），
--- v0.6.14 那个错误结论就是靠它推翻的。
function Session.installGestureProbe()
    if type(UIManager.sendEvent) ~= "function" then return false end
    if UIManager._ima_send_probe == true then return true end

    local original = UIManager.sendEvent
    UIManager.sendEvent = function(self, event, ...)
        if state.probe == true then pcall(Session._probeGesture, event) end
        return original(self, event, ...)
    end
    UIManager._ima_send_probe = true
    return true
end

--- 把「顶部下滑」接到返回列表上。
---
--- 只包 ReaderMenu 的**实例**方法，不碰它的原型，也不碰任何 zone 定义 ——
--- 原 zone 的 handler 是闭包，里面写 `self:onSwipeShowMenu(ges)`，方法名在
--- 调用时才解析，所以实例赋值能活过 `ReaderMenu:onSetDimensions`
--- （旋屏 / ReaderReady 都会把 zone 再注册一遍）。反之若自己去注册同名 zone，
--- 下一次 initGesListener 就会把我们覆盖掉。
---
--- 幂等：实例上留一个标记，重复调用直接返回。
--- @return boolean 是否装上了
function Session.enableSwipeBack(readerui)
    if not Session.swipeBackEnabled() then return false end

    local menu = readerui and readerui.menu
    if type(menu) ~= "table" then return false end
    if menu._ima_swipe_back then return true end
    if type(menu.onSwipeShowMenu) ~= "function" then return false end

    -- ReaderMenu 是 prototype 继承出来的表，instance 上的赋值不会污染共享原型。
    local original = menu.onSwipeShowMenu
    menu.onSwipeShowMenu = function(self, ges)
        -- 只接管**从上往下**那一划。其余方向原文本来也不处理，原样交回即可
        -- （它会自己 return nil）。
        if ges and ges.direction == "south" and state.active then
            -- ⚠️ 这个事件必须**先**发：returnNow 会把阅读器拆掉，之后再拿
            -- self.ui 就是残骸了。作用与原文一致 —— 告诉阅读器这一划已被消费，
            -- 别再同时当成滚动/翻页。
            pcall(function()
                self.ui:handleEvent(require("ui/event"):new("HandledAsSwipe"))
            end)
            -- 落点 / 距离一并记下：万一免打扰窗没兜住，这两组数字能和探针
            -- 记到的那一划对照，一眼看出是"同一次物理滑动被重复派发"
            -- 还是"真的又划了一次"。
            logger.info("[ima] 顶部下滑：返回知识库列表（dist=" .. tostring(ges.distance)
                .. " pos=" .. tostring(ges.pos and ges.pos.x) .. "," .. tostring(ges.pos and ges.pos.y)
                .. "）")
            -- 开一轮「退出余波免打扰」（见 6d) 与 HANDOVER_QUIET_SECONDS）。
            -- ⚠️ **必须在关闭阅读器之前**：它会顺手把列表钉成 modal
            -- （HANDOVER_PIN_MENU），这样觅阅随后 show 的文件管理器底座、
            -- 以及它 raise 的首页，都只能插到列表下面 —— 见 6e)。
            pcall(Session.armSwipeHandover)
            -- 与阅读器菜单里的「← 返回 IMA 知识库」同一条退出路径，但**延后到
            -- 下一 UI tick**：不能在这里同步 onClose（见文件头 6c）。
            UIManager:nextTick(Session.returnNow)
            -- 无论退出成没成，这一划都算被我们吃掉了：吃掉了最坏是"没反应"，
            -- 吐出去就会同时弹出菜单，那不是用户要的。
            return true
        end
        return original(self, ges)
    end
    menu._ima_swipe_back = true

    logger.info("[ima] 顶部下滑已接管：改为返回知识库列表（顶部点按仍可打开菜单）")
    return true
end

----------------------------------------------------------------
-- 对外入口
----------------------------------------------------------------

--- 阅读器菜单里的「← 返回 IMA 知识库」，以及顶部下滑。
---
--- ⚠️ 刻意**不走** ReaderUI:onHome()（原生 onHome 会 showFileManager(当前文档)，
--- 把 FileManager 拉出来并切到 cache/ima，见文件头 6 与 Session.closeReader）。
--- 只调 onClose：落盘、阅读进度、CloseDocument 事件都在里面，关掉之后露出的
--- 就是压在下面的知识库列表；列表由 reclaim 抬稳。
function Session.returnNow()
    local ok, ReaderUI = pcall(require, "apps/reader/readerui")
    local readerui = ok and ReaderUI.instance or nil
    if not readerui then return false end

    if Session.closeReader(readerui) then return true end

    -- 兜底：onClose 不可用（KOReader 改了接口）时退回原生退出。
    -- 用捕获下来的原生方法，避免撞上 installExitRouting 那层包装。
    local native_home = readerui._ima_native_onHome
    if type(native_home) == "function" and pcall(native_home, readerui) then
        pcall(Session.scheduleReclaim)
        return true
    end
    return false
end

--- 文档加载完成后的收尾。
---
--- 作为 ReaderUI:showReader 的 after_open_callback 传入。
--- 注意此时 ReaderUI.instance 还没赋值（readerui.lua 在回调之后才赋值），
--- 所以实例要靠参数传进来 —— KOReader 是以 self:after_open_callback() 调用的。
function Session.attach(readerui)
    if not state.active then return end
    local ok, err = pcall(Session._attach, readerui)
    if not ok then logger.warn("[ima] 阅读会话初始化失败", tostring(err)) end
end

function Session._attach(readerui)
    Session.liftMiureadHooks(readerui)
    Session.watchClose(readerui)
    Session.installExitRouting(readerui)
    Session.installRotationRestore(readerui)
    Session.enableSwipeBack(readerui)
    Session.enforceContinuousPaging(readerui)
    Session.enforceSeededZoom(readerui)
    Session.enforceSeededRotation(readerui)
    -- 只装一次；语义见函数头（拦下退出余波 + 记录"谁关掉了列表"）。
    Session.installCloseGuard()
    -- 免打扰期内记手势；期外一次比较的开销。
    Session.installGestureProbe()
    Session.hintOnce()

    -- 行网格（见 Session._lineGrid）：这里**同步**把首页算好，宁可在"打开文档"
    -- 这一下多花几十毫秒（用户本来就看着加载画面），也不要让他第一次翻页时卡。
    -- ⚠️ 刻意**不用** UIManager:scheduleIn 预取：那会往全局定时器队列里塞一个
    --    与阅读无关的任务，退出余波那条链（吞划窗口 / 钉顶层）是按队列顺序驱动
    --    的，多一个任务会让它的时序断言与真机行为都偏移一拍。
    -- 失败无所谓：_alignOverlap 在第一次翻页时还会自己取一次。
    if Session.continuousPaging() then
        pcall(Session._lineGrid, readerui)
    end
end

--- 当前「翻页连续」开关状态。
function Session.continuousPaging()
    return Config.get():getBool(CONTINUOUS_SETTING, true)
end

function Session.toggleContinuousPaging()
    local cfg = Config.get()
    local next_value = not cfg:getBool(CONTINUOUS_SETTING, true)
    cfg:setBool(CONTINUOUS_SETTING, next_value)
    return next_value
end

--- 当前「打开文档自动横屏（退出恢复）」开关状态。**默认开**（见 ROTATION_SETTING）。
function Session.autoLandscape()
    return Config.get():getBool(ROTATION_SETTING, true)
end

function Session.toggleAutoLandscape()
    local cfg = Config.get()
    local next_value = not cfg:getBool(ROTATION_SETTING, true)
    cfg:setBool(ROTATION_SETTING, next_value)
    return next_value
end

--- 首次打开提示一次操作方式。
--- 之前「打开后点屏幕顶部弹出来的是觅阅面板」让人以为阅读器坏了，
--- 所以这里明确说一次：翻页键、屏幕两侧、以及**从哪退出**；
--- 顺带指出字号/行距在阅读器的「排版」面板里就能调。
function Session.hintOnce()
    if state.hinted then return end
    state.hinted = true
    UIManager:scheduleIn(1.5, function()
        local ok, Loader = pcall(require, "ima.ui.loader")
        if not ok or type(Loader.notify) ~= "function" then return end
        Loader.notify(
            _("已用 KOReader 原生阅读器打开：翻页键或点屏幕两侧翻页；"
              .. "顶部下滑返回知识库列表；点屏幕顶部可打开阅读器菜单"
              .. "（字号与行距在「排版」里调）。"),
            6)
    end)
end

return Session
