--[[--
腾讯 ima 开放平台接口常量。

接口要点（**均经 2026-10-07 用真实凭证实测确认**）：
  Base URL : https://ima.qq.com
  知识库线 : /openapi/wiki/v1
  协议     : HTTP POST + JSON body
  认证     : 三个请求头，缺一不可
             ima-openapi-clientid
             ima-openapi-apikey
             Content-Type: application/json
  返回     : { code, msg, data }，code == 0 表示成功

  错误信封在非 2xx 时同样带 body，例如凭证无效：
    HTTP 401  {"code":200002,"msg":"skill auth failed"}

  ⚠️ 官方**没有**「列全部知识库」的专用接口（曾误用 get_knowledge_base_list，
     实测 404）。正确做法是 search_knowledge_base 传空 query。

凭证获取：登录 ima 后访问 https://ima.qq.com/agent-interface
--]]--

local _ = require("gettext")

local Constants = {
    API_HOST = "https://ima.qq.com",
    WIKI_V1  = "/openapi/wiki/v1",

    HEADER_CLIENT_ID = "ima-openapi-clientid",
    HEADER_API_KEY   = "ima-openapi-apikey",

    -- 业务错误码
    AUTH_ERROR_CODE = 200002,  -- "skill auth failed"，凭证错或被重置

    -- 游标分页上限。
    --
    -- ⚠️ 各接口**并不统一**，且服务端会硬性拒绝越界值
    --    （code=51 + "value must be inside range (0, N]"），
    --    因此绝不能共用一个数字。以下均为 2026-10-07 实测边界：
    --      search_knowledge_base  limit=20 通过，21 报错 → 上限 20
    --      get_knowledge_list     limit=50 通过，51 报错 → 上限 50
    --      search_knowledge       上限未探测到，取 50
    -- 详见 api.lua 的 call_with_autolimit：越界时会自动按服务端提示重放。
    LIMIT_SEARCH_KB        = 20,  -- 列库 / 搜库（同一接口）
    LIMIT_KNOWLEDGE_LIST   = 50,  -- 浏览目录
    LIMIT_SEARCH_KNOWLEDGE = 50,  -- 库内检索

    DEFAULT_LIMIT = 20,

    -- 网络超时（秒）。块超时用于「等待首包」，总超时用于「收到数据后的累计耗时」。
    BLOCK_TIMEOUT = 15,
    TOTAL_TIMEOUT = 40,

    -- 文件下载单独放宽：正文文件常有几十 MB，按接口超时走必然中途断开。
    DOWNLOAD_BLOCK_TIMEOUT = 20,
    DOWNLOAD_TOTAL_TIMEOUT = 600,

    USER_AGENT = "KOReader-IMA/0.6.20",

    ---------------------------------------------------------------
    -- media_type
    ---------------------------------------------------------------
    -- ✅ 2026-10-07 扫全库 678 条实测确认：
    --      1  = PDF    (media_id 前缀 pdf_)
    --      3  = Word   (word_)
    --      5  = Excel  (excel_)
    --      9  = 图片   (img_)
    --      99 = 文件夹
    --      11 = 笔记（官方接口文档示例明确，本库未出现）
    --
    -- ❓ 其余数值官方未公开映射。**不猜**——查不到就返回 nil，
    --    界面只是不显示类型后缀，不会有错误行为。
    --    （首版曾按顺序硬猜 [4]=Excel、[5]=PPT，实测全错。）
    MEDIA_TYPE_LABEL = {
        [1]  = _("PDF"),
        [3]  = _("Word"),
        [5]  = _("Excel"),
        [9]  = _("图片"),
        [11] = _("笔记"),
        [99] = _("文件夹"),
    },

    FOLDER_MEDIA_TYPE = 99,
    NOTE_MEDIA_TYPE   = 11,

    -- media_id 前缀 → 扩展名。
    -- media_id 形如 "pdf_112331258d95d52ce454b216e93de259_f730d7c1..."，
    -- 下划线前那一段就是格式，比数字枚举更稳定也更可读。
    MEDIA_ID_EXT = {
        pdf    = "pdf",
        word   = "docx",
        excel  = "xlsx",
        ppt    = "pptx",
        img    = "jpeg",
        txt    = "txt",
        md     = "md",
        web    = "html",
        note   = "note",
        folder = "folder",
    },

    -- media_type 数字 → 扩展名（media_id 前缀认不出时的兜底）
    MEDIA_TYPE_EXT = {
        [1] = "pdf",
        [3] = "docx",
        [5] = "xlsx",
    },

    -- KOReader 能直接打开的扩展名。
    -- 用于**下载前**预判：不支持的格式直接给出提示，不白耗流量下载。
    -- 下载完成后仍会用 DocumentRegistry:hasProvider() 做权威确认。
    READABLE_EXT = {
        pdf = true, epub = true, txt = true,
        html = true, htm = true, xhtml = true,
        mobi = true, azw = true, azw3 = true,
        fb2 = true, cbz = true, djvu = true, djv = true, rtf = true,
        jpg = true, jpeg = true, png = true, gif = true,
        bmp = true, webp = true, tif = true, tiff = true,
    },
}

return Constants
