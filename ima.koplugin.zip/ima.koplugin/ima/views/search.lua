--[[--
检索入口。

两种粒度：
  Search.knowledge_base() —— 按名称找知识库（search_knowledge_base）
  Search.within(kb)       —— 在某个知识库内检索内容（search_knowledge）
--]]--

local InputDialog = require("ui/widget/inputdialog")
local UIManager = require("ui/uimanager")
local _ = require("gettext")

local Api = require("ima.api")
local Constants = require("ima.constants")
local Loader = require("ima.ui.loader")
local Models = require("ima.models")

-- 惰性加载，避免 views 之间的循环 require（详见 kb_browser.lua 的说明）
local function KbList()
    return require("ima.views.kb_list")
end

local function KbBrowser()
    return require("ima.views.kb_browser")
end

local Search = {}

--- 弹出输入框，回车或点「搜索」后交给 on_submit
local function prompt(title, hint, on_submit)
    local dialog
    dialog = InputDialog:new{
        title      = title,
        input      = "",
        input_hint = hint,
        buttons    = {
            {
                {
                    text     = _("取消"),
                    id       = "close",
                    callback = function()
                        UIManager:close(dialog)
                    end,
                },
                {
                    text     = _("搜索"),
                    callback = function()
                        local query = dialog:getInputText()
                        UIManager:close(dialog)
                        on_submit(query)
                    end,
                },
            },
        },
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

--- 按名称搜索知识库
function Search.knowledge_base()
    if not Loader.ensureOnline() then return end

    prompt(_("搜索知识库"), _("输入知识库名称或关键词"), function(query)
        local data, err = Loader.run(_("正在检索…"), function()
            return Api.search_knowledge_base(query, "", Constants.LIMIT_SEARCH_KB)
        end)

        if not data then
            Loader.error(err)
            return
        end

        KbList().render(Models.knowledge_bases(data),
            _("搜索结果：") .. query, Models.paging(data))
    end)
end

--- 在指定知识库内检索内容
function Search.within(kb)
    if not Loader.ensureOnline() then return end

    prompt(kb.name .. " · " .. _("搜索"), _("输入关键词"), function(query)
        local data, err = Loader.run(_("正在检索…"), function()
            return Api.search_knowledge(kb.id, query, "", Constants.LIMIT_SEARCH_KNOWLEDGE)
        end)

        if not data then
            Loader.error(err)
            return
        end

        KbBrowser().render(kb, Models.media_entries(data),
            _("搜索结果：") .. query)
    end)
end

return Search
