--[[--
「点开条目 → 在线阅读」的编排。

流程：
  1. 查缓存 —— 命中直接交给阅读器（秒开）
  2. 未命中 → get_media_info 取临时下载地址
  3. 下载到 cache/ima（带进度提示）
  4. ReaderUI:showReader(path) 交给 KOReader 打开

**格式预判放在最前面**：Word / Excel 这类 KOReader 没有 provider 的格式，
直接如实告知，而不是先下几十 MB 再报错。

同步说明：下载是同步阻塞的（Lua 单线程 + KOReader 的主循环模型），
所以下载期间界面收不到输入，也就**没法中途取消**。
兜底靠的是 constants 里的 DOWNLOAD_TOTAL_TIMEOUT。

打开前后各有一处交接，见 ima/reader_session.lua：
  · prepare —— 写文档默认阅读设置（PDF 整页显示）并把本次标记为 IMA 会话；
  · attach（after_open_callback）—— 摘掉觅阅对阅读器的接管，退出后把列表抬回来。
--]]--

local util      = require("util")
local _         = require("gettext")

local Downloader = require("ima.downloader")
local Loader     = require("ima.ui.loader")
local Models     = require("ima.models")
local Session    = require("ima.reader_session")

local Reader = {}

--- 交给 KOReader 打开本地文件。
--- @param path 本地文件路径（已确认存在）
local function openLocal(path)
    local ok_req, ReaderUI = pcall(require, "apps/reader/readerui")
    if not ok_req or type(ReaderUI) ~= "table" then
        Session.abort()
        Loader.error(_("当前 KOReader 没有提供阅读器接口，无法打开文件。"))
        return false
    end

    -- after_open_callback 会在文档加载完成、ReaderUI.instance 赋值之前被调用，
    -- 实例由 KOReader 作为第一个参数传进来（readerui.lua 里是 self:after_open_callback()）。
    local ok, err = pcall(function()
        ReaderUI:showReader(path, nil, nil, nil, Session.attach)
    end)

    if not ok then
        Session.abort()
        Loader.error(_("打开文件失败：") .. tostring(err))
        return false
    end
    return true
end

--- 标题过长会撑爆提示框，按 UTF-8 安全截断
local function shortTitle(title)
    return Models.truncate_utf8(tostring(title or ""), 60)
end

--- 是否该当作「笔记」处理。
--- 笔记没有文件扩展名，走 note 线读正文，而不是下载文件。
local function isNote(entry, ext)
    return entry.is_note == true or ext == nil or ext == "note"
end

--- 点开一个条目：优先读缓存，其次下载，最后交给阅读器。
function Reader.open(entry)
    if type(entry) ~= "table" or not entry.id then return end
    if not Loader.ensureOnline() then return end

    local ext   = Models.file_extension(entry)
    local note  = isNote(entry, ext)

    -- 格式预判：KOReader 打不开的格式不下载，省流量也省等待
    if not note and not Models.is_readable_ext(ext) then
        Loader.info(string.format(
            _("「%s」\n\n格式为 %s，KOReader 无法直接打开这类文件。\n\n"
              .. "可以回到 ima 客户端或网页端查看。"),
            shortTitle(entry.title),
            string.upper(tostring(ext))))
        return
    end

    -- 1. 缓存命中 → 秒开
    local cached = Downloader.cachedPath(entry)
    if cached then
        Session.prepare(cached)
        openLocal(cached)
        return
    end

    -- 2. 取地址 + 下载，期间持续更新进度
    local dialog = Loader.progress(
        string.format(_("正在获取「%s」…"), shortTitle(entry.title)))

    local path, err = Downloader.ensureLocal(entry, function(bytes)
        dialog.setText(string.format(
            _("正在下载「%s」…\n\n已下载 %s"),
            shortTitle(entry.title),
            util.getFriendlySize(bytes)))
    end)

    dialog.close()

    if not path then
        Loader.error(err, _("无法打开："))
        return
    end

    Session.prepare(path)
    openLocal(path)
end

return Reader
