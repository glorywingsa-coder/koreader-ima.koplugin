--[[--
知识库内容浏览视图：目录逐层进入，点条目在线阅读。

分页：get_knowledge_list 的 limit 上限是 50，而知识库内容常有数百条
（实测某个人知识库 content_count = 678），因此列表末尾会补
「加载更多…」，用 next_cursor 续取，并累积到当前列表。

⚠️ 循环变量**绝不能用 `_`**。
`_` 在本文件顶部是 gettext 的翻译函数（local _ = require("gettext")），
写成 `for _, entry in ipairs(...)` 会把它覆盖成数字下标，此后循环体内
任何 `_("...")` 都会以
    attempt to call upvalue '_' (a number value)
直接崩掉 KOReader —— 这正是 v0.4.0「点文件就崩溃」的根因。
--]]--

local _ = require("gettext")

local Api       = require("ima.api")
local Constants = require("ima.constants")
local Loader    = require("ima.ui.loader")
local Imenu     = require("ima.ui.menu")
local Models    = require("ima.models")

-- 注意：views 之间存在互相引用（列表 → 浏览 → 检索 → 列表）。
-- LuaJIT 的 require 没有「加载中」标记，顶层互引会无限递归，
-- 因此凡是构成环的依赖一律改为函数内惰性 require。
local function SearchView()
    return require("ima.views.search")
end

local function ReaderView()
    return require("ima.views.reader")
end

local KbBrowser = {}

local function entry_text(entry)
    local label  = Models.media_type_label(entry.media_type)
    local prefix = entry.is_folder and "▸ " or ""
    local suffix = label and ("  ·  " .. label) or ""
    return prefix .. entry.title .. suffix
end

local function fetch(kb, folder_id, cursor)
    return Loader.run(_("正在读取目录…"), function()
        return Api.get_knowledge_list(kb.id, folder_id, cursor,
            Constants.LIMIT_KNOWLEDGE_LIST)
    end)
end

--- 渲染已取到的条目列表
--- @param kb        知识库 { id, name }
--- @param entries   累积的条目数组
--- @param title     标题栏文案（nil 时用 kb.name）
--- @param folder_id 当前目录 id（根目录为 nil）
--- @param more      可选 { next_cursor = "..." }，非 nil 时末尾追加「加载更多…」
function KbBrowser.render(kb, entries, title, folder_id, more)
    local item_table = {}

    item_table[#item_table + 1] = {
        text     = _("搜索此知识库…"),
        callback = function()
            SearchView().within(kb)
        end,
    }

    if folder_id then
        item_table[#item_table + 1] = {
            text     = _("← 返回上一级"),
            callback = function()
                KbBrowser.show(kb)
            end,
        }
    end

    if #entries == 0 then
        item_table[#item_table + 1] = Imenu.note(_("（空目录）"))
    else
        for i, entry in ipairs(entries) do
            local item = { text = entry_text(entry) }

            if entry.is_folder then
                item.callback = function()
                    KbBrowser.show(kb, entry.id, entry.title)
                end
            else
                item.callback = function()
                    ReaderView().open(entry)
                end
            end

            item_table[#item_table + 1] = item
        end
    end

    if more and more.next_cursor ~= "" then
        item_table[#item_table + 1] = {
            text     = _("加载更多…"),
            callback = function()
                local data, err = fetch(kb, folder_id, more.next_cursor)
                if not data then
                    Loader.error(err)
                    return
                end
                local merged = {}
                for i = 1, #entries do merged[#merged + 1] = entries[i] end
                for i, e in ipairs(Models.media_entries(data)) do
                    merged[#merged + 1] = e
                end
                KbBrowser.render(kb, merged, title, folder_id, Models.paging(data))
            end,
        }
    end

    Imenu.show(title or kb.name, item_table)
end

--- 拉取并展示某目录下的内容（从第一页开始）
--- @param kb        知识库 { id, name }
--- @param folder_id 可选，进入子目录时传该目录的 media_id
--- @param title     可选，标题栏文案
function KbBrowser.show(kb, folder_id, title)
    if not Loader.ensureOnline() then return end

    local data, err = fetch(kb, folder_id, "")

    if not data then
        Loader.error(err)
        return
    end

    KbBrowser.render(kb, Models.media_entries(data), title, folder_id,
        Models.paging(data))
end

return KbBrowser
