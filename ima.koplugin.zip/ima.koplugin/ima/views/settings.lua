--[[--
设置与凭证视图。

这些入口原先挂在 KOReader 原生主菜单的「IMA 知识库」二级菜单里。
为了让「点一下 IMA 知识库就直接进列表」，它们被挪进列表界面内部
（见 ima/views/kb_list.lua 顶部的「设置与凭证」），本模块只负责各自的对话框。

本模块不依赖插件实例，可以独立 require；也不参与 views 之间的循环依赖。
--]]--

local InfoMessage = require("ui/widget/infomessage")
local UIManager = require("ui/uimanager")
local util = require("util")
local _ = require("gettext")

local Config = require("ima.config")
local Constants = require("ima.constants")
local Imenu = require("ima.ui.menu")
local Loader = require("ima.ui.loader")
local Util = require("ima.util")

-- 惰性 require：reader_session 是本插件的阅读会话层，本模块只在真的用到
-- 版面设置时才把它拉进来，避免设置界面在文件管理器里被 require 时就带上它。
local function Session()
    return require("ima.reader_session")
end

local Settings = {}

local PLUGIN_VERSION = "0.6.20"

function Settings.showCredentialDialog()
    local MultiInputDialog = require("ui/widget/multiinputdialog")
    local cfg = Config.get()
    local dialog
    dialog = MultiInputDialog:new{
        title = _("IMA 开放平台凭证"),
        fields = {
            {
                description = _("Client ID"),
                text        = cfg:getClientId(),
                hint        = "ima-openapi-clientid",
            },
            {
                description = _("API Key"),
                text        = cfg:getApiKey(),
                hint        = "ima-openapi-apikey",
            },
        },
        buttons = {
            {
                {
                    text     = _("取消"),
                    id       = "close",
                    callback = function()
                        UIManager:close(dialog)
                    end,
                },
                {
                    text     = _("保存"),
                    callback = function()
                        local fields = dialog:getFields()
                        local client_id = Util.trim(fields[1] or "")
                        local api_key = Util.trim(fields[2] or "")

                        if client_id == "" or api_key == "" then
                            UIManager:show(InfoMessage:new{
                                text    = _("Client ID 与 API Key 都不能为空。"),
                                timeout = 3,
                            })
                            return
                        end

                        cfg:setCredentials(client_id, api_key)
                        UIManager:close(dialog)
                        Loader.notify(_("凭证已保存"))
                    end,
                },
            },
        },
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

function Settings.showCredentialInfo()
    local cfg = Config.get()
    local text
    if cfg:hasCredentials() then
        text = _("已配置凭证") .. "\n\n"
            .. "Client ID: " .. Util.mask_secret(cfg:getClientId()) .. "\n"
            .. "API Key: " .. Util.mask_secret(cfg:getApiKey()) .. "\n\n"
            .. _("存放位置：") .. "\n" .. cfg:getSettingsFilePath()
    else
        text = _("尚未配置凭证。") .. "\n\n"
            .. _("请在电脑上安装 ima 客户端并用微信登录，"
                .. "再于其头像 → CLAW 配置 (beta) 获取 API Key；"
                .. "或访问 https://ima.qq.com/agent-interface。")
    end
    UIManager:show(InfoMessage:new{ text = text })
end

function Settings.confirmClearCredentials()
    if not Config.get():hasCredentials() then
        Loader.notify(_("当前没有已保存的凭证"))
        return
    end
    UIManager:show(require("ui/widget/confirmbox"):new{
        text        = _("确定要清除已保存的 IMA 凭证吗？"),
        ok_text     = _("清除"),
        ok_callback = function()
            Config.get():clearCredentials()
            Loader.notify(_("凭证已清除"))
        end,
    })
end

--- 把接口的原始 JSON 摊开给用户看，用于核对响应字段。
--- 不同账号 / 不同版本下接口返回的层级可能有差异，
--- 看清真实结构后到 ima/models.lua 里补精确分支即可。
function Settings.showRawResponse()
    if not Loader.ensureOnline() then return end

    local Api = require("ima.api")
    local json = require("json")

    local data, err, raw = Loader.run(_("正在请求…"), function()
        return Api.list_knowledge_bases("", Constants.LIMIT_SEARCH_KB)
    end)

    local text
    if raw ~= nil then
        local ok, encoded = pcall(json.encode, raw)
        text = ok and encoded or tostring(raw)
    elseif data ~= nil then
        local ok, encoded = pcall(json.encode, data)
        text = ok and encoded or tostring(data)
    else
        text = _("请求失败：") .. tostring(err)
    end

    local ok_tv, TextViewer = pcall(require, "ui/widget/textviewer")
    if ok_tv and TextViewer then
        UIManager:show(TextViewer:new{
            title = "search_knowledge_base",
            text  = text,
        })
    else
        UIManager:show(InfoMessage:new{ text = text, timeout = 10 })
    end
end

function Settings.showAbout()
    UIManager:show(InfoMessage:new{
        text = _("IMA 知识库 · v") .. PLUGIN_VERSION .. "\n\n"
            .. _("通过腾讯 ima 官方开放平台接口，浏览与检索个人知识库。") .. "\n\n"
            .. _("本版已实现：") .. "\n"
            .. _("· 浏览知识库列表与目录") .. "\n"
            .. _("· 按名称搜索知识库") .. "\n"
            .. _("· 在知识库内检索内容") .. "\n"
            .. _("· 点条目在线阅读（PDF / 图片等 KOReader 支持的格式）") .. "\n"
            .. _("· 笔记正文读取") .. "\n"
            .. _("· 阅读器用 KOReader 原生界面：物理翻页键、点按翻页、字体排版、"
                .. "阅读器菜单全部可用；退出即回到知识库列表") .. "\n"
            .. _("· 翻页不切断文字：按文档真实行位置对齐，屏幕底部总收在整行上") .. "\n"
            .. _("· 打开文档自动横屏（正文放大 1.33×），退出阅读自动恢复竖屏") .. "\n"
            .. _("· 阅读界面顶部下滑返回知识库列表（与列表里的下滑手势一致；"
                .. "顶部点按仍可打开阅读器菜单）") .. "\n"
            .. _("· 退出阅读器只关阅读器，不会闪出 KOReader 的文件列表") .. "\n"
            .. _("· 不替用户改版面：文档按 KOReader 默认缩放打开") .. "\n"
            .. _("· PDF 是固定版面：不开「重排」时字号/行距调不了、调了也不生效，"
                .. "阅读器「排版」里那一项就是灰的") .. "\n\n"
            .. _("凭证获取：https://ima.qq.com/agent-interface"),
    })
end

--- 清理本地下载缓存。
--- 正文文件会长期占用存储，Kobo 的可用空间通常只有几百 MB，
--- 所以给一个明确的出口，而不是让用户去翻隐藏目录。
function Settings.confirmClearCache()
    local Downloader = require("ima.downloader")
    local count, bytes = Downloader.cacheUsage()

    if count == 0 then
        Loader.notify(_("下载缓存是空的"))
        return
    end

    UIManager:show(require("ui/widget/confirmbox"):new{
        text = string.format(
            _("本地已缓存 %d 个文件，共占用 %s。\n\n确定要全部删除吗？"),
            count, util.getFriendlySize(bytes)),
        ok_text     = _("删除"),
        ok_callback = function()
            local removed = Downloader.clearCache()
            Loader.notify(string.format(_("已删除 %d 个缓存文件"), removed))
        end,
    })
end

--- 「设置与凭证」子菜单的条目。
--- 交给 kb_list 的 Menu 作为 sub_item_table 使用（Menu 支持 sub_item_table，
--- 点击会进入子菜单，标题栏关闭按钮经 Menu:onClose 自动退回父菜单）。
--- 注意这里不能用 keep_menu_open —— 那是 TouchMenu 的属性，Menu 不支持。
---
--- 用 mandatory_func 显示当前值的条目要**平铺**在这里而不是塞进子菜单：
--- Imenu.refresh() 认的是最近一次 show 出来的那个 Menu（last_menu），
--- 子菜单不是走 Imenu.show 建的，在里面改完值刷新不到自己，右栏会一直显示旧值。
function Settings.menu_items()
    return {
        {
            text     = _("配置凭证"),
            callback = Settings.showCredentialDialog,
        },
        {
            text     = _("查看当前凭证"),
            callback = Settings.showCredentialInfo,
        },
        {
            text     = _("清除凭证"),
            callback = Settings.confirmClearCredentials,
        },
        {
            -- 只留「版面」这一轴（缩放），不再提供任何字号/行距设置：
            -- PDF 上「能调字号」等价于「打开重排」，而重排在本库文档上实测
            -- 又慢（56 秒）又把中文排成满屏空格（原因见 reader_session 文件头）。
            -- 默认「跟随系统默认」= 一个 zoom 键都不写，跟平时读书完全一致。
            -- ⚠️ 别写「要放大正文用阅读器『排版』面板」：那一项（字号/行距/
            --    字距/对齐）的 enabled_func 是 enableIfEquals(configurable,
            --    "text_wrap", 1)，而我们每次都写 kopt_text_wrap = 0 ⇒ 它永远是
            --    灰的、而且是 1.0（键被删掉后回落到 DKOPTREADER_CONFIG_FONT_SIZE）。
            --    固定版面 PDF 上放大的手段只有「横屏」（视口变宽 ⇒ zoom 变大）这一条。
            text           = _("打开文档时的版面"),
            mandatory_func = function()
                return Session().zoomLabel()
            end,
            callback = function()
                local choice = Session().cycleZoom()
                -- Menu 不会因为 callback 而自己刷新，得手动让它重算一遍，
                -- 否则右边那栏还显示着旧值。
                Imenu.refresh()
                Loader.notify(string.format(
                    _("已改为「%s」，下次打开文档生效"), Session().zoomLabel(choice)))
            end,
        },
        {
            -- v0.6.2 修的是「翻页时有一部分内容和上一页重复」；v0.6.17 修它的**反面**
            -- （重叠归零 ⇒ 跨越屏底的那一行被切成两半）；v0.6.19 起改成真正的解 ——
            -- 不再假设"一行有多高"，而是用文档自己的行坐标，让每次翻页后的屏幕底部
            -- 落在某个行顶上，于是屏底那一行永远完整、重复量又最小。
            -- v0.6.20 修掉 v0.6.19 上机无效的根因（滚动位置取错了字段）并补上
            -- 「上一屏被切掉的那一行必须被下一屏救回来」。
            -- 原理与两版走弯路的记录见 reader_session.lua 文件头 1b / 1c。
            text           = _("翻页不切断文字（自动对齐整行）"),
            mandatory_func = function()
                return Session().continuousPaging() and _("开") or _("关")
            end,
            callback = function()
                local on = Session().toggleContinuousPaging()
                Imenu.refresh()
                Loader.notify(on
                    and _("已开启：翻页后屏幕底部正好收在整行，底部的字不会被切成两半")
                    or _("已关闭：恢复 KOReader 原生的页间重叠"))
            end,
        },
        {
            -- 修的是「阅读界面从上往下滑弹出的是 KOReader 设置界面」。
            -- KOReader 原生把屏幕顶部条带的下滑绑成「打开菜单」，而知识库列表里
            -- 下滑是「返回上一层」，同一个手势两处含义相反。开这一项后，
            -- IMA 打开的文档里顶部下滑也变成「返回知识库列表」。
            -- 顶部**点按**打开阅读器菜单不受影响。
            text           = _("阅读界面顶部下滑 = 返回列表"),
            mandatory_func = function()
                return Session().swipeBackEnabled() and _("开") or _("关")
            end,
            callback = function()
                local on = Session().toggleSwipeBack()
                Imenu.refresh()
                Loader.notify(on
                    and _("已开启：阅读界面顶部下滑返回知识库列表（顶部点按仍可打开菜单）")
                    or _("已关闭：恢复 KOReader 默认的顶部下滑打开菜单"))
            end,
        },
        {
            -- 不重排也能放大正文的唯一手段（见 reader_session.lua 的 ROTATION_SETTING）。
            -- 竖屏 contentwidth 的缩放只有 2.113（18pt 正文等效 9.13pt），横屏 2.809
            -- → 12.14pt，正好 1.33×。走 KOReader 自己的**文档级**旋转，所以只影响
            -- 这个知识库里的文档，别的书一点不受影响；退出后屏幕恢复原样。
            text           = _("打开文档自动横屏（退出恢复）"),
            mandatory_func = function()
                return Session().autoLandscape() and _("开") or _("关")
            end,
            callback = function()
                local on = Session().toggleAutoLandscape()
                Imenu.refresh()
                Loader.notify(on
                    and _("已开启：IMA 文档以横屏打开（正文放大 1.33×），退出后屏幕恢复")
                    or _("已关闭：文档按 KOReader 原生的旋转设置打开"))
            end,
        },
        {
            text     = _("清理下载缓存"),
            callback = Settings.confirmClearCache,
        },
        {
            text     = _("调试：查看接口原始响应"),
            callback = Settings.showRawResponse,
        },
        {
            text     = _("关于 IMA 知识库"),
            callback = Settings.showAbout,
        },
    }
end

return Settings
