--[[--
知识库列表视图。

这是插件的**一级界面**：从 KOReader 主菜单或觅阅首页点「IMA 知识库」
会直接落到这里，因此「搜索」与「设置与凭证」都放在列表顶部的工具栏，
不必再回 KOReader 主菜单里翻找。

分页：官方 limit 上限 50，而知识库/目录内容可能远超此数，
因此列表末尾会补一条「加载更多…」，用 next_cursor 续取。
--]]--

local UIManager = require("ui/uimanager")
local _ = require("gettext")

local Api = require("ima.api")
local Config = require("ima.config")
local Constants = require("ima.constants")
local Loader = require("ima.ui.loader")
local Imenu = require("ima.ui.menu")
local Models = require("ima.models")
local Settings = require("ima.views.settings")

local KbBrowser = require("ima.views.kb_browser")

-- 惰性加载：kb_list → kb_browser → search → kb_list 构成环，
-- 而 LuaJIT 的 require 没有「加载中」哨兵，顶层互引会无限递归。
-- 因此凡是构成环的依赖一律改为函数内 require（详见 kb_browser.lua 的说明）。
local function SearchView()
    return require("ima.views.search")
end

local KbList = {}

--- 列表顶部的固定入口。
--- 「设置与凭证」用 sub_item_table 做成子菜单：frontend/ui/widget/menu.lua 支持
--- 该字段（Menu:onMenuSelect 会 switchItemTable 进入子菜单），并且标题栏关闭
--- 按钮经 Menu:onClose 自动退回父菜单，不需要自己写「返回上一级」。
--- 注意不能用 keep_menu_open —— 那是 TouchMenu 的属性，Menu 不支持。
local function toolbar_items()
    return {
        {
            text     = _("搜索知识库…"),
            callback = function()
                SearchView().knowledge_base()
            end,
        },
        {
            text           = _("设置与凭证"),
            mandatory      = Config.get():hasCredentials() and _("已配置") or _("未配置"),
            sub_item_table = Settings.menu_items(),
        },
    }
end

--- 取一页知识库列表。cursor 传 "" 即第一页。
local function fetch_page(cursor)
    return Loader.run(_("正在读取知识库列表…"), function()
        return Api.list_knowledge_bases(cursor, Constants.LIMIT_SEARCH_KB)
    end)
end

--- 渲染一批知识库。已按名称排序。
--- @param kbs   array of { id, name, base_type, role_type }
--- @param title 标题栏文案（nil 时用默认）
--- @param more  可选 { next_cursor = "..." }，非 nil 时末尾追加「加载更多…」
function KbList.render(kbs, title, more)
    local item_table = toolbar_items()

    if #kbs == 0 then
        item_table[#item_table + 1] = Imenu.note(_("没有匹配的知识库"))
    else
        table.sort(kbs, function(a, b)
            return (a.name or "") < (b.name or "")
        end)
        for i, kb in ipairs(kbs) do
            local label = Models.kb_type_label(kb.base_type)
            item_table[#item_table + 1] = {
                text     = kb.name .. (label and ("  ·  " .. label) or ""),
                callback = function()
                    KbBrowser.show(kb)
                end,
            }
        end
    end

    if more and more.next_cursor ~= "" then
        item_table[#item_table + 1] = {
            text     = _("加载更多…"),
            callback = function()
                local data, err = fetch_page(more.next_cursor)
                if not data then
                    Loader.error(err)
                    return
                end
                -- 续取到的结果追加到当前列表后重新渲染
                local merged = {}
                for i = 1, #kbs do merged[#merged + 1] = kbs[i] end
                for i, kb in ipairs(Models.knowledge_bases(data)) do
                    merged[#merged + 1] = kb
                end
                KbList.render(merged, title, Models.paging(data))
            end,
        }
    end

    Imenu.show(title or _("IMA 知识库"), item_table)
end

--- 首次使用直接落到列表页时，先把用户引到凭证配置，而不是甩一个接口报错。
local function prompt_configure()
    UIManager:show(require("ui/widget/confirmbox"):new{
        text = _("尚未配置 IMA 凭证。") .. "\n\n"
            .. _("请在电脑上安装 ima 客户端并用微信登录，"
                .. "再于其头像 → CLAW 配置 (beta) 获取 API Key；"
                .. "或访问 https://ima.qq.com/agent-interface。"),
        ok_text     = _("去配置"),
        ok_callback = function()
            Settings.showCredentialDialog()
        end,
    })
end

--- 拉取并展示全部知识库
function KbList.show()
    if not Config.get():hasCredentials() then
        prompt_configure()
        return
    end

    if not Loader.ensureOnline() then return end

    local data, err = fetch_page("")

    if not data then
        Loader.error(err)
        return
    end

    KbList.render(Models.knowledge_bases(data), nil, Models.paging(data))
end

return KbList
