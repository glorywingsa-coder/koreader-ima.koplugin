--[[--
界面侧的通用辅助：加载提示、联网检查、提示条。

关于「同步请求」：ima 的接口是普通 REST，一次往返很快，骨架阶段直接用同步
请求即可。为了让用户看到反馈，请求前先 show 一个 InfoMessage 并强制重绘
——否则 UIManager 要等主循环下一帧才画，界面会「假死」。
后续若接入大文件下载或长文档分片读取，再换成 UIManager:nextTick + 后台任务。
--]]--

local InfoMessage = require("ui/widget/infomessage")
local Notification = require("ui/widget/notification")
local UIManager = require("ui/uimanager")
local NetworkMgr = require("ui/network/manager")
local _ = require("gettext")

local Loader = {}

--- 联网检查。未联网时提示用户，返回 false。
function Loader.ensureOnline()
    if NetworkMgr:isConnected() then
        return true
    end
    UIManager:show(Notification:new{
        text = _("需要先连接 Wi-Fi"),
        timeout = 3,
    })
    return false
end

--- 执行一次同步请求，期间显示等待提示。
--- fn 需返回 (data, err[, extra])。返回值原样透传，extra 用于调试时取原始结构。
function Loader.run(waiting_text, fn)
    local info = InfoMessage:new{
        text = waiting_text or _("正在连接 IMA…"),
    }
    UIManager:show(info)
    UIManager:forceRePaint()

    local ok, data, err, extra = pcall(fn)

    UIManager:close(info)

    if not ok then
        return nil, tostring(data)
    end
    return data, err, extra
end

function Loader.notify(text, timeout)
    UIManager:show(Notification:new{
        text = text,
        timeout = timeout or 3,
    })
end

function Loader.error(err, prefix)
    UIManager:show(InfoMessage:new{
        text = (prefix or _("IMA 请求失败：")) .. tostring(err or _("未知错误")),
        timeout = 4,
    })
end

function Loader.info(text)
    UIManager:show(InfoMessage:new{ text = text })
end

--- 可更新的等待提示框，用于下载这种要持续给反馈的场景。
---
--- 注意：InfoMessage 在 init 时就把 self.text 渲染成了内部的 text_widget，
--- 所以**改 self.text 没有用**，必须改 text_widget 再标脏重绘。
--- setText 用 pcall 包住：控件实现在不同 KOReader 版本间有差异，
--- 更新失败最多是文案不刷新，绝不能因此把下载链路带崩。
--- @return { setText = function(text), close = function() }
function Loader.progress(text)
    local info = InfoMessage:new{ text = text or _("正在处理…") }
    UIManager:show(info)
    UIManager:forceRePaint()

    local dialog = { closed = false }

    function dialog.setText(new_text)
        if dialog.closed or not info.text_widget then return end
        pcall(function()
            info.text_widget:setText(new_text)
            UIManager:setDirty(info, "ui")
        end)
    end

    function dialog.close()
        if dialog.closed then return end
        dialog.closed = true
        UIManager:close(info)
    end

    return dialog
end

return Loader
