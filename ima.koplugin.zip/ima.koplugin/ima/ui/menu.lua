--[[--
通用列表菜单。

KOReader 的 Menu 在选中条目时会自动调用 item.callback（见
frontend/ui/widget/menu.lua 的 Menu:onMenuChoice），因此只要往 item_table
里塞 { text = ..., callback = ... } 就够了。

另外两件与「阅读器退出后回到列表」有关的小事放在这里：

  · show 时把控件登记进 ima.reader_session —— 阅读器关闭后要抬回顶层；
  · raise 把已经在窗口栈里的控件重新抬到最上层。

为什么需要 raise：从列表点开文档后，列表控件会一直留在窗口栈里
（KOReader 自己也是如此：ui/widget/menu.lua 里专门有 Menu:onShowingReader
钩子在阅读器接管时清理菜单的刷新状态）。等阅读器关闭时，觅阅会把它的
停靠首页重新抬起来，于是列表被盖到了下面——raise 就是把位置抢回来的那一步。
--]]--

local Menu = require("ui/widget/menu")
local UIManager = require("ui/uimanager")

-- 惰性 require：reader_session 会反过来用本模块的 raise，
-- 顶层互引在 LuaJIT 下没有「加载中」哨兵，会无限递归。
local function Session()
    return require("ima.reader_session")
end

local Imenu = {}

--- 最近一次 show 出来的列表。用于 Imenu.refresh()。
local last_menu

--- 本模块创建过、且当前仍在窗口栈里的列表（顺序 = 创建顺序）。
---
--- reader_session 需要它做三件事（v0.6.16 起）：
---   ① 「退出余波免打扰」期内把它们**全部**钉成 `modal`。只钉最上面那层是不够的：
---      插栈规则（uimanager.lua:186-199）会把觅阅补回的 KOReader 文件管理器放到
---      那层列表**之下**，而更下一层的列表仍压在它下面 —— 于是"关掉文档列表、
---      露出知识库用户界面"这一步会先露出 cache/ima（用户报的"闪现一下缓存列表"）。
---   ② 判断"这个控件是不是我们自己的列表"（`is_foreign_overlay` / 关闭闸口都要
---      排除它们，否则被钉成 modal 的列表会把自己判成"该让位的模态对话框"→ 自锁死）。
---   ③ 关掉列表前把夹在窗口栈里的缓存列表清干净（见 reader_session 的关闭闸口）。
local live = {}

--- 当前仍在窗口栈里的列表（顺手把已经关掉的从登记表里摘掉）。
--- @return array
function Imenu.menus()
    local kept, out = {}, {}
    for i = 1, #live do
        local item = live[i]
        if item and UIManager:isWidgetShown(item) then
            kept[#kept + 1] = item
            out[#out + 1] = item
        end
    end
    live = kept
    return out
end

--- 这个控件是不是本模块创建的列表。
--- @return boolean
function Imenu.isOurs(widget)
    if widget == nil then return false end
    for i = 1, #live do
        if live[i] == widget then return true end
    end
    return false
end

--- @param title      标题栏文案
--- @param item_table Menu 条目数组
--- @param opts       可选：{ on_close = function }
function Imenu.show(title, item_table, opts)
    opts = opts or {}
    local menu
    menu = Menu:new{
        title               = title,
        item_table          = item_table,
        covers_fullscreen   = true,
        is_borderless       = true,
        is_popout           = false,
        title_bar_fm_style  = true,
    }
    -- 识别「用户主动关闭列表」，依据是 KOReader Menu 的两条调用路径：
    --   · Menu:onCloseAllMenus（用户下滑 / 点 X / 点外部）——**先**
    --     UIManager:close(self) 把菜单摘出窗口栈，**后**调 close_callback，
    --     所以回调跑到这里时菜单必然已不在窗口栈里；
    --   · Menu:onMenuSelect（menu.lua:1374-1377，选中普通条目）——先跑
    --     条目自己的 callback（打开文档 / 进下一层），**后**调 close_callback，
    --     但菜单**没有关、还留在窗口栈里**。
    -- 只认前者：v0.6.11/0.6.12 不加区分，结果「从列表点开文档」也被记成
    -- 「用户主动关闭」，user_closed 被置位并毒死整场阅读的抬回守护 ——
    -- 退出后列表永远不回来（v0.6.13 修复，见 reader_session.lua 文件头 6c）。
    -- opts.on_close 维持无条件调用（历史上它就一直会在选中条目时触发）。
    local on_close = opts.on_close
    menu.close_callback = function()
        if not UIManager:isWidgetShown(menu) then
            pcall(function() Session().noteMenuClosed(menu) end)
        end
        if type(on_close) == "function" then return on_close() end
    end

    -- 手势免打扰窗（见 reader_session.lua 6d) 与 Session.swallowHandoverSwipe）：
    -- 「顶部下滑 = 返回列表」把阅读器关掉之后约 1 秒，还会飘来**第二个 south
    -- swipe**（实测三轮，调用栈 `sendEvent → 列表 handleEvent → Menu:onSwipe
    -- → onClose` —— 是一条独立的新输入事件）。KOReader 的 `Menu:onSwipe`
    -- （widget/menu.lua:1492-1497，`no_title == false` 时 south → `self:onClose()`）
    -- 会把它当「返回上一层」，于是刚露出的**文档列表**被关掉、只剩下一层
    -- 知识库列表 —— 用户看到的就是"始终没出现文档列表"。
    --
    -- 这里只包**实例**方法，且只在窗口内拦截：窗口一过原样交回原生实现，
    -- 用户之后主动下滑退出列表的手感分毫不变。
    local native_swipe = menu.onSwipe
    if type(native_swipe) == "function" then
        menu.onSwipe = function(self, arg, ges_ev)
            local ok, swallowed = pcall(function()
                return Session().swallowHandoverSwipe(ges_ev and ges_ev.direction)
            end)
            if ok and swallowed then return true end
            -- 交回原生实现。它里面的 `self:onNextPage()` / `self:onPrevPage()`
            -- 是**动态**查找，会命中下面那两个实例包装 ⇒ 「不环绕」自动生效。
            return native_swipe(self, arg, ges_ev)
        end
    end

    -- ⚠️ **分页不许环绕**（v0.6.20）。
    --
    -- KOReader 的 `Menu:onNextPage/onPrevPage`（widget/menu.lua:1405-1413）是**环形**的：
    --     onPrevPage:  self.page > 1 and self.page - 1 or self.page_num
    -- 于是在**第 1 页**向右划一下，会直接跳到**最后一页**。
    --
    -- 这不是理论问题，是用户实测报上来的「从文档退出总是退到文档列表的最后一页」。
    -- 设备日志（手势探针）里两条全部吻合：
    --     10:05:31  dir=east dist=450.02 pos=35,855   顶层=0x6eb64ae8
    --     10:06:42  dir=east dist=332.27 pos=43,962   顶层=0x6eb64ae8   ← 文档列表
    -- 两次都紧跟在「从文档退出」之后约 1 秒，方向都是 east、起点都贴着屏幕左缘。
    -- 而 `Session.swallowHandoverSwipe` 只吞 `south`（reader_session.lua 里那行
    -- `if flipped ~= "south" then return false end`），这一划原样落到 `Menu:onSwipe`
    -- → `onPrevPage()` → 第 1 页 → `page_num`，列表就"永远停在最后一页"。
    --
    -- 只包实例方法，不动类方法、不碰别的菜单：到边界就什么也不做，
    -- 既不跳页也不报错。翻页改用底部的左右箭头按钮（page_info 那一行），照常可用。
    local native_prev = menu.onPrevPage
    if type(native_prev) == "function" then
        menu.onPrevPage = function(self, ...)
            if type(self.page) ~= "number" or self.page <= 1 then return true end
            return native_prev(self, ...)
        end
    end
    local native_next = menu.onNextPage
    if type(native_next) == "function" then
        menu.onNextPage = function(self, ...)
            if type(self.page) ~= "number"
                or (type(self.page_num) == "number" and self.page >= self.page_num) then
                return true
            end
            return native_next(self, ...)
        end
    end

    UIManager:show(menu)
    last_menu = menu
    -- 登记进「我们自己还活着的列表」——必须在 UIManager:show 之后，
    -- 因为 Imenu.menus() 用 isWidgetShown 过滤。
    live[#live + 1] = menu

    pcall(function()
        Session().rememberMenu(menu)
    end)

    return menu
end

--- 重新渲染当前列表。
---
--- 给「就地改值」的条目用：Menu:onMenuChoice 只会调用 callback，并不会刷新
--- 自己（这一点和 TouchMenu 的 keep_menu_open 不同），所以像「打开文档时的
--- 版面」这种 mandatory_func 显示当前值的条目，改完之后面板上还是旧值。
--- 这里手动让它重算一遍。
--- @return boolean 是否刷新过
function Imenu.refresh()
    local menu = last_menu
    if not menu or not menu.updateItems then return false end
    if not UIManager:isWidgetShown(menu) then return false end
    return (pcall(menu.updateItems, menu, 1))
end

--- 纯文本行（不可选中），用于「空目录」「共 N 项」这类占位信息
function Imenu.note(text)
    return {
        text           = text,
        select_enabled = false,
    }
end

--- 把已经挂在窗口栈里的控件重新抬到最上层。
---
--- 实现与觅阅 HomeView.raise 同源：先从栈里摘出来，再插回「最上面那个
--- 非模态、非 toast 的窗口之上」——与 UIManager:show 的插入位置规则一致。
--- 刻意不调用 UIManager:show，避免同一个控件在栈里出现两份。
---
--- UIManager._window_stack 是内部字段，但这里只做「摘出 → 原样插回」，
--- 不改变任何窗口的数据，失败也无副作用（全程 pcall 兜住）。
--- @return boolean 是否抬起过
function Imenu.raise(widget)
    if not widget then return false end

    local raised = false
    local ok = pcall(function()
        local stack = UIManager._window_stack
        if type(stack) ~= "table" then return end

        local window, index
        for i = #stack, 1, -1 do
            if stack[i] and stack[i].widget == widget then
                window, index = stack[i], i
                break
            end
        end
        if not window then return end

        table.remove(stack, index)

        local insert_at = 1
        for i = #stack, 0, -1 do
            local top = stack[i]
            if top and top.widget and top.widget.toast then
                -- toast 永远在最上面，越过它继续往下找
            elseif not top or not top.widget or not top.widget.modal then
                insert_at = i + 1
                break
            end
        end
        table.insert(stack, insert_at, window)
        raised = true

        UIManager:setDirty(widget, "ui")
    end)

    return ok and raised
end

return Imenu
