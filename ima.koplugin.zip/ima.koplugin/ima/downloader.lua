--[[--
把知识库条目变成设备上可打开的文件。

链路：
    media_id --get_media_info--> 临时签名 URL --流式下载--> 本地缓存文件

几条硬约束（均经 2026-10-07 实测确认）：

  1. **URL 是临时签名**，query 里带 sign / t，另有 X-IMA-Create-URL-Time。
     所以绝不缓存 URL，只缓存下好的文件；每次点开都重新取一次地址。

  2. 实测**不带** url_info.headers 也能下到文件（签名已经在 URL 里），
     带上无害，故原样透传。

  3. **必须流式落盘**（自建 ltn12 sink），不能把整个文件读进内存。
     Kobo 内存有限，一个几十 MB 的 PDF 一次性 load 会直接把设备拖死。

  4. **失败必须删掉半截文件**。否则下次点开会命中「缓存」，
     打开一个残缺文件 —— 这种错误比下载失败更难排查。
     因此先写 .part，成功后原子 rename。

  5. 笔记（media_type = 11）不是文件，走 note 线读正文，
     落成 .txt 交给 KOReader 的文本阅读器。
--]]--

local http      = require("socket.http")
local socket    = require("socket")
local socketutil = require("socketutil")
local lfs       = require("libs/libkoreader-lfs")
local logger    = require("logger")
local util      = require("util")

local Api       = require("ima.api")
local Constants = require("ima.constants")
local Models    = require("ima.models")

local Downloader = {}

local CACHE_SUBDIR = "ima"

--- 拼路径。KOReader 的 util 没有 joinPath，自己来。
--- 注意：全项目统一用这个，别写成 util.joinPath —— 那个函数根本不存在，
--- 运行时才会炸（"attempt to call field 'joinPath' (a nil value)"）。
local function joinPath(...)
    local parts = { ... }
    local out = table.remove(parts, 1) or ""
    for i = 1, #parts do
        local p = parts[i]
        if type(p) == "string" and p ~= "" then
            out = out:gsub("/+$", "") .. "/" .. p:gsub("^/+", "")
        end
    end
    return out
end

--- 缓存目录（KOReader 数据目录下的 cache/ima）
function Downloader.cacheDir()
    return joinPath(require("datastorage"):getFullDataDir(), "cache", CACHE_SUBDIR)
end

local function ensureDir(dir)
    if lfs.attributes(dir, "mode") == "directory" then return true end
    local ok = pcall(util.makePath, dir)
    if not ok or lfs.attributes(dir, "mode") ~= "directory" then
        return false, "无法创建缓存目录：" .. tostring(dir)
    end
    return true
end

--- 8 位稳定短哈希。用来给缓存文件名去重 —— media_id 唯一，
--- 而标题可能重复（同名不同版本的两个 PDF 很常见）。
local function short_hash(s)
    local h = 5381
    for i = 1, #s do
        h = (h * 33 + s:byte(i)) % 4294967296
    end
    return string.format("%08x", h)
end

--- 条目在缓存里的完整路径。
--- @param ext 扩展名（不含点）
function Downloader.cachePath(entry, ext)
    local name = Models.safe_filename(entry.title, ext)
        .. "_" .. short_hash(entry.id)
        .. "." .. ext
    return joinPath(Downloader.cacheDir(), name)
end

--- 流式下载到 dest。返回 (path, err, bytes)。
local function downloadToFile(url, dest, headers, on_progress)
    local tmp = dest .. ".part"

    local f, ferr = io.open(tmp, "wb")
    if not f then
        return nil, "无法写入缓存文件：" .. tostring(ferr)
    end

    local received   = 0
    local last_tick  = -1

    -- 文件句柄只关一次：写失败时 http.request 可能不再回调 sink(nil)，
    -- 若不在失败分支里关掉，这个句柄就一直泄漏到进程结束。
    local closed = false
    local function closeFile()
        if closed then return end
        closed = true
        pcall(function() f:close() end)
    end

    local sink = function(chunk, err)
        if not chunk then          -- 数据结束
            closeFile()
            if err then return nil, err end
            return 1
        end

        received = received + #chunk
        local ok, werr = f:write(chunk)
        if not ok then
            closeFile()
            return nil, werr or "写入缓存失败"
        end

        -- 节流：Kobo 刷新一屏要几百毫秒，按字节回调会把界面刷烂
        if on_progress then
            local now = os.time()
            if now ~= last_tick then
                last_tick = now
                on_progress(received)
            end
        end
        return 1
    end

    local req_headers = {}
    for k, v in pairs(headers or {}) do
        req_headers[k] = v
    end
    -- 请求头若被省略，服务端可能回 gzip；LuaSocket 不会自动解压，
    -- 落盘就成了坏文件。显式关掉。
    req_headers["Accept-Encoding"] = "identity"
    req_headers["User-Agent"]      = Constants.USER_AGENT

    socketutil:set_timeout(Constants.DOWNLOAD_BLOCK_TIMEOUT,
                           Constants.DOWNLOAD_TOTAL_TIMEOUT)

    local ok, code = pcall(function()
        return socket.skip(1, http.request{
            url      = url,
            method   = "GET",
            headers  = req_headers,
            sink     = sink,
            redirect = true,
        })
    end)

    socketutil:reset_timeout()

    if not ok then
        pcall(os.remove, tmp)
        logger.warn("ima download: transport error", url, tostring(code))
        return nil, "下载中断：" .. tostring(code)
    end

    if type(code) ~= "number" then
        -- 请求根本没发出去（DNS / 连接被拒 / 超时），此时 code 是错误文案
        pcall(os.remove, tmp)
        logger.warn("ima download: no response", tostring(code), url)
        return nil, "下载失败：" .. tostring(code)
    end

    if code < 200 or code >= 300 then
        pcall(os.remove, tmp)
        logger.warn("ima download: http status", tostring(code), url)
        return nil, string.format("下载失败（HTTP %d）", code)
    end

    if received == 0 then
        pcall(os.remove, tmp)
        return nil, "下载到的文件是空的"
    end

    -- 原子替换：先删旧的再改名，避免半截文件被当作有效缓存
    pcall(os.remove, dest)
    local rok, rerr = os.rename(tmp, dest)
    if not rok then
        pcall(os.remove, tmp)
        return nil, "保存文件失败：" .. tostring(rerr)
    end

    return dest, nil, received
end

--- 把纯文本（笔记正文）写成 .txt。
--- 走文件而非直接上屏：这样退出后还能重进，也能在文件管理器里找到。
local function writeTextFile(dest, text)
    local f, err = io.open(dest, "wb")
    if not f then
        return nil, "无法写入文件：" .. tostring(err)
    end
    -- 带 BOM 的 UTF-8，避免某些阅读器把中文认成别的编码
    f:write("\239\187\191")
    f:write(text)
    f:close()
    return dest
end

--- 只查缓存，不发任何网络请求。命中返回本地路径，否则 nil。
--- 用于「秒开」判断：已下过的文件不该再走一次取地址 + 下载。
function Downloader.cachedPath(entry)
    if type(entry) ~= "table" or not entry.id then return nil end
    local ext = Models.file_extension(entry) or (entry.is_note and "txt" or nil)
    if not ext then return nil end
    local p = Downloader.cachePath(entry, ext)
    if lfs.attributes(p, "mode") == "file" then return p end
    return nil
end

--- 确保条目已在本地有可打开的文件；已缓存则直接复用。
---
--- @param entry       条目 { id, title, media_type }
--- @param on_progress 可选，function(bytes) 下载进度（已节流到约每秒一次）
--- @return path, err, from_cache
function Downloader.ensureLocal(entry, on_progress)
    if type(entry) ~= "table" or not entry.id then
        return nil, "条目信息不完整"
    end

    local ext = Models.file_extension(entry)

    local ok_dir, derr = ensureDir(Downloader.cacheDir())
    if not ok_dir then return nil, derr end

    -- 缓存命中。笔记落成 txt；其余若认不出扩展名，用 bin 兜底。
    local guess_ext = ext or (entry.is_note and "txt" or "bin")
    local cached = Downloader.cachePath(entry, guess_ext)
    if lfs.attributes(cached, "mode") == "file" then
        return cached, nil, true
    end

    -- 取临时地址 / 笔记 id
    local data, err = Api.get_media_info(entry.id)
    if not data then return nil, err end

    local info = Models.media_info(data)

    -- 分支一：笔记 → 读正文落成 txt
    if info.is_note and info.notebook_id then
        local doc, derr2 = Api.get_doc_content(info.notebook_id)
        if not doc then return nil, derr2 end

        local text = doc.content
        if type(text) ~= "string" or text == "" then
            return nil, "这条笔记还没有正文内容"
        end

        local dest = Downloader.cachePath(entry, "txt")
        local path, werr = writeTextFile(dest, text)
        if not path then return nil, werr end
        return path, nil, false
    end

    -- 分支二：普通文件 → 下载
    if not info.url then
        return nil, "该条目暂时取不到原文。\n\n"
            .. "常见原因：条目仍在解析中（刚导入的资料需要时间），"
            .. "或解析失败。可以稍后再试。"
    end

    if not ext then
        -- 地址后缀比列表里的信息更准（列表标题可能被改过名）
        ext = info.url:match("%.([%a%d]+)%?") or info.url:match("%.([%a%d]+)$")
        if ext then ext = ext:lower() end
    end

    local dest = Downloader.cachePath(entry, ext or "bin")
    local path, derr3 = downloadToFile(info.url, dest, info.headers, on_progress)
    if not path then return nil, derr3 end

    return path, nil, false
end

--- 清空缓存目录，返回 (删除文件数, 释放字节数)
function Downloader.clearCache()
    local dir = Downloader.cacheDir()
    if lfs.attributes(dir, "mode") ~= "directory" then return 0, 0 end

    local count, bytes = 0, 0
    for file in lfs.dir(dir) do
        if file ~= "." and file ~= ".." then
            local p = joinPath(dir, file)
            local attr = lfs.attributes(p)
            if attr and attr.mode == "file" then
                bytes = bytes + (attr.size or 0)
                if os.remove(p) then count = count + 1 end
            end
        end
    end
    return count, bytes
end

--- 缓存占用（文件数, 字节数）
function Downloader.cacheUsage()
    local dir = Downloader.cacheDir()
    if lfs.attributes(dir, "mode") ~= "directory" then return 0, 0 end
    local count, bytes = 0, 0
    for file in lfs.dir(dir) do
        if file ~= "." and file ~= ".." then
            local attr = lfs.attributes(joinPath(dir, file))
            if attr and attr.mode == "file" then
                count = count + 1
                bytes = bytes + (attr.size or 0)
            end
        end
    end
    return count, bytes
end

return Downloader
