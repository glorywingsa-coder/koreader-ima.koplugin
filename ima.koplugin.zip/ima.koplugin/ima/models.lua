--[[--
把接口返回的 data 规整成界面能直接用的结构。

首版曾用纯「特征匹配」盲扫 JSON，接口路径修正后改为：
**优先走实测确认的精确路径，特征匹配只作为兜底**。
这样正常情况 O(n) 直取，接口若变更也不至于直接崩，只是退化。

实测结构（2026-10-07）：
  search_knowledge_base → data.info_list[]   { kb_id, kb_name, base_type, ... }
  get_knowledge_list    → data.knowledge_list[] { media_id, title, media_type, ... }
                          data.is_end / data.next_cursor
  search_knowledge      → data.info_list[]   { media_id, title, media_type, ... }
--]]--

local Constants = require("ima.constants")

local Models = {}

local MAX_DEPTH = 6

--- 知识库条目
local function as_knowledge_base(node, depth)
    local id   = node.kb_id
    local name = node.kb_name
    if (not id or not name) and (depth or 0) <= 3 then
        id   = id or node.knowledge_base_id or node.id
        name = name or node.name
    end
    if type(id) == "string" and id ~= "" and type(name) == "string" and name ~= "" then
        return {
            id            = id,
            name          = name,
            base_type     = node.base_type or "",
            role_type     = node.role_type,
            content_count = node.content_count,
            creator       = node.creator,
        }
    end
    return nil
end

--- 媒体条目（文件 / 文件夹 / 笔记）
local function as_media(node)
    local id    = node.media_id or node.file_id
    local title = node.title or node.name or node.media_name
    if type(id) ~= "string" or id == "" then return nil end
    if type(title) ~= "string" or title == "" then return nil end

    local media_type = tonumber(node.media_type) or tonumber(node.file_type)
    return {
        id           = id,
        title        = title,
        media_type   = media_type,
        is_folder    = media_type == Constants.FOLDER_MEDIA_TYPE,
        is_note      = media_type == Constants.NOTE_MEDIA_TYPE,
        parent_id    = node.parent_folder_id,
        highlight    = node.highlight_content,
    }
end

local function walk(node, out, seen, depth, make)
    if type(node) ~= "table" or depth > MAX_DEPTH then return end
    local item = make(node, depth)
    if item and not seen[item.id] then
        seen[item.id] = true
        out[#out + 1] = item
    end
    -- 只递归 table 字段；接口返回里的标量表不会被误当作容器
    for _, v in pairs(node) do
        if type(v) == "table" then
            walk(v, out, seen, depth + 1, make)
        end
    end
end

local function collect(node, make)
    local out, seen = {}, {}
    walk(node, out, seen, 0, make)
    return out
end

--- 从数组字段里逐条转换（精确路径）
local function from_list(data, key, make)
    local out = {}
    local list = type(data) == "table" and data[key]
    if type(list) ~= "table" then return out end
    for _, node in ipairs(list) do
        if type(node) == "table" then
            local item = make(node, 0)
            if item then out[#out + 1] = item end
        end
    end
    return out
end

--- @return array of { id, name, base_type, role_type, content_count, creator }
function Models.knowledge_bases(data)
    -- 实测路径：search_knowledge_base → data.info_list[]
    local out = from_list(data, "info_list", as_knowledge_base)
    if #out > 0 then return out end
    return collect(data, as_knowledge_base)
end

--- @return array of { id, title, media_type, is_folder, parent_id, highlight }
function Models.media_entries(data)
    -- 实测路径：get_knowledge_list → knowledge_list[]
    --           search_knowledge    → info_list[]
    for _, key in ipairs({ "knowledge_list", "info_list" }) do
        local out = from_list(data, key, as_media)
        if #out > 0 then return out end
    end
    return collect(data, as_media)
end

--- 分页信息。实测：data.is_end（布尔）、data.next_cursor（不透明字符串）
--- @return { is_end = boolean, next_cursor = string }
function Models.page_info(data)
    if type(data) ~= "table" then
        return { is_end = true, next_cursor = "" }
    end
    return {
        is_end      = data.is_end ~= false,
        next_cursor = type(data.next_cursor) == "string" and data.next_cursor or "",
    }
end

--- 给界面的续取标记：还有下一页时返回 { next_cursor = "..." }，否则 nil。
--- 放在 Models 而非某个 view 里，免得 kb_list / kb_browser 互相 require 成环。
function Models.paging(data)
    local page = Models.page_info(data)
    if page.is_end or page.next_cursor == "" then return nil end
    return { next_cursor = page.next_cursor }
end

--- 当前所在目录面包屑。实测：data.current_path[] = { folder_id, name, is_top }
--- @return array of string
function Models.current_path(data)
    local out = {}
    local list = type(data) == "table" and data.current_path
    if type(list) ~= "table" then return out end
    for _, node in ipairs(list) do
        if type(node) == "table" and type(node.name) == "string" and node.name ~= "" then
            out[#out + 1] = node.name
        end
    end
    return out
end

--- media_type → 展示文案，未知类型返回 nil
function Models.media_type_label(media_type)
    return Constants.MEDIA_TYPE_LABEL[tonumber(media_type) or -1]
end

--- 知识库类型文案。
--- 实测 base_type 返回的已是中文（如「个人知识库」），直接透传即可。
function Models.kb_type_label(base_type)
    if type(base_type) ~= "string" or base_type == "" then return nil end
    return base_type
end

--==========================================================================
-- 条目格式与本地文件
--==========================================================================

--- 从标题末尾取扩展名（小写、不含点）
local function ext_from_title(title)
    if type(title) ~= "string" then return nil end
    local ext = title:match("%.([%a%d]+)$")
    if ext and #ext <= 5 then return ext:lower() end
    return nil
end

--- 从 media_id 前缀取扩展名（"pdf_1123..._abc" → "pdf"）
local function ext_from_id(id)
    if type(id) ~= "string" then return nil end
    local prefix = id:match("^([%a]+)_")
    if not prefix then return nil end
    return Constants.MEDIA_ID_EXT[prefix:lower()]
end

--- 条目对应文件的扩展名。
--- 顺序：标题后缀（最直观，与用户在列表里看到的一致）
---      → media_id 前缀（稳定）
---      → media_type 数字（兜底）
--- 都认不出返回 nil —— 例如笔记（note_ 前缀）本就没有文件扩展名。
function Models.file_extension(entry)
    if type(entry) ~= "table" then return nil end
    local ext = ext_from_title(entry.title) or ext_from_id(entry.id)
    if ext and ext ~= "" then return ext end
    return Constants.MEDIA_TYPE_EXT[tonumber(entry.media_type) or -1]
end

--- 该扩展名 KOReader 能否直接打开（下载前的预判，用来省流量）
function Models.is_readable_ext(ext)
    if type(ext) ~= "string" then return false end
    return Constants.READABLE_EXT[ext:lower()] == true
end

--- 按字节截断，且不切断 UTF-8 序列。
--- Kobo 文件名上限 255 **字节**，而中文一个字占 3 字节 —— 只按字符数截断
--- 会不小心超限写到一半失败。界面里截断长标题也用得上。
function Models.truncate_utf8(s, max_bytes)
    s = tostring(s or "")
    if #s <= max_bytes then return s end
    local cut = max_bytes
    while cut > 0 do
        local b = s:byte(cut + 1)
        -- 0x80–0xBF 是续字节，说明 cut 落在字符中间，继续往前退
        if b == nil or b < 0x80 or b >= 0xC0 then break end
        cut = cut - 1
    end
    return s:sub(1, cut)
end

--- 把条目标题变成安全的本地文件名（不含目录、不含扩展名）。
--- 必须清理路径分隔符：标题里若含 "/"，直接拼路径会把文件写进别的目录。
function Models.safe_filename(title, ext)
    local name = tostring(title or "")

    if type(ext) == "string" and ext ~= "" then
        -- 去掉标题里原有的扩展名，最后统一由调用方拼一个
        name = name:gsub("%." .. ext:gsub("%p", "%%%0") .. "$", "")
    end

    name = name:gsub("[/\\:*?\"<>|]", "_")   -- 路径分隔符 + Windows 禁用字符
    name = name:gsub("%c", "")               -- 控制字符（含换行）
    name = name:gsub("^%s+", ""):gsub("%s+$", "")
    name = name:gsub("%s+", " ")

    if name == "" then name = "ima_file" end

    return Models.truncate_utf8(name, 160)
end

--- 解析 get_media_info 的响应。
--- @return table {
---   media_type, url, headers, notebook_id,
---   is_note, downloadable
--- }
function Models.media_info(data)
    local out = {
        media_type = type(data) == "table" and tonumber(data.media_type) or nil,
    }

    if type(data) == "table" then
        local ui = data.url_info
        if type(ui) == "table" then
            if type(ui.url) == "string" and ui.url ~= "" then
                out.url = ui.url
            end
            if type(ui.headers) == "table" then
                out.headers = ui.headers
            end
        end

        local ne = data.notebook_ext_info
        if type(ne) == "table" then
            local nid = ne.notebook_id or ne.notebookId
            if type(nid) == "string" and nid ~= "" then
                out.notebook_id = nid
            end
        end
    end

    out.is_note      = out.media_type == Constants.NOTE_MEDIA_TYPE
                         or out.notebook_id ~= nil
    out.downloadable = out.url ~= nil or out.notebook_id ~= nil

    return out
end

return Models
