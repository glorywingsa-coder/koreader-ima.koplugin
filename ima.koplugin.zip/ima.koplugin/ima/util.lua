--[[--
通用小工具。保持无副作用、不依赖 KOReader 运行时，方便单独调试。
--]]--

local Util = {}

function Util.trim(s)
    if type(s) ~= "string" then return s end
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

function Util.is_blank(s)
    return type(s) ~= "string" or Util.trim(s) == ""
end

--- 取表中第一个非空字段，用于兼容接口可能的不同字段命名
function Util.first_of(t, keys, default)
    if type(t) ~= "table" then return default end
    for _, k in ipairs(keys) do
        local v = t[k]
        if v ~= nil and v ~= "" then return v end
    end
    return default
end

--- 凭证脱敏，仅用于界面展示，绝不写入日志
function Util.mask_secret(s)
    if Util.is_blank(s) or type(s) ~= "string" then return "" end
    if #s <= 8 then return string.rep("*", #s) end
    return s:sub(1, 4) .. string.rep("*", #s - 8) .. s:sub(-4)
end

--- 安全拼接：忽略 nil 与空串
function Util.join(sep, ...)
    local parts = {}
    for i = 1, select("#", ...) do
        local v = select(i, ...)
        if not Util.is_blank(v) then
            parts[#parts + 1] = tostring(v)
        end
    end
    return table.concat(parts, sep)
end

return Util
