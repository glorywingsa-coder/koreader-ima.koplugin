--[[--
IMA ←→ 觅阅（miuread）桥接层。

目前只做一件事：把「IMA 知识库」放进觅阅首页的**下拉快捷面板**
（在首页顶部区域向下滑出来的那一排按钮）。

为什么是「包装」而不是「注册」——取证结论（觅阅 5.9.0 + KOReader v2026.07.1）：

  觅阅的下拉面板是**白名单式**的，没有任何给第三方插件留的注册接口：

    · 条目池：main.lua 里一张**硬编码**的 definitions 表
      （wifi / 方向锁定 / 截图 / 下载 / 觅阅设置 / KO设置 / 重启 …，共 17 项）；
    · 过滤排序：for key in home.panel_order + home.panel_items[key]==true，
      上限 HOME_PANEL_MAX_VISIBLE = 8；
    · 渲染：miuread/home_quick_panel.lua 的 QuickPanelWidget:_build()，
      **单行**，columns = math.min(8, #buttons)；
    · 它也**不读** KOReader 的 Dispatcher —— 所以「注册一个手势动作」那条路
      同样进不了这个面板。

  唯一不碰觅阅文件的做法，是包装面板模块的 show(opts)：
  Plugin:show_home_quick_panel() 会把组装好的 opts.buttons 交给它渲染，
  我们在那一环往 buttons 里插一项。

边界（与本项目其它部分一致）：

  · 不改觅阅任何文件、不写觅阅任何设置。只替换一次函数引用。
  · 觅阅没装 / 模块进不了 package.path / 接口改名 → 静默跳过，
    全程 pcall + 类型检查。最坏结果是「入口不出现」，绝不会崩。
  · 幂等：KOReader 对同一个插件会在 FileManager 与 ReaderUI 各建一次实例，
    init 会跑多次，用 _G 标记挡住重复包装。
  · 惰性：不在启动路径上 require 觅阅的面板模块（那是整棵控件树），
    由 main.lua 调用 scheduleInstall() 安排到启动完成之后再挂。
--]]--

local logger    = require("logger")
local UIManager = require("ui/uimanager")
local _         = require("gettext")

local M = {}

--- 觅阅的面板模块名，以及它的单行容量（对应觅阅的 HOME_PANEL_MAX_VISIBLE）。
--- 容量写死是有意的：面板 _build() 里就是 math.min(8, #buttons)，
--- 这里用它表达「满格时要插到最前」的阈值。
local PANEL_MODULE   = "miuread.home_quick_panel"
local PANEL_CAPACITY = 8

--- 距 KOReader 启动多少秒后尝试安装。第一次通常就够了（觅阅作为插件
--- 在启动时就被加载），后两次是「万一觅阅晚一步」的兜底。
local RETRY_AT = { 4, 10, 25 }

--- 安装标记放在 _G：模块级 require 缓存跨不过插件实例，而这件事
--- 全局只需要做一次。
local HOOK_FLAG     = "__IMA_MIUREAD_PANEL_HOOKED"
local SCHEDULE_FLAG = "__IMA_MIUREAD_PANEL_SCHEDULED"

--- 觅阅插件是否真的在运行。它没装或没启用时，这个入口没有意义，
--- 也就没必要把它的面板模块拉进内存。
local function miuread_running()
    local ok, PluginLoader = pcall(require, "pluginloader")
    if not ok or type(PluginLoader) ~= "table" then return false end
    if type(PluginLoader.getPluginInstance) ~= "function" then return false end
    local ok_get, plugin = pcall(PluginLoader.getPluginInstance, PluginLoader, "miuread")
    return ok_get and plugin ~= nil
end

--- 构造面板条目。界面模块的 require 留在回调里，避免把 views/kb_list
--- 那一串控件树提前拖进来。
local function build_entry()
    return {
        -- 直接复用觅阅自带的「书库」图标（Lucide library）。觅阅按 icon_key
        -- 在它自己的 resources/icons/miuread/ 下找 svg，找不到会自动退到
        -- more.svg，所以图标缺失也不会报错，更不会崩。
        icon_key = "library",
        label    = _("IMA 知识库"),
        detail   = "",
        callback = function()
            -- 面板点击是「先收起面板、再执行回调」（home_quick_panel.lua
            -- 的 run_action → close_callback），所以这里可以安全地开界面。
            local ok, err = pcall(function()
                require("ima.views.kb_list").show()
            end)
            if not ok then
                logger.warn("[ima] 从觅阅快捷面板打开知识库失败", tostring(err))
            end
        end,
    }
end

--- 把 IMA 条目插进 opts.buttons。
--- 有空位就追加在最末（不动用户已勾选项的相对顺序）；
--- 已经满 8 项时插到**最前** —— 渲染层只取前 8 个，因此只会挤掉最后一格，
--- 保证入口始终可见，且其余各项的先后次序完全不变。
local function inject(opts)
    local buttons = opts.buttons
    local entry = build_entry()
    if #buttons >= PANEL_CAPACITY then
        table.insert(buttons, 1, entry)
    else
        buttons[#buttons + 1] = entry
    end
end

--- 安装（幂等）。返回 true 表示这一步之后入口已经在位。
function M.installPanelEntry()
    if rawget(_G, HOOK_FLAG) == true then return true end

    if not miuread_running() then return false end

    -- 惰性 require：这一步会把觅阅的面板控件树加载进内存，
    -- 所以只在调用方安排的延迟时刻（启动完成之后）做。
    local ok_req, Panel = pcall(require, PANEL_MODULE)
    if not ok_req or type(Panel) ~= "table" or type(Panel.show) ~= "function" then
        return false
    end

    local original_show = Panel.show
    Panel.show = function(opts)
        -- 只在结构符合预期时插入。觅阅若改了 opts 的形状，
        -- 这里最多是「入口不出现」，show 本身照常执行。
        if type(opts) == "table" and type(opts.buttons) == "table" then
            local ok_inject = pcall(inject, opts)
            if not ok_inject then
                logger.warn("[ima] 觅阅快捷面板注入失败，跳过本次")
            end
        end
        return original_show(opts)
    end

    rawset(_G, HOOK_FLAG, true)
    logger.info("[ima] 已挂上觅阅首页下拉面板入口（IMA 知识库）")
    return true
end

--- 由插件 init 调用：安排到 KOReader 启动完成之后再挂，不拖慢启动。
--- 重复调用无害（SCHEDULE_FLAG 挡住）。
function M.scheduleInstall()
    if rawget(_G, HOOK_FLAG) == true or rawget(_G, SCHEDULE_FLAG) == true then
        return
    end
    rawset(_G, SCHEDULE_FLAG, true)

    local previous = 0
    -- 注意：循环变量刻意**不能**用 `_` —— 本模块里 `_` 是 gettext 函数，
    -- 写 `for _, at in ...` 会把它遮蔽成数字下标，之后任何 `_("...")`
    -- 都会抛 "attempt to call upvalue '_' (a number value)" 直接崩 KOReader。
    -- （build_entry 里就有 `_("IMA 知识库")`，是活代码不是注释。）
    for _index, at in ipairs(RETRY_AT) do
        UIManager:scheduleIn(at - previous, function()
            if rawget(_G, HOOK_FLAG) == true then return end
            pcall(M.installPanelEntry)
        end)
        previous = at
    end
end

return M
