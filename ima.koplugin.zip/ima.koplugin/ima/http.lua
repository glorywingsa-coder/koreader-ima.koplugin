--[[--
HTTP 传输层：向 ima 开放平台 POST 一个 JSON 请求。

KOReader 自带的 socket.http 内置了 https 分支（内部自动使用 ssl.https.tcp），
因此这里一个 http.request 就能同时支持 http/https，无需分别 require。
参考实现见 koreader/frontend/socketutil.lua。
--]]--

local http = require("socket.http")
local socket = require("socket")
local ltn12 = require("ltn12")
local socketutil = require("socketutil")
local json = require("json")
local logger = require("logger")

local Constants = require("ima.constants")

local Http = {}

local function encode_body(payload)
    local ok, body = pcall(json.encode, payload or {})
    if not ok or type(body) ~= "string" then
        return nil, "请求参数序列化失败"
    end
    return body
end

--- 解析 ima 的统一信封 { code, msg, data }
--- 返回 data / err / 完整原始结构
---
--- 注意：ima 在**非 2xx 时同样返回 JSON body**，所以先解 body 再判状态码，
--- 否则会把「凭证无效」这类关键信息丢掉，只剩一句没用的 HTTP 401。
--- 实测凭证无效：HTTP 401 + {"code":200002,"msg":"skill auth failed"}
local function parse_response(http_code, raw)
    if type(http_code) ~= "number" then
        return nil, "网络请求失败（没有拿到响应）", nil
    end

    local decoded
    if type(raw) == "string" and raw ~= "" then
        local ok, d = pcall(json.decode, raw)
        if ok and type(d) == "table" then decoded = d end
    end

    local code, msg
    if decoded then
        code = decoded.code
        if code == nil then code = decoded.retcode end
        msg = decoded.msg or decoded.errmsg or decoded.message or decoded.errMsg
    end

    if http_code < 200 or http_code >= 300 then
        if tonumber(code) == Constants.AUTH_ERROR_CODE then
            return nil, "凭证无效或已被重置。请回 ima.qq.com/agent-interface 重新生成后填入。", decoded
        end
        local detail = msg and ("：" .. tostring(msg)) or ""
        return nil, string.format("服务端返回 HTTP %d%s", http_code, detail), decoded
    end

    if not decoded then
        return nil, "响应不是合法 JSON", nil
    end

    if code ~= nil and tonumber(code) ~= 0 then
        return nil, tostring(msg or "接口返回错误"), decoded
    end

    local data = decoded.data
    if data == nil then data = decoded end
    return data, nil, decoded
end

--- POST JSON。
--- @param url     完整 URL
--- @param payload 请求体（会被 json.encode）
--- @param headers 额外请求头
--- @return data, err, raw
function Http.post_json(url, payload, headers)
    local body, body_err = encode_body(payload)
    if not body then
        return nil, body_err, nil
    end

    -- 复制一份，避免修改调用方传入的表
    local req_headers = {}
    for k, v in pairs(headers or {}) do
        req_headers[k] = v
    end
    req_headers["Content-Type"] = "application/json"
    req_headers["Content-Length"] = tostring(#body)
    req_headers["User-Agent"] = req_headers["User-Agent"] or Constants.USER_AGENT

    local chunks = {}
    socketutil:set_timeout(Constants.BLOCK_TIMEOUT, Constants.TOTAL_TIMEOUT)

    -- 需要 sink 时 http.request 会先返回一个 1 作为标记，所以用 socket.skip 跳过它。
    local ok, code = pcall(function()
        return socket.skip(1, http.request{
            url      = url,
            method   = "POST",
            headers  = req_headers,
            source   = ltn12.source.string(body),
            sink     = ltn12.sink.table(chunks),
            redirect = false,
        })
    end)

    socketutil:reset_timeout()

    if not ok then
        logger.warn("ima: transport error", url, tostring(code))
        return nil, "网络请求异常：" .. tostring(code), nil
    end

    local raw = table.concat(chunks)
    local data, err, decoded = parse_response(code, raw)

    -- 失败一律落日志：ima 会把具体原因写在 body 里（例如 limit 越界、
    -- 凭证失效），只靠界面弹窗很容易被用户一句「请求失败」带过去，
    -- 排查时无从下手。凭证不打印，URL 与响应片段足够定位问题。
    if not data then
        logger.warn("ima: request failed", url,
            "http=", tostring(code), "err=", tostring(err),
            "body=", string.sub(raw, 1, 400))
    end

    return data, err, decoded
end

return Http
