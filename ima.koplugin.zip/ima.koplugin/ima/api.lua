--[[--
ima 开放平台接口封装。

只做「拼路径 + 拼参数 + 带凭证」三件事，不处理界面。
每个函数返回 (data, err, raw)，data 为 { code, msg, data } 里的 data 部分。

路径与入参均在 2026-10-07 用真实凭证 curl 实测通过。

--- 关于 limit（v0.4.0 的重要修正）----------------------------------------

首版把三个接口的 limit 统一写成 50，导致**首屏必然打不开**：
服务端对越界 limit 不是静默截断，而是直接报错——

    {"code":51,"msg":"invalid SearchKnowledgeBaseReq.Limit:
                        value must be inside range (0, 20]"}

而 search_knowledge_base 的真实上限是 20。各接口上限实测如下：

    search_knowledge_base   (0, 20]     ← 列库 / 搜库都走它
    get_knowledge_list      (0, 50]
    search_knowledge         未设硬上限（100 也通过）

因此这里不再共用常量，改为**按接口传对应的上限**；
另外再叠一层保险：一旦服务端用上面的文案拒了请求，
就从消息里解析出真实上限并自动重放一次，见 call_with_autolimit。
这样官方将来收紧或放宽上限，插件都不会因为一个硬编码数字而整体失效。
--]]--

local logger = require("logger")

local Constants = require("ima.constants")
local Http = require("ima.http")
local Config = require("ima.config")

local Api = {}

local function clamp_limit(limit, max)
    local n = tonumber(limit) or max or Constants.DEFAULT_LIMIT
    if n < 1 then n = 1 end
    if max and n > max then n = max end
    return n
end

local function auth_headers()
    local cfg = Config.get()
    return {
        [Constants.HEADER_CLIENT_ID] = cfg:getClientId(),
        [Constants.HEADER_API_KEY]   = cfg:getApiKey(),
        ["User-Agent"]               = Constants.USER_AGENT,
    }
end

local function call(path, payload)
    if not Config.get():hasCredentials() then
        return nil, "尚未配置 IMA 凭证（Client ID / API Key）"
    end
    return Http.post_json(Constants.API_HOST .. path, payload, auth_headers())
end

--- 从服务端错误文案里取出真实上限：
---   "invalid XxxReq.Limit: value must be inside range (0, 20]"  →  20
local function limit_range_hint(err)
    if type(err) ~= "string" then return nil end
    return tonumber(err:match("inside range%s*%(%s*%d+%s*,%s*(%d+)%s*%]"))
end

--- 带「越界自愈」的调用：build_payload(limit) 负责用给定 limit 拼参数。
--- 正常一次成功；若被服务端的越界提示拒绝，则按其给出的真实上限重放一次。
local function call_with_autolimit(path, build_payload, limit)
    local data, err, raw = call(path, build_payload(limit))
    if data then return data, nil, raw end

    local server_max = limit_range_hint(err)
    if server_max and server_max > 0 and server_max ~= limit then
        logger.warn("ima: limit out of range, retrying", path,
            "client=", tostring(limit), "server_max=", tostring(server_max))
        data, err, raw = call(path, build_payload(server_max))
        if data then return data, nil, raw end
    end

    return nil, err, raw
end

--- 列出当前账号可访问的全部知识库。
---
--- ⚠️ 官方没有「列库」专用接口。实测 get_knowledge_base_list → HTTP 404。
--- 正确做法是 search_knowledge_base 传**空 query**，服务端即返回全部：
---   {"query":"","cursor":"","limit":N}   N ≤ 20
---   → data.info_list[] = { kb_id, kb_name, base_type, role_type,
---                          content_count, creator, description, ... }
function Api.list_knowledge_bases(cursor, limit)
    local want = clamp_limit(limit, Constants.LIMIT_SEARCH_KB)
    return call_with_autolimit(
        Constants.WIKI_V1 .. "/search_knowledge_base",
        function(l)
            return { query = "", cursor = cursor or "", limit = l }
        end,
        want)
end

--- 按名称 / 关键词搜索知识库（与 list_knowledge_bases 同一接口，只是 query 非空）
--- 实测响应：data.info_list[]（字段同上）
function Api.search_knowledge_base(query, cursor, limit)
    local want = clamp_limit(limit, Constants.LIMIT_SEARCH_KB)
    return call_with_autolimit(
        Constants.WIKI_V1 .. "/search_knowledge_base",
        function(l)
            return { query = query or "", cursor = cursor or "", limit = l }
        end,
        want)
end

--- 按 id 批量取知识库详情
--- 实测响应：data.infos[<id>] = { id, name, cover_url, description, ... }
function Api.get_knowledge_base(ids)
    if type(ids) == "string" then ids = { ids } end
    return call(Constants.WIKI_V1 .. "/get_knowledge_base", { ids = ids or {} })
end

--- 浏览知识库内容（不传 folder_id 即查根目录）
--- 实测响应：
---   data.knowledge_list[] = { media_id, title, parent_folder_id, media_type, tags }
---   data.is_end / data.next_cursor / data.current_path[]
function Api.get_knowledge_list(kb_id, folder_id, cursor, limit)
    local want = clamp_limit(limit, Constants.LIMIT_KNOWLEDGE_LIST)
    return call_with_autolimit(
        Constants.WIKI_V1 .. "/get_knowledge_list",
        function(l)
            local payload = {
                knowledge_base_id = kb_id,
                cursor            = cursor or "",
                limit             = l,
            }
            if type(folder_id) == "string" and folder_id ~= "" then
                payload.folder_id = folder_id
            end
            return payload
        end,
        want)
end

--- 在单个知识库内检索内容
--- 实测响应：data.info_list[] = { media_id, title, parent_folder_id,
---                                highlight_content, media_type }
function Api.search_knowledge(kb_id, query, cursor, limit)
    local want = clamp_limit(limit, Constants.LIMIT_SEARCH_KNOWLEDGE)
    return call_with_autolimit(
        Constants.WIKI_V1 .. "/search_knowledge",
        function(l)
            return {
                knowledge_base_id = kb_id,
                query             = query or "",
                cursor            = cursor or "",
                limit             = l,
            }
        end,
        want)
end

--- 取条目的原文 / 下载地址。
---
--- 实测（2026-10-07，真实条目）：
---   POST /openapi/wiki/v1/get_media_info   {"media_id": "..."}
---
--- 响应 data：
---   { media_type = 1,
---     url_info = {
---       url     = "https://pkb.ima.myqcloud.com/2/.../xxx.pdf
---                  ?media_id=pdf_...&media_title=...&sign=...&t=...",
---       headers = { ["X-IMA-Sign"]=..., ["X-IMA-Platform"]="H5", ... },
---     },
---     notebook_ext_info = nil }
---
--- 三条分支：
---   1. url_info.url 非空   → 直接下载。
---        实测：签名已写在 URL 的 query 里，**不带**那组 headers 也能 206/200 下到
---        文件，headers 仅作冗余带上即可。
---   2. media_type == 11    → 笔记，取 notebook_ext_info.notebook_id，
---                            改走 note 线 /get_doc_content 读正文。
---   3. 两者都没有          → 条目不可访问（多半仍在解析中，或解析失败）。
---
--- ⚠️ URL 是**临时签名**（query 里带 sign / t，另带 X-IMA-Create-URL-Time），
---    所以**不要缓存 URL 本身**，每次点开都重新取一次；缓存只缓存下好的文件。
function Api.get_media_info(media_id)
    if type(media_id) ~= "string" or media_id == "" then
        return nil, "条目 ID 为空"
    end
    return call(Constants.WIKI_V1 .. "/get_media_info", { media_id = media_id })
end

--- 读笔记正文（note 线）。media_type == 11 的条目走这里。
--- 参数按官方文档构造：{"doc_id": "<notebook_id>", "target_content_format": 0}
--- → data.content 为纯文本。
function Api.get_doc_content(doc_id, target_content_format)
    if type(doc_id) ~= "string" or doc_id == "" then
        return nil, "笔记 ID 为空"
    end
    return call("/openapi/note/v1/get_doc_content", {
        doc_id                = doc_id,
        target_content_format = target_content_format or 0,
    })
end

return Api
