--[[--
凭证与插件设置。

凭证存放在 KOReader 的 settings 目录（默认 koreader/settings/ima.lua），
与其它插件的设置同级。写入后尽量把文件权限收紧到 0600。

注意：API Key 属于敏感信息。
  - 不要提交到代码仓库
  - 不要写进日志（logger 调用里只出现脱敏后的值）
  - 泄露后可在 https://ima.qq.com/agent-interface 重新生成
--]]--

local DataStorage = require("datastorage")
local LuaSettings = require("luasettings")
local lfs = require("libs/libkoreader-lfs")

local Config = {}
Config.__index = Config

local SETTINGS_FILE = DataStorage:getSettingsDir() .. "/ima.lua"

local instance

--- 单例：整个插件生命周期内只打开一次设置文件
function Config.get()
    if not instance then
        instance = setmetatable({}, Config)
        instance.settings = LuaSettings:open(SETTINGS_FILE)
    end
    return instance
end

function Config:getSettingsFilePath()
    return SETTINGS_FILE
end

function Config:getClientId()
    local v = self.settings:readSetting("client_id")
    return type(v) == "string" and v or ""
end

function Config:getApiKey()
    local v = self.settings:readSetting("api_key")
    return type(v) == "string" and v or ""
end

function Config:hasCredentials()
    return self:getClientId() ~= "" and self:getApiKey() ~= ""
end

function Config:setCredentials(client_id, api_key)
    self.settings:saveSetting("client_id", client_id or "")
    self.settings:saveSetting("api_key", api_key or "")
    self.settings:flush()
    self:_restrict_permissions()
end

function Config:clearCredentials()
    self.settings:saveSetting("client_id", "")
    self.settings:saveSetting("api_key", "")
    self.settings:flush()
end

--- 布尔开关的统一读写。默认值不落盘：读不到就用 default，
--- 这样「跟随默认」和「用户显式关掉」两种情况能区分开。
function Config:getBool(key, default)
    local v = self.settings:readSetting(key)
    if type(v) == "boolean" then return v end
    return default == true
end

function Config:setBool(key, value)
    self.settings:saveSetting(key, value == true)
    self.settings:flush()
end

--- 字符串选项。同样区分「跟随默认」（键不存在）与「用户显式选了默认那一项」：
--- 调用方自己决定 fallback，这里不替它决定语义。
function Config:getString(key, default)
    local v = self.settings:readSetting(key)
    if type(v) == "string" and v ~= "" then return v end
    return default
end

function Config:setString(key, value)
    self.settings:saveSetting(key, tostring(value or ""))
    self.settings:flush()
end

--- 数值选项（重排参数这类）。读不到或类型不对就用 default，
--- 于是"没设置过"与"用户显式设成了默认值"在行为上等价 —— 对连续量来说
--- 这比区分两者更有用。
function Config:getNumber(key, default)
    local v = self.settings:readSetting(key)
    if type(v) == "number" then return v end
    return default
end

function Config:setNumber(key, value)
    local n = tonumber(value)
    if n == nil then return end
    self.settings:saveSetting(key, n)
    self.settings:flush()
end

--- 部分设备的文件系统不支持 chmod，失败不影响功能，因此静默忽略错误。
function Config:_restrict_permissions()
    pcall(function()
        if lfs.attributes(SETTINGS_FILE, "mode") == "file" then
            lfs.chmod(SETTINGS_FILE, "rw-------")
        end
    end)
end

return Config
