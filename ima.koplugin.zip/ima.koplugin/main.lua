--[[--
IMA 知识库 for KOReader

通过腾讯 ima 官方开放平台接口，在 KOReader 中浏览与检索个人知识库。

  接口文档：https://ima.qq.com/openapi
  凭证获取：https://ima.qq.com/agent-interface

本文件只负责插件注册与菜单装配；
网络与数据逻辑在 ima/ 目录下，界面在 ima/views/ 下。

设计要点：菜单里只注册一个「无子菜单」的条目。
KOReader 原生主菜单和觅阅（miuread）的插件桥接层遵循同一条规则——
只注册单一 callback 条目的插件会被直接呈现为可点击项，
点一下即进入知识库列表，不再多一层菜单。
搜索与凭证管理已收进列表界面内部（见 ima/views/kb_list.lua 顶部的工具栏）。
--]]--

local WidgetContainer = require("ui/widget/container/widgetcontainer")
local _ = require("gettext")

-- 重量级 UI 模块一律按需加载：插件在 KOReader 启动时就会被 dofile，
-- 这里若顶层 require 会把整棵 menu/dialog 控件树拖进启动路径。
-- 详见 miuread 对桌面模块的同类处理。
local function Settings()
    return require("ima.views.settings")
end

local function OpenKbList()
    require("ima.views.kb_list").show()
end

local IMA = WidgetContainer:extend{
    name = "ima",
    is_doc_only = false,
}

function IMA:init()
    self.ui.menu:registerToMainMenu(self)

    -- ① KOReader 的「动作」（Dispatcher）：注册后在 手势管理器 / 热键 /
    --    Profiles 的动作列表里就能选到「IMA 知识库」。
    self:onDispatcherRegisterActions()

    -- ② 觅阅首页「下拉快捷面板」入口。这是另一套机制（觅阅面板不读
    --    Dispatcher），做法与取舍见 ima/miuread_bridge.lua 顶部说明。
    --    延迟到启动完成后再挂，不在启动路径上加载觅阅的面板控件树。
    local ok_bridge, Bridge = pcall(require, "ima.miuread_bridge")
    if ok_bridge and type(Bridge) == "table"
        and type(Bridge.scheduleInstall) == "function" then
        pcall(Bridge.scheduleInstall)
    end
end

--- 注册 KOReader 的「动作」。KOReader 会广播 DispatcherRegisterActions，
--- 插件在这里（或 init 里）登记即可；registerAction 自带去重，
--- 而 init 会在 FileManager 与 ReaderUI 各跑一次，重复登记无副作用。
function IMA:onDispatcherRegisterActions()
    local ok_req, Dispatcher = pcall(require, "dispatcher")
    if not ok_req or type(Dispatcher) ~= "table"
        or type(Dispatcher.registerAction) ~= "function" then
        return false
    end
    return pcall(Dispatcher.registerAction, Dispatcher,
        "ima_open_knowledge_base", {
            -- category = "none" + event：Dispatcher 执行时发
            -- Event:new("ImaOpenKnowledgeBase")，由下面的同名方法接住。
            category = "none",
            event    = "ImaOpenKnowledgeBase",
            title    = _("IMA 知识库"),
            -- general：在阅读器内外都可用（本插件本来就与文档无关）。
            general  = true,
        }) == true
end

--- Dispatcher 事件的落地方法（event = "ImaOpenKnowledgeBase" → 本方法）。
function IMA:onImaOpenKnowledgeBase()
    OpenKbList()
    return true
end

function IMA:addToMainMenu(menu_items)
    -- 阅读器里是另一套菜单（ReaderMenu）。这里只加一个「返回知识库」，
    -- 而且只在**本文档确实是本插件打开的那一本**时加：
    -- 普通书籍（用户从文件浏览器打开的）不该多出一个 IMA 条目。
    if self.ui and self.ui.document then
        local ok, Session = pcall(require, "ima.reader_session")
        if ok and Session.isActive() then
            menu_items.ima_return_to_kb = {
                text         = _("← 返回 IMA 知识库"),
                sorting_hint = "main",
                callback     = function()
                    Session.returnNow()
                end,
            }
        end
        return
    end

    -- 关键：此处刻意不提供 sub_item_table。
    --   · KOReader 原生菜单：条目直接可点，点击进入知识库列表。
    --   · miuread 的 native_plugins.lua / plugin_menu_adapter.lua：只抓到
    --     一个 callback 条目时会走「直接执行」分支，同样是一级点击即进入。
    -- 若改回 sub_item_table，两侧都会退化成「一级 → 二级菜单」。
    menu_items.ima_knowledge_base = {
        text         = _("IMA 知识库"),
        sorting_hint = "more_tools",
        callback     = function()
            OpenKbList()
        end,
    }
end

-- 以下方法保留原方法名，实现已移到 ima/views/settings.lua。
-- 保留是为了兼容外部（插件管理器、觅阅的 openSettings 探测等）按名调用，
-- 同时让这些入口在任何路径下都指向同一份实现。

function IMA:showCredentialDialog()
    Settings().showCredentialDialog()
end

function IMA:showCredentialInfo()
    Settings().showCredentialInfo()
end

function IMA:confirmClearCredentials()
    Settings().confirmClearCredentials()
end

function IMA:showRawResponse()
    Settings().showRawResponse()
end

function IMA:showAbout()
    Settings().showAbout()
end

return IMA
