local _ = require("gettext")
return {
    fullname = _("IMA 知识库"),
    description = _([[通过腾讯 ima 开放平台接口，在 KOReader 中浏览与检索你的个人知识库。]]),
    version = "0.6.20",
}
