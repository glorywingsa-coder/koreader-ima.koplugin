# IMA 知识库 · KOReader 插件（v0.6.20）

在 KOReader（Kobo 等设备）里浏览、检索并**在线阅读**腾讯 **ima 个人知识库**。

走的是 ima **官方开放平台接口**，不是逆向：

| 项目 | 值 |
| --- | --- |
| Base URL | `https://ima.qq.com` |
| 知识库线 | `/openapi/wiki/v1` |
| 笔记线 | `/openapi/note/v1` |
| 协议 | HTTP POST + JSON body |
| 认证 | 三个请求头：`ima-openapi-clientid` / `ima-openapi-apikey` / `Content-Type: application/json` |
| 返回 | `{ code, msg, data }`，`code == 0` 为成功 |
| 分页 | `cursor` + `limit`，响应带 `next_cursor` / `is_end`；**各接口上限不同，见下** |
| 正文 | `get_media_info` 取**临时签名 URL**（自助下载），笔记走 `get_doc_content` |

> ⚠️ **`limit` 上限各接口不统一，不能共用一个数字。**
> 服务端对越界值是**直接报错**而非静默截断：
> `{"code":51,"msg":"invalid XxxReq.Limit: value must be inside range (0, N]"}`。
> 实测边界（2026-10-07）：
>
> | 接口 | 上限 |
> | --- | --- |
> | `search_knowledge_base`（列库 / 搜库） | **20** |
> | `get_knowledge_list`（浏览目录） | 50 |
> | `search_knowledge`（库内检索） | 未设硬上限 |
>
> v0.3.0 曾把这几个统一写成 50，导致**首屏必然打不开**（列库走的是上限 20 的
> `search_knowledge_base`）。现已按接口分别限位，并在 `api.lua` 里加了
> `call_with_autolimit`：一旦被上面的文案拒绝，就从消息里解析出真实上限重放一次。

因为认证只是两个静态请求头，**整份插件是纯 Lua，不需要编译任何 native 库**——
这一点和 miuread（需要交叉编译 `miucodec.cpp` 到 Kobo ARM）完全不同。

---

## 安装

```
# 解压后目录结构应为：
koreader/plugins/ima.koplugin/
```

1. 把 `ima.koplugin` 整个目录拷到设备的 `koreader/plugins/` 下
2. 重启 KOReader（或重载插件）
3. 主菜单 → 更多工具 → **IMA 知识库** —— 点一下**直接进入知识库列表**

### 作为觅阅的扩展使用

觅阅（miuread）内置了插件桥接层，会自动发现并收录第三方 KOReader 插件，
**不需要修改觅阅一行代码**。装好并启用后：

```
觅阅首页 → 插件与扩展 → 已安装扩展 → IMA 知识库   （点一下直接进列表）
```

桌面模式走首页菜单按钮的「工具」，经典模式走主菜单的「觅阅 · 微信读书助手」。

> 之所以两侧都是「一级点击即进入」，是因为 `addToMainMenu` 里**刻意只注册了一个
> 无 `sub_item_table` 的条目**。觅阅的 `native_plugins.lua` 在只抓到单个 callback
> 条目时会走「直接执行」分支。若改回 `sub_item_table`，两侧都会退化成两级菜单。

**再快一点：首页下拉就能点**（v0.6.7 新增）。在**觅阅首页顶部区域向下滑**，
弹出的快捷面板里会多出一格「IMA 知识库」，点一下直接进列表。

```
觅阅首页（顶部区域下滑）→ 快捷面板 → [ Wi-Fi ][ 方向锁定 ][ IMA 知识库 ] … 
```

> 这一格不在觅阅的预设里：它的面板是**白名单式**的（条目池是 17 项硬编码，
> 上限 8 格，且没有给第三方留注册接口）。本插件是在**内存里包装它的渲染函数**、
> 把这一格插进去的 —— 不改觅阅任何文件、不写它任何设置。
> 完整取证与取舍见 `ima/miuread_bridge.lua` 顶部注释。

### 觅阅升级之后要做什么

**先直接装、直接用 —— 不存在"重新关联"这一步。**

本插件与觅阅之间**没有任何需要建立的绑定关系**：不注册条目、不申请授权、不写觅阅任何文件
或设置。全部交互都是**运行时按名字挂钩**（拿到觅阅实例和方法引用、替换一次函数引用），
而且每一处都包在 `pcall` + 类型检查里 —— **挂钩点找不到就静默跳过，最坏结果是"这个功能
不出现"，绝不会崩**。所以觅阅更新后，大多数情况什么都不用做。

只有当出现下表中**某个特定症状**时，才需要按图索骥去改对应的挂钩点：

| # | 挂钩点（觅阅侧） | 用来做什么 | 失效时的症状 |
| --- | --- | --- | --- |
| 1 | `PluginLoader.getPluginInstance(PluginLoader, "miuread")` | 取觅阅插件实例（其余挂钩的前提） | 全部觅阅适配静默关闭。KOReader 官方 API，基本不会变 |
| 2 | `plugin._uninstall_reader_toolbar_hooks(plugin, readerui, reason)` | 摘掉已装的阅读面板接管 | 阅读器里**顶部下滑弹出的是觅阅面板**、改不了字号 |
| 3 | `plugin._sync_reader_toolbar_hooks(plugin, reason)` | 挡住后续重装（reader ready / 旋屏 / resume 都会再同步一次） | 刚进阅读器正常，**旋屏之后**觅阅面板又回来了 |
| 4 | `readerui._miuread_original_onHome` / `readerui._miuread_original_showFileManager` | 把退出通道还原成 KOReader 原生的 | 退出阅读器时**弹回觅阅首页**，而不是知识库列表 |
| 5 | `HomeView.unpark()` + `_miu_input_suspended`（`home_view.lua`） | 解冻被觅阅"停放"在阅读器下面的首页输入 | **退出阅读器后整屏没反应**（就是当年那个"卡死"） |
| 6 | `miuread.home_quick_panel` 的 `show(opts)` / `opts.buttons` | 在首页下拉面板里插一格「IMA 知识库」 | 只是**面板里少一格**，其余一切照常 |
| 7 | 窗口标记 `_miuread_transient` / `_miuread_modal_surface` | 抬列表时判断"这一层要越过" | 退出后知识库列表**抬不回来**、或抬得比预期慢 |

**代码落在哪 —— 只需要记两处：**

- **第 6 项（首页下拉面板入口）整条链路只在 `ima/miuread_bridge.lua` 一个文件里**（约 150 行）。
  它对觅阅的依赖只有四个名字：模块名 `miuread.home_quick_panel`、该模块的**模块级** `show(opts)`
  函数、`opts.buttons` 这个数组、以及条目字段 `icon_key` / `label` / `detail` / `callback`。
  连图标都是复用觅阅自带的（`icon_key = "library"`），图标没了只会退到 `more.svg`，不报错。
  ⇒ **"面板里少了一格"只改这个文件，不会牵动别处。**
- 其余 #1~#5 与 #7 都在 `ima/reader_session.lua`。
  ⇒ **"阅读器里不对"或"退出时不对"才去改它**，跟面板那格一点关系都没有。

**不受觅阅升级影响的部分**（用的都是 KOReader 自己的名字，KOReader 版本不变就不必动）：
FileManager 的识别（`apps/filemanager/filemanager` 的 `.instance`）、`UIManager` 的窗口栈与
插栈规则、阅读器手势 zone、`ReaderUI:onClose`。

**日志标志**（`[MiuRead][Home] FileManager base ready`、`[ReaderClosePerf] FileManager base
created show_ms=N`）只用于排查，改名不影响功能。

怎么快速判断挂钩还活着：打开一次 IMA 文档，`crash.log` 里若出现

```
[ima] 本次阅读使用 KOReader 原生阅读器（已临时摘除觅阅阅读面板接管）
```

就说明 2/3/4 三条都命中了（注意这行要求觅阅插件实例能被取到；没装觅阅时不会有它）。

## 配置凭证

### 1. 拿到 Client ID 与 API Key

**前置条件**：在电脑上安装 **腾讯 ima 客户端**（Mac / Windows），并用微信登录 ——
凭证与你在 ima 里的**个人知识库同属一个账号**，所以务必用同一个微信登录。
网页版 ima 本身**不能**完成这一步，agent-interface 页面会调起本地客户端。

两个等价入口，任选其一：

| 入口 | 路径 |
| --- | --- |
| 网页跳转（推荐） | 打开 <https://ima.qq.com/agent-interface> → 点「获取 API Key」→ 自动跳转到本地 ima 客户端 → 弹出凭证 |
| 客户端内直达 | ima 客户端 → 左上角**头像** → **CLAW 配置 (beta)** → 「获取 API Key」 |

弹出的两个值：

- **Client ID** —— 应用标识，对应请求头 `ima-openapi-clientid`（可再次查看）
- **API Key** —— 调用密钥，对应请求头 `ima-openapi-apikey`（**只显示一次**）

> ⚠️ **API Key 只展示一次。** 拿到就立刻记下。
> 如果之前已经生成过，页面上会提示"已存在"，此时需要先点**删除**，再重新获取。
> 泄露同样走这条路：删除重建即可，旧 Key 立即失效。

### 2. 填进插件

KOReader → **IMA 知识库** → **设置与凭证** → **配置凭证**，把两个值分别填入后保存。

未配置凭证时直接进入列表，会先弹出「去配置」的引导，而不是抛一个接口错误。

### 3. 或者：直接在电脑上写好再推进设备

设备上打字很痛苦。凭证最终存在 `koreader/settings/ima.lua`，
它就是一个被 `dofile` 执行的 Lua 文件（`LuaSettings:open`），所以可以直接手写：

```lua
-- koreader/settings/ima.lua
return {
    ["client_id"] = "你的 Client ID",
    ["api_key"]   = "你的 API Key",
}
```

如果 Kobo 支持 SSH/SCP，把这份文件推过去后重启 KOReader 即可，全程不用在设备上敲键盘。
插件写入时会把文件权限收紧到 `0600`；手动创建的文件建议同样 `chmod 600`。

## 界面结构

```
IMA 知识库                        ← 一级点击直接落到这里
├── 搜索知识库…                   ← 按名称搜库
├── 设置与凭证                    ← 子菜单（关闭按钮即退回列表）
│   ├── 配置凭证
│   ├── 查看当前凭证
│   ├── 清除凭证
│   ├── 打开文档时的版面           ← 跟随系统默认（默认）/ 内容宽 / 页宽 / 整页
│   ├── 翻页不切断文字（自动对齐整行） ← 开 / 关（默认开）
│   ├── 打开文档自动横屏（退出恢复） ← 开 / 关（默认开；正文放大 1.33×）
│   ├── 清理下载缓存
│   ├── 调试：查看接口原始响应
│   └── 关于 IMA 知识库
└── 知识库条目 …                  ← 点文件即在线阅读，点文件夹进入下一层
    ├── 搜索此知识库…             ← 库内关键词检索
    ├── ← 返回上一级
    ├── 碳酸锂2026Q4展望.pdf  ·  PDF
    └── 加载更多…
```

## 在线阅读

点条目会走这条链路：

```
缓存命中 ──是──> 交给阅读器打开（秒开）
   │
   否
   ↓
get_media_info 取临时签名 URL
   ↓
流式下载到 koreader/cache/ima/
   ↓
按档位写文档阅读设置（默认：不插手版面；打开即横屏；翻页按行网格对齐）
   ↓
ReaderUI:showReader(path, …, after_open_callback)
   ↓
打开后：摘除觅阅对阅读器的接管 + 按文档真实行位置对齐翻页 + 兜底重叠一行
```

打开后**阅读器就是 KOReader 原生界面**：物理翻页键、点按翻页、字体大小、
排版设置、阅读器菜单全部照常可用。想退出时用阅读器菜单里的
**「← 返回 IMA 知识库」**，会直接落回知识库列表（而不是先回到觅阅首页）。

**从哪退出：顶部下滑**（v0.6.8 起）。知识库列表里「下滑」本来就是返回上一层
（KOReader 自带的 `Menu:onSwipe`：`south → onClose()`），而 KOReader 的**阅读器**
偏偏把屏幕顶部 12.5% 条带（`DTAP_ZONE_MENU = {x=0, y=0, w=1, h=1/8}`）的下滑
固定绑成了「打开阅读器菜单」（`ReaderMenu:onSwipeShowMenu`）—— 同一个手势两处
含义相反。现在本次阅读（由 IMA 发起的文档）里**顶部下滑也返回知识库列表**，
和菜单里的「← 返回 IMA 知识库」走的是**同一条退出路径**（所以阅读进度、
文档设置照常落盘）。
想做回原生行为，在「设置与凭证 → 阅读界面顶部下滑 = 返回列表」里关掉即可。
**顶部「点按」不受影响**，所以阅读器菜单照样打得开（字号 / 排版都在里面）。

**退出时不会闪出 KOReader 的文件列表**（v0.6.9 → v0.6.11 三轮打磨）。原本的退出走
`ReaderUI:onHome()`，而它在 `onClose()` 之后还会 `showFileManager(当前文档)`
（`readerui.lua:929`）—— 文档就在 `cache/ima/` 下，于是 KOReader 会**新建一个
FileManager 并把目录切过去**，插在知识库列表**上面**：先闪一眼文件列表，1.8 秒后
才被抬回的列表盖住；而且那个 FileManager 会一直留在窗口栈里，导致在知识库列表上
再下滑（KOReader 自带的 `Menu:onSwipe` → `onClose()`）退到的是 `cache/ima`
的文件列表，而不是本该露出的觅阅首页。现在退出只调 `onClose()`
（落盘、阅读进度、`CloseDocument` 事件都照旧），关掉阅读器后露出的就是**本来就
压在下面的窗口** = 知识库列表本身。KOReader 里其它「回家」入口
（`ReaderBack` 在文档开头再返回一次会发 `Event:new("Home")`）也一起改道，
只有在阅读 IMA 文档时生效，普通书籍的退出行为一点没变。

> **但只做这一半还不够。** 觅阅自己也把 KOReader 的文件管理器当桌面模式的
> 「底座」，阅读器一关它就调 `Plugin:_ensure_filemanager_base`
> （miuread `main.lua:17572`）把底座补回来；`FileManager.instance` 不存在时它走
> 创建分支，用 `HOME_RETURN_FILE`（= 刚读过的那本书）推出目录 —— 正是
> `cache/ima` —— 然后 `FileManager:showFiles(dir)` → `UIManager:show(file_manager)`
> 把文件管理器插到列表上面。所以退出后还要有一步「收掉它」，
> 见 v0.6.10 与实现要点 10。
>
> **v0.6.11 又补了两处**：① 守护拍点从 4 拍加密到 10 拍，把「文件管理器在屏幕上
> 停 3 秒」压到 0.5 秒以内；② 用户在列表上下滑**自己关掉**界面时守护必须停手 ——
> 否则一拍之后列表又会被 show 回来（实测就是「下滑 → 露出下一层 → 又弹回列表」）。
> 两种情况怎么区分见实现要点 11。

**插件不替用户决定版面**：默认档「跟随系统默认」一个 zoom 键都不写，
文档打开的样子跟平时在 KOReader / 觅阅里打开一本书完全一致。
要放大正文就用**阅读器菜单里的「排版」面板**（那层被觅阅接管的入口本插件
已经摘掉，打得开）。

想换别的版面，在「设置与凭证 → 打开文档时的版面」里切：
**跟随系统默认（默认）/ 适应内容宽度 / 适应页宽 / 整页显示**。

> **翻页不切断文字**：KOReader 的 PDF 默认带**页间重叠**（连续视图是固定的
> `DOVERLAPPIXELS = 30` 像素，整页视图是 36%），所以翻页时会看到上一屏的
> 尾巴 —— 而固定重叠在不同文档里对应的行数不同，于是「不同文档重复量还不一样」。
>
> 本插件**不给固定值**，而是每次向下翻页前现算：用
> `document:getPageTextBoxes()` 取到这一页**每一行的真实 y 坐标**
> （走 MuPDF 的 stext 设备，**不经过 k2pdfopt 重排引擎**，所以不会踩"重排 = 卡死"
> 那颗雷），让**下一屏的底部正好落在某个行顶**上 ⇒ 屏幕最后一行永远是**完整的**，
> 重复量同时压到最小。可在「设置与凭证 → 翻页不切断文字（自动对齐整行）」
> 里关掉（关掉即归还 KOReader 原生重叠）。
>
> 为什么不能用固定值：本库 PDF 的行距**不统一** —— 用 PyMuPDF 逐行量过 16 份样本
> （`outputs/_tools/linegrid_probe.py`），相邻行顶差有 **21.75 / 21.0 / 34.5 /
> 35.25 / 53.46pt** 五种（段内正文与标题前后不一样）。固定值只可能对齐其中一种：
> 按真实行框做的离线模拟（`outputs/_tools/overlap_sim.py`，72~80 屏）显示，
> `0 ~ 71pt` 里**任何**固定值的切字率都在 **59% ~ 73%**。
> ⚠️ 代价：**第一屏**（页面顶端）的底部仍可能切字 —— 这是滚动阅读固有的，
> 要让它也对齐就得裁掉页面顶部一截、那会丢掉文档开头。**从第二屏起就整齐了。**

> ⚠️ **知识库里的研报是浏览器打印的纯文字 PDF**：实测
> `Producer = Skia/PDF m154`、正文 18pt、页面宽 598pt、单页超长
> （`doc_pages = 1`），没有位图图像对象但**有矢量图表**。
> 按宽度铺满 1264px 屏之后正文只有 9.1pt（约 3.2mm），偏小但清晰 ——
> 这是 PDF 的物理事实，不是显示错误。
>
> **想放大，最省事的办法是横屏**（v0.6.6 实测）：竖屏
> `1264 / 598 = 2.11 px/pt`，18pt 正文只显示 9.1pt；**横屏
> `1680 / 598 = 2.81 px/pt` → 12.1pt，正好 1.33×**，不重排、不等待、
> 不崩，KOReader 旋转后自动重算缩放，插件一个字都不用改。代价只是
> 一屏装的页面高度变少、翻页变多。
> ⚠️ **v0.6.19 更正**：上面这句"插件一个字都不用改"到 v0.6.18 就不成立了 ——
> 现在有一个**默认开启**的「打开文档自动横屏（退出恢复）」，等于把"每次手动转
> 一下"那一步替你做了。（v0.6.18 时它是默认**关**的，结果用户压根没去翻设置项，
> 于是"打开文档不转"、被当成功能没做，v0.6.19 因此改成默认开。）
> 见 v0.6.18 / v0.6.19 章节。
> 另一条路是「重排」（`kopt_text_wrap`），但本库文档上有两个硬伤
> （v0.6.2/0.6.3 实测）：**打开要 56 秒**；并且因为 KOReader 把文档语言
> 默认成 `eng`（`kopt_doc_language`），k2pdfopt 不按 CJK 断行，中文会被排成
> **满屏空格**。所以本版不默认开重排，也不提供任何字号设置 —— 需要时自己
> 在阅读器的「排版」面板里开，插件不插手。
> 想彻底解决（离线、与插件无关）：用 PyMuPDF 把单页超长 PDF 按屏幕比例
> **切片**成多页纯矢量 PDF，见下方第 7 条与 `outputs/_pdf_display_probe/`。

**能直接打开的格式**（由 KOReader 的 provider 决定）：
`pdf` `epub` `txt` `html` `mobi` `fb2` `cbz` `djvu` `rtf`，以及
`jpg` `jpeg` `png` `gif` `bmp` `webp` `tif` 等图片。

**打不开的格式**：`docx` / `xlsx` / `pptx`。KOReader 没有这类 provider，
插件会在**下载前**就如实告知，不会先耗流量下几十 MB 再报错。

> 实测这个个人知识库 678 条内容里：PDF 639、Word 34、图片 4、Excel 1
> —— 也就是约 **95% 可以直接在线阅读**。

### 几个实现上的取舍

- **URL 不缓存，只缓存文件。** `get_media_info` 返回的是**临时签名**地址
  （query 里带 `sign` / `t`），每次点开都重新取一次。
- **必须流式落盘。** 用自建的 `ltn12` sink 边收边写，绝不把整个文件读进内存
  —— Kobo 内存有限，一个几十 MB 的 PDF 一次性 load 会直接把设备拖死。
- **先写 `.part` 再原子改名。** 下载中断时必须删掉半截文件，
  否则下次点开会命中「缓存」打开一个残缺文件，这种错误比下载失败更难查。
- **下载无法中途取消。** Lua 单线程 + KOReader 的主循环模型决定了同步下载期间
  收不到输入事件，兜底靠 `DOWNLOAD_TOTAL_TIMEOUT`（默认 600 秒）。
- **缓存托管在 `koreader/cache/ima/`**，文件名是「清理过的标题 + media_id 短哈希」，
  与设置文件分开，不会被误当作书籍扫描。可用「设置与凭证 → 清理下载缓存」清空。
- **不改觅阅的设置文件，也不持久化任何觅阅状态。** 摘除那层包装是**运行时**行为，
  只对本次打开的这份 `readerui` 生效；阅读器关闭后由
  `PluginLoader:finalize()` 自然回收，觅阅在别处一切照旧。
- **抬回列表不跟觅阅抢位置。** 只在栈顶是普通窗口时才把自己抬上去；
  遇到模态框 / 觅阅的临时交互面板就放弃本次，避免盖住正在进行的操作。

## 已实现

- **觅阅首页下拉面板直达**（v0.6.7）：在觅阅首页顶部下滑的快捷面板里有
  「IMA 知识库」一格，点一下进列表（面板有空位时追加在末尾，满 8 格时插到最前）
- **可绑手势 / 热键**（v0.6.7）：注册了 KOReader 的 Dispatcher 动作，
  可在**手势管理器 / 热键 / Profiles** 里把「打开 IMA 知识库」绑到任意手势或按键
- 列出账号下可访问的全部知识库（条目右侧标注服务端返回的 `base_type`，如「个人知识库」）
- 逐层浏览目录（进入子文件夹、返回上一级）
- 按名称 / 关键词搜索知识库
- 在单个知识库内按关键词检索内容
- **点条目在线阅读**（PDF / 图片 / EPUB 等 KOReader 原生支持的格式），带下载进度提示
- **阅读器完整可用**：物理翻页键、点按翻页、字体大小、排版设置、阅读器菜单全部照常；
  阅读器菜单里有「← 返回 IMA 知识库」直达列表
- **顶部下滑 = 返回知识库列表**（v0.6.8）：与列表里的下滑手势统一；顶部**点按**
  仍可打开阅读器菜单。可在「设置与凭证」里关掉，恢复 KOReader 原生行为
- **退出不闪文件列表**（v0.6.9 → v0.6.11）：退出只关阅读器，不会顺手拉出 KOReader 的
  FileManager（原生的 `onHome` 会，并把目录切到 `cache/ima`）；**而且觅阅随后
  补回来的那个「文件管理器底座」也会被收掉**，所以退出后看到的一定是知识库列表，
  不会是缓存目录（v0.6.9 漏掉的正是这一步）。退出后有两秒多的窗口栈守护
  （10 拍），期间不会被任何窗口顶掉；但用户在列表上**自己下滑关掉**时立刻停手，
  不会把已关掉的界面弹回来
- **不替用户改版面**：默认档「跟随系统默认」一个 zoom 键都不写，文档按 KOReader
  原生默认打开；字号 / 行距用阅读器菜单的「排版」面板自己调
- **翻页不切断文字**（v0.6.19 起，v0.6.20 修正）：每次向下翻页前，读文档
  **真实行位置**（`PdfDocument:getPageTextBoxes`，走 MuPDF stext，不经重排引擎），
  按**当前实际滚动位置**把屏幕底部**对齐到某个整行的顶边** —— 屏幕底边永远压不住字；
  上一屏被切掉的那一行也会被下一屏完整救回。拿不到行框时退回「重叠一行」
  （正文行距 21.75pt × 当前缩放 = 竖屏 46px / 横屏 61px）；含运行时 +
  布局重算两道钉子
- **列表分页不环绕**（v0.6.20）：知识库 / 文档列表翻到第 1 页再往右划**不会**跳到
  最后一页（KOReader 原生的 `Menu:onPrevPage` 是环绕的，退出阅读器后飘来的那一划
  会正好踩中它）
- **版面可换**：跟随系统默认（默认）/ 适应内容宽度 / 适应页宽 / 整页显示
- **笔记正文读取**（`media_type = 11` 走 note 线，落成 `.txt` 交给文本阅读器）
- **本地缓存**：下过的文件再次打开是秒开；提供「清理下载缓存」
- **游标分页**：列表底部「加载更多…」用 `next_cursor` 续取（目录类接口单页上限 50，
  实测某个人知识库有 678 条内容，不分页根本看不全）
- 列表内直接管理凭证（设置与凭证 → 配置 / 查看 / 清除），右侧显示「已配置 / 未配置」
- 「调试：查看接口原始响应」——把 `search_knowledge_base` 的原始 JSON 摊开显示
- **失败落日志**：任何请求失败都会 `logger.warn` 出 URL、HTTP 码、错误文案与响应片段
  （凭证不打印），便于直接从 `crash.log` 定位问题，不必只依赖界面弹窗

## 尚未实现

- **公众号文章 / 网页（`WECHAT_ARTICLE` / `WEB`）的正文渲染**。
  这两类返回的是网页 URL，直接下 HTML 给 KOReader 看效果很差，
  需要先清洗成可读的 HTML 或打包成 EPUB。实测这个库里没有这类内容，暂未做。
- **Word / Excel / PPT 的格式转换**。KOReader 无对应 provider，
  要做需要在服务端或本地先转 PDF。
- 写操作（上传文件、导入链接、建目录）
- 跨库搜索（接口是单库的，需要逐库调用后自行汇总）

---

## 代码结构

```
ima.koplugin/
├── _meta.lua              插件元信息
├── main.lua               插件注册与菜单装配（只注册一个可点击条目）
└── ima/
    ├── constants.lua      接口常量（Host / 路径 / 请求头 / 枚举 / 超时）
    ├── util.lua           纯函数小工具
    ├── config.lua         凭证读写（LuaSettings + chmod 0600）
    ├── http.lua           POST JSON + 解析 {code,msg,data} 信封
    ├── api.lua            接口封装
    ├── models.lua         把响应规整成界面可直接用的结构
    ├── downloader.lua     下载与本地缓存（临时签名 URL → 流式落盘）
    ├── reader_session.lua 阅读会话：版面档位 / 翻页按行网格对齐（兜底一行高）/ 自动横屏（退出恢复）/ 顶部下滑返回列表 / 退出不拉 FileManager / 收掉觅阅补回的文件管理器 / 抬回守护（认用户主动关闭）/ 关闭探针 / 摘除觅阅接管
    ├── miuread_bridge.lua 与觅阅的桥接：把入口插进它首页的下拉快捷面板
    │                      （内存包装其渲染函数；不改觅阅文件、不写其设置）
    ├── ui/
    │   ├── loader.lua     加载提示 / 进度提示 / 联网检查 / 提示条
    │   └── menu.lua       通用列表菜单
    └── views/
        ├── kb_list.lua    知识库列表（一级界面，含顶部工具栏）
        ├── kb_browser.lua 目录浏览（点条目进阅读）
        ├── reader.lua     在线阅读编排：缓存 → 下载 → 交给阅读器
        ├── search.lua     两种粒度的检索
        └── settings.lua   设置 / 凭证 / 缓存管理的各个对话框
```

### 十一个实现要点

**1. 传输层复用 KOReader 自带的 `socket.http`。**
KOReader 的 `common/socket/http.lua` 内置了 `https` 分支
（内部自动调用 `ssl.https.tcp`），所以一次 `http.request{ url = "https://..." }`
就能同时支持 http/https，不需要分别 require。超时用 `socketutil:set_timeout()` 控制，
和 `customisablesleepscreen` 里的做法一致。

**2. 菜单只注册「一个 callback 条目」。**
`addToMainMenu` 里刻意不给 `sub_item_table`。KOReader 原生菜单与觅阅的插件桥接层
遵循同一条规则：单一 callback 条目会被直接呈现为可点击项。这样「IMA 知识库」
点一下就是知识库列表，而不是先弹一个二级菜单。改回去两侧都会退化。

**3. views 之间用惰性 require 打破循环依赖。**
`kb_list → kb_browser → search → kb_list` 天然成环，而 LuaJIT 的 `require`
没有「加载中」哨兵（不像 Lua 5.2+），顶层互引会无限递归。所以凡是构成环的
依赖都改成了函数内 `require`。

**4. 循环变量不要用 `_`。**
`_` 在本项目里是 gettext 的翻译函数。写成 `for _, entry in ipairs(...)` 会把它
覆盖成数字下标，此后循环体内任何 `_("...")` 都会以

```
attempt to call upvalue '_' (a number value)
```

直接崩掉 KOReader —— 这正是 v0.4.0「点文件就崩溃」的根因。
这类错误**语法检查查不出来**，只在运行到那一行才爆，因此已把项目里的
`for _,` 全部改写掉，并在校验脚本里加了专门的检查。

**5. 与觅阅共生，而不是对抗。**
觅阅在 desktop 模式下会接管 ReaderUI 的菜单入口与退出通道 —— 这对「在觅阅首页里
直接看微信读书」是必要的，但会让 IMA 这类**外部文档**的阅读器失去原生能力。
处理方式不是去改觅阅的文件，而是**调用觅阅自己暴露的私有接口**在同一进程里
卸掉那层包装（`_uninstall_reader_toolbar_hooks`），并在它重新同步时拦一手。
所有对觅阅的调用都包在 `pcall` 里且**先探测是否存在**，所以觅阅升版/改名
最多让这层优化失效（退回被接管的状态），不会让插件崩掉。

同一条原则也用在**入口**上（v0.6.7）。现在有两条独立入口：
- **KOReader 的动作（Dispatcher）** —— 这是阅读器的**公开**扩展点，
  注册后可在手势管理器／热键／Profiles 里绑定；
- **觅阅首页的下拉快捷面板** —— 这个面板**没有**公开扩展点，
  只能在内存里包装它的 `show(opts)` 往按钮数组插一项
  （见 `ima/miuread_bridge.lua` 顶部对白名单机制的完整取证）。
两条都不碰对方文件，都做了幂等与降级，且互不依赖：觅阅面板不读 Dispatcher，
所以绑定手势**不会**让 IMA 出现在面板里。

**6. 版面这件事，先用真实文件量一遍再决定。**
v0.6.0 曾为 PDF 强制写入「整页显示」，理由是「A4 按宽度适配后高度超屏」——
被实测推翻。v0.6.1 改成「什么都不写」，实测反馈是「显示正常了，但正文太小」。
v0.6.2 又改成「默认开重排、顺手放大字号」，实测反馈是「打开 56 秒 + 满屏空格」。
三次都说明：**这类「看起来像 bug」的判断，必须先量真实文件**。
量完之后的结论：

- 研报不是长图截图，是**浏览器打印**出来的**纯文字** PDF
  （`Producer = Skia/PDF m154`、有 Type0/CJK 字体对象、有 ToUnicode 映射、
  位图对象 0 个）；
- 正文 18pt、页宽 598pt，铺满 1264px 屏后只剩 **9.1pt** —— 偏小是物理事实；
- PDF 上「能调字号」**等价于**「打开 Reflow」，而 Reflow 在本库文档上有两个硬伤：
  - **慢**：整页 5548pt 高 + 大量矢量图，实测打开一份 56 秒；
  - **满屏空格**：KOReader 的 `kopt_doc_language` 默认 `"eng"`，而
    `KoptInterface:createContext` 只在语言是 `chi_sim`/`chi_tra`/`jpn`/`kor`
    时才调 `kc:setCJKChar()`。于是 k2pdfopt 拿中文当拉丁文断行，再叠加默认的
    `justification = 3`（full，两端对齐）—— 中文被拆成一格一格的空隙。

  所以 v0.6.4 起的结论是：**字号这件事不归插件管**。默认「跟随系统默认」
  （一个 zoom 键都不写），要放大就用阅读器自带的「排版」面板；
  插件只保留一处主动改动 —— 「翻页不切断文字（自动对齐整行）」。
- 判断 PDF 时要量的是 `MediaBox`、内容流里的字体/图像对象、以及 `BT`/`Tj`
  文本操作符数量 —— 只看宽高比会把它误判成「长图」。

**7. 「不重排也要放大」这条路，逐条量过一遍。**

v0.6.6 把「除了开重排，还有没有别的办法把正文放大」问了一遍，并在真机
源码 + 真实文件上逐条验证。结论先给：**唯一零风险的办法是横屏，而且
不需要插件写一行代码**。其余路径都被否决，理由如下（都可在源码里复核）。

- ✅ **横屏（推荐）**：KOReader 的放大倍数就是 `视口宽(px) ÷ 页宽(pt)`
  （`ReaderZooming:getZoom`，zooming.lua）。这台 Libra 2 是 1264×1680px、
  300dpi，页宽 598pt：
  - 竖屏 `1264 / 598 = 2.113 px/pt` → 18pt 正文只剩 **9.13pt**；
  - 横屏 `1680 / 598 = 2.809 px/pt` → **12.13pt**，正好 **1.329×**
    （≈ 之前想要的 1.3 倍），且**不重排、不变形、不等待**。
  - 代价只有一个：一屏能装的页面高度从 795pt 降到 450pt，**翻页变多**。
  - 关键点：`ReaderZooming:onRotationUpdate` 会在旋转后自动重算缩放，
    所以**默认档（跟随系统默认）旋转即可生效**，插件无需介入。
    旋转是屏幕级（全局）的，别的书也一起横过来。
  - ⚠️ **v0.6.18 更正**：这一段是 v0.6.6 当时的结论，其中**最后一句是错的** ——
    旋转其实有**文档级**记录（`kopt_rotation_mode`，见 readerview.lua:968-975
    与 1219-1222），只是那一轮没查到这一层，才以为"只能全局、别的书也跟着转"。
    v0.6.18 正是用这一层实现的「打开文档自动横屏 / 退出恢复」，
    所以**别的书不会被一起转过去**。详见 v0.6.18 章节。
- ❌ **分栏（columns/rows）**：`getZoom` 的 else 分支是
  `zoom = zoom_w * zoom_factor`（`kopt_zoom_factor` 默认 1.5），渲染宽度
  必然溢出视口宽 —— 单栏中文会被切成「所有行的左半屏 → 所有行的右半屏」，
  阅读顺序直接断裂。（`setNumberOf("rows")` 另乘 `zoom_h/zoom_w`，还依赖
  文档高度，更不可控。）
- ❌ **双击局部放大（free zoom）**：它要 `document:getPageBlock` →
  `page:getPagePix` 把整页按 300dpi 光栅化（598×5548pt ≈ 1260×11700 灰度
  ≈15MB），再过 leptonica `findPageBlocks()`。首次必然卡顿，和重排崩溃
  属于同一族内存问题。
- ❌ **裁页边 / 页边距归零**：本机已是 `trim_page = auto`，且 `getZoom`
  本来就按 content bbox 计算；把 `page_margin` 归零只多出约 **2.4%**，
  没有意义。
- 🏆 **根治（离线、非插件能力）**：把单页超长 PDF 按视口比例**切片**成
  多页纯矢量 PDF（PyMuPDF `set_cropbox`）—— 不失真、体积不增，每页宽高比
  恰好对上 1264:1680，横竖屏都能整页看、字号按屏宽自然放大。已实测两份
  样张（1→7 页、1→4 页），每页仍可正常提取文字；样本在
  `outputs/_pdf_display_probe/`。

**8. 改「手势」先看它被谁注册 —— zone 是闭包，实例方法才是稳的。**

v0.6.8 把阅读界面顶部下滑从「打开菜单」改成「返回知识库列表」时，第一反应
是去重新 `registerTouchZones` 覆盖 `readermenu_swipe` —— **这是错的**：

- KOReader 阅读器的顶部手势来自 `readermenu.lua:98-174` 的
  `self.ui:registerTouchZones{...}`，四个 zone（`readermenu_swipe` /
  `readermenu_ext_swipe` / 两个同区 `pan`）的 `handler` 都是闭包，写的是
  `function(ges) return self:onSwipeShowMenu(ges) end` —— 方法名**调用时**
  才在 `self` 上解析。
- 所以：**在 ReaderMenu 实例上包一层 `onSwipeShowMenu`**，能活过
  `ReaderMenu:onSetDimensions`（旋屏、ReaderReady 都会把 zone 再注册一遍）；
  反过来，若自己去注册同名 zone，下一次 `initGesListener` 就把我们覆盖掉，
  而且 `InputContainer:registerTouchZones` 是按 `id` 覆盖的，改错 id 还会
  让同一控件在 `_ordered_touch_zones` 里出现两份。
- 顺带：`readermenu.lua` 里 `tap` 与 `swipe` 是**分成两组 zone** 的
  （`readermenu_tap` → `onTapShowMenu`，`readermenu_swipe` →
  `onSwipeShowMenu`），所以只包 `onSwipeShowMenu` 就天然实现了
  「下滑返回、点按仍开菜单」—— 不用自己再判断手势类型。
- 事件顺序也一样有讲究：原文是在 `onShowMenu()` **之后**才发
  `Event:new("HandledAsSwipe")`（告诉阅读器这一划已被消费、别再当滚动/翻页）；
  我们要退出阅读器，所以必须**先发**再退出 —— 反过来的话，`self.ui`
  已经是拆掉后的残骸了。

**9. 退出阅读器要用 `onClose`，不要用 `onHome` —— 后者会顺手把 FileManager 拉出来。**

v0.6.9 修的「关掉阅读器先闪一下 KOReader 的文件列表，之后在列表上再下滑还退到
`cache/ima`」就出在这一行上（`readerui.lua:929`）：

```lua
function ReaderUI:onHome()
    local file = self.document.file
    self:onClose()
    self:showFileManager(file)   -- ← 问题在这一行
    return true
end
```

- `showFileManager(file)` → `file_chooser:changeToPath(文档所在目录)`。本插件的
  文档都下载在 `cache/ima/` 下，所以这一句等于「新建一个 FileManager，并把
  目录切到缓存目录」。真机日志里的证据很好认：退出那一刻会重跑
  `[MiuRead][Startup] begin`、`[Customisable Sleep Screen] initialised`
  一整串 —— 那就是 FileManager 与各插件的 `init` 被重新执行了一遍
  （`PluginLoader:finalize()` 刚在 `onClose` 里把插件实例销毁掉）。
- 更要紧的是窗口栈：`UIManager:show` 的插入规则是
  **「插在最上面那个非模态窗口之上」**（`uimanager.lua:185-198`），
  于是新建的 FileManager 被 push 到**知识库列表上面**。两个后果：
  1. 列表要等 1.8s 后的 reclaim 才盖回来 —— 中间那一眼就是「闪现」；
  2. FileManager 会一直留在栈里，之后在知识库列表上再下滑
     （`Menu:onSwipe` → `onClose()`）露出来的是 `cache/ima` 的文件列表，
     而不是压在下面本该露出的觅阅首页。
- 正确做法：只调 `onClose()`。落盘、阅读进度、`CloseDocument` 事件、
  `saveSettings` 全在里面，与 `onHome` 的前半段完全一致，差别只有
  **「要不要顺手把 FileManager 拉出来」**。不拉的时候，阅读器关掉后露出的就是
  本来就压在下面的那个窗口 = 知识库列表本身。
- 顺带一个时序细节：`UIManager:close` 是**同步**跑 `handleEvent("CloseWidget")`
  的（`uimanager.lua:242`），所以 `pcall(readerui.onClose, readerui)` 一返回，
  `ReaderUI.instance` 已经是 nil、`reclaim_pending` 也已经置好 —— 可以**立刻**
  抬一次列表，不用等第一拍定时。
- `readerui.onHome` 也一并改道（`Session.installExitRouting`），因为 KOReader 里
  还有别的「回家」入口（`ReaderBack` 在文档开头再返回一次会发
  `Event:new("Home")`，`readerback.lua:173`）。改道时**必须用捕获下来的原生
  `onHome` 兜底**，不能写 `self.onHome` —— 否则 `onClose` 一旦失败就是无限递归。
  只在 `state.active` 时改道，普通书籍不变。

**10. 退出后「抬回列表」要认三种覆盖层，其中两种必须越过 —— 而障碍是觅阅也会建 FileManager。**

v0.6.9 只做了「退出不拉 FileManager」，结果实测反而更糟：**打开文档下滑就直接
停在 `cache/ima` 的文件列表里**。因为在 `FileManager.instance` 不存在时，觅阅的
`_ensure_filemanager_base` 会走**创建分支**，替我们把这个文件管理器建出来并
`UIManager:show` 到列表上面（`HOME_RETURN_FILE` 指向刚读的那本书，目录自然就是
`cache/ima`）：

```lua
-- miuread main.lua:17593-17615
local target = tostring(file or HOME_RETURN_FILE or "")
local dir    = target:match("^(.*)/[^/]+$")
FileManager:showFiles(dir, target)     -- → UIManager:show(file_manager)，插到列表上面
```

（v0.6.8 之所以看起来正常，是那版退出走 `onHome`、KOReader 抢先建过 FileManager，
觅阅随后走的是 `conceal_under_home` 分支，只把**它自己的首页** raise 上来。）

所以 `Session.reclaim` 现在按「顶层是谁」分三种处理，`is_foreign_overlay`
只留最窄的那一种：

| 顶层是什么 | 处理 | 理由 |
| --- | --- | --- |
| KOReader 文件管理器（`FileManager.instance`） | **收掉它**（`UIManager:close`） | 它不属于 IMA 的任何界面；KOReader 自己退出文件管理器也走这条路 |
| 觅阅恢复流程的过渡层（`_miuread_transient` / `_miuread_modal_surface`） | **越过它**，照常抬列表 | **v0.6.9 就是被这两个标记挡住的** —— 它们出现的时机恰好就是要把列表抬回顶层的时机，认它们等于永远抬不动 |
| 真正的模态对话框（`modal`） | 让位 | 用户可能正在输入，抢了会把对话框压到底 |

另外两条同批补的：

- **列表被整个移出窗口栈**（觅阅桌面模式接管时会清场）时，「抬」无从谈起 ——
  改为 `UIManager:show(menu)` **重新显示一次**，否则用户会被永久留在文件管理器上。
  （但**用户自己关掉的**列表不能这样救回来 —— 见第 11 条。）
- **校正窗口加密到 10 拍**（0.8 / 1.6 / 2.4 / 2.9 / 3.4 / 4.0 / 4.8 / 5.8 / 7.0 / 8.5s）。
  v0.6.10 是 4 拍（1.8 / 3.2 / 5.0 / 7.5s），实测**太稀疏**：觅阅要 +2.55s 才确认
  「阅读器真的关闭了」、+3.0s 才 `FileManager base created`，而 5.0s 那一拍才去收它 ——
  文件管理器在屏幕上整整停了近 3 秒（`20:30:04 创建 → 20:30:07 收掉`）。
  加密后最坏暴露时间降到 0.5 秒以内。
  而且 `scheduleReclaim` 现在带**令牌**：`onCloseWidget` 与 `closeReader` 都会排
  定时器，两组交错会把 `state.step` 往前推、让窗口提前收口。
- **reclaim 的每个早退点都写日志**（含窗口栈快照）。这个方法以前全程静默，
  出问题时只能靠推测 —— 上面这条路整整查了两轮才定位。

---

**11. 「界面被关掉」有两种，必须分开 —— 一种要救，一种绝不能救。**

v0.6.10 实测反馈：「退出阅读器后会返回知识库界面 → 自动跳到 `cache/ima` 缓存页 →
自动跳回知识库列表；此时再次下滑，又是返回知识库界面后自动跳回知识库列表。」

日志（`crash.log` 行 11197-11243）把这条链拆得很清楚：退出后 1.8s 那一拍，
`UIManager:isWidgetShown(menu)` 已经是 **false** —— 列表被整个关掉了，而它
**不在** `close_callback` 的记录里。于是「列表不见了」有两种截然不同的成因：

| 成因 | 走不走 `Menu.close_callback` | 该怎么办 |
| --- | --- | --- |
| 用户在列表上**下滑**（`Menu:onSwipe → onClose → onCloseAllMenus`） | **走** | 用户已经离开这一层 —— 停止一切抬回 |
| 觅阅的恢复流程把窗口栈清场 | **不走** | 那才是 reclaim 该救的场合 |

KOReader 的 `Menu:onCloseAllMenus`（`ui/widget/menu.lua:1471`）是**先**
`UIManager:close(self)`、**后** `self.close_callback()` —— 顺序正好可以用来区分。
所以 `Imenu.show` 现在**总是**装上 `close_callback`（调用方自己的 `on_close` 照常链在后面），
一被调用就通知会话 `noteMenuClosed()`：置 `user_closed`、关掉守护窗口、推进令牌
作废在途定时器。`reclaim` 的第一行就是查这个标记。

没有这一步的后果就是用户看到的那样：**守护定时器把用户刚关掉的界面又 show 了回来**。

同一批还装了**关闭探针**：KOReader 的 `UIManager:close` 只用 `logger.dbg` 记一行
（`uimanager.lua:237`），而设备日志是 INFO 级 —— 于是「列表到底是被谁关掉的」
在 v0.6.10 的完整日志里**一个字的证据都没有**，只能靠推断。现在该方法的包装会在
「被关掉的正是本列表」时用 warn 级补一条带调用栈的日志：

```
[ima] 诊断：知识库列表被关闭，调用栈 = ...
```

栈里若是 `Menu:onCloseAllMenus` 就是用户关的；若是觅阅的某个函数，就是该救的那种。

---

## 接口实测结论（2026-10-07 用真实凭证验证）

| 项 | 结论 |
| --- | --- |
| `search_knowledge_base` | ✅ 可用。**空 `query` 即返回全部知识库** —— 这是「列库」的正确姿势 |
| `get_knowledge_base_list` | ❌ **不存在**，HTTP 404。首版误用了这个接口名，v0.3.0 已移除 |
| `get_knowledge_list` | ✅ 可用，返回 `data.knowledge_list[]` + `is_end` / `next_cursor` |
| `search_knowledge` | ✅ 可用，返回 `data.info_list[]` |
| `get_knowledge_base` | ✅ 可用，返回 `data.infos[<id>]` |
| `get_media_info` | ✅ 可用，返回**临时签名 URL**（见下） |
| `get_doc_content` | ✅ 笔记线接口，`data.content` 为纯文本 |
| 凭证无效 | HTTP **401** + `{"code":200002,"msg":"skill auth failed"}` |
| 请求头大小写 | 无问题，小写 `ima-openapi-clientid` 直接可用 |
| `limit` 越界 | HTTP **200** + `{"code":51,"msg":"invalid XxxReq.Limit: value must be inside range (0, N]"}` —— 注意 HTTP 状态是 200，只看状态码会把这类错误当成成功 |
| `search_knowledge_base` 的 limit | **(0, 20]**：`20` 通过，`21` 报 51，`0` 也报 51 |
| `get_knowledge_list` 的 limit | **(0, 50]**：`50` 通过，`51` / `100` 报 51 |

关键响应字段：

```
search_knowledge_base → data.info_list[] =
  { kb_id, kb_name, base_type, role_type, content_count, creator, description }

get_knowledge_list → data =
  { knowledge_list[] = { media_id, title, parent_folder_id, media_type, tags },
    is_end, next_cursor, current_path[] }

search_knowledge → data.info_list[] =
  { media_id, title, parent_folder_id, highlight_content, media_type }

get_media_info → data =
  { media_type,
    url_info = { url = "https://pkb.ima.myqcloud.com/...?media_id=..&sign=..&t=..",
                 headers = { ["X-IMA-Sign"], ["X-IMA-Platform"], ... } },
    notebook_ext_info = { notebook_id } }     -- 仅笔记（media_type=11）时非空
```

### 关于 `get_media_info` 的三个实测细节

1. **URL 是临时签名**，query 里带 `sign` / `t`，另有 `X-IMA-Create-URL-Time`。
   不要缓存 URL 本身。
2. **那组 `headers` 不带也能下载。** 实测直接对 URL 发 GET 得到
   `HTTP 200` + `content-type: application/pdf` + 完整 343154 字节
   （头部 `%PDF-1.4`、尾部 `%%EOF`）。签名已经写在 URL 里，headers 只是冗余。
3. **CDN 证书链能通过设备自带根证书。** CDN 域名 `pkb.ima.myqcloud.com` 的证书
   由 `DNSPod DV TLS RSA CA 2025` 签发，看起来较新，所以我用设备上的
   `data/ca-bundle.crt`（118 个根证书）实测验证过 —— 两个域名都是
   `ssl_verify_result=0`，TLS 不存在信任问题。

`models.lua` 现在**优先走这些精确路径**，只在其缺失时退回特征匹配兜底，
所以正常情况是 O(n) 直取，接口若变更也只是退化为旧行为而不是崩掉。

## 关于「扫码登录」

**现在的凭证（Client ID / API Key）无法通过扫码获得，两者没有转换关系。**

微信扫码走的是标准 OAuth，换回来的是登录 Cookie（`IMA-GUID` / `IMA-UID` /
`IMA-TOKEN` / `IMA-REFRESH-TOKEN`）；而 openapi 只认 `agent-interface` 页面生成的
**静态凭证**。想用扫码就得改走 ima 的**私有 cgi-bin 接口**（Cookie 鉴权），
那等于放弃官方接口的稳定性去换一个登录方式，不划算。

而且 **Kobo 没有摄像头**，只能是「Kobo 显示二维码 → 手机扫 → 服务端轮询回传」，
省下的只是「在设备上敲两串字符」这一件事 —— 而这件事用
「在电脑上写好 `settings/ima.lua` 再推过去」就能解决，见上文。

---

## 变更记录

**v0.6.20（当前）**

实测反馈三条：①「**打开文档自动横屏**」和②「**退出自动转回来**」这次**好了**；
③「**字的页末裁切还是存在**」；④新问题：「**从文档退出会总是退到文档列表的最后一页
而不是初始首页**」。

两条都从设备日志里拿到了直接证据，都不是"没部署"。

### ③ 页末裁切：v0.6.19 的**滚动位置取错了字段**

v0.6.19 的算法（让下一屏底部落在某个行顶上）是对的，行网格也确实取到了 ——
设备日志里那条 `[ima] 行网格：第 1 页 204 行` 就是证据。**错在读屏幕位置**：

- 🔴 **`paging.visible_area` 在翻页过程中是一块"死"矩形。**
  它是 `ReaderView:recalculate()`（readerview.lua:761）产出的、**贴着页面原点的
  屏幕大小的矩形**，只在「尺寸 / 缩放变化」时被重写
  （`ReaderPaging:onViewRecalculate` 只在收到 `ViewRecalculate` 事件时才赋值）。
  连续视图下它的 `y` 恒等于 `page_area.y`（= 0）。
- 🔴 **于是 `y0` 永远是 0** ⇒ 查询区间 `(H, 2H]` 恒定 ⇒ 每次算出来的重叠量**都是
  同一个数** ⇒ **又退化成了固定重叠量**，等于什么都没修。日志也印证：整个会话里
  「行网格：第 1 页 N 行」只出现一次，翻多少屏都没有新输出。
- 🟢 **真正的滚动位置在 `view.page_states[#].visible_area.y`** —— 这正是
  `ReaderPaging:onScrollPageRel`（readerpaging.lua:921-937）**自己**取的那个
  `last_page_state.visible_area`：它按 `offset.y = last_visible_area.h - overlap`
  把"当前屏最下面那一页块"整体下移一步。**必须和原生取同一个字段**，否则算出来的
  步长对不上。包装是在原生之前跑的，所以 `page_states[#]` 就是它将要用的那个。
- 🟢 **缩放也换成 `view.state.zoom`**（与 `page_area` 同源的 `getPageArea(page, zoom,
  rotation)`），不再调 `zooming:getZoom()` —— 那条路会顺带跑 `view:onBBoxUpdate`。
  单位换算的原文依据是 readerview.lua:414：
  `page_y = (state.visible_area.y + screen_y - state.offset.y) / state.zoom`。

### ④ 退出后落到列表最后一页：`Menu:onPrevPage` 是**环绕**的

- 🔴 **根因**：KOReader 的 `Menu:onNextPage/onPrevPage`（widget/menu.lua:1405-1413）
  写的是
  ```lua
  onPrevPage:  self.page > 1 and self.page - 1 or self.page_num
  ```
  —— 在**第 1 页**往前翻会**直接跳到最后一页**（`-- cycle for swipes only`）。
- 🔴 **触发它的那一划来自"退出余波"**，设备手势探针两条完全一致（都在退出后约 1 秒、
  方向都是 `east`、起点都贴着屏幕左缘、顶层都是文档列表）：
  ```
  10:05:31  dir=east dist=450.02 pos=35,855  顶层=0x6eb64ae8
  10:06:42  dir=east dist=332.27 pos=43,962  顶层=0x6eb64ae8   ← 文档列表
  ```
  `Session.swallowHandoverSwipe` **只吞 `south`**（`if flipped ~= "south" then
  return false end`），所以这一划原样落到 `Menu:onSwipe` → `onPrevPage()` →
  第 1 页 → `page_num`，列表于是"永远停在最后一页"。
- 🟢 **修法：给列表的分页去掉环绕。** `Imenu.show` 里给每个列表实例包一层
  `onPrevPage` / `onNextPage`：到边界就什么也不做（既不跳页也不报错）。
  只包**实例**、不动类方法 —— KOReader 自己的菜单照旧环绕。
  翻页改用底部的左右箭头按钮（`page_info` 那一行），照常可用。

### 顺带：第一次翻页会把"开文档那一屏"切掉的那半行救回来

打开文档后的**第一屏**屏顶只能是 `y0 = 0`，屏底必然落在任意位置 —— 要对齐就得把
页面顶部裁掉一截（丢掉文档开头），不能接受。所以那一屏底部那一行仍可能被切。

但现在**第一次往下翻页**会把它救回来：只要当前屏底**骑在某一行的身上**
（`bots[cut] > edge`），就把对齐上限从 `edge + E` 收到 `tops[cut] + E`
（"下一屏顶 ≤ 该行顶"）。上限只往回挪一行（≪ 一屏），步长仍接近满屏，
但那一行会在下一屏**完整**出现。从第二屏起，相邻两屏必然重叠
（`y0_{k+1} ≤ f_k·zoom − H ≤ y0_k + H`）⇒ **不可能再有任何一行被切**。

### 离线量化验证（`outputs/_tools/align_sim.py`）

新增脚本，把 v0.6.20 的算法**逐字复刻**成 Python，拿设备上 `cache/ima` 里**真实的
16 份 PDF**（PyMuPDF 逐行取行框）跑连续视图翻页，逐个屏幕统计：

| 策略 | 屏底切字（横屏 2.809） | 略过第一屏后 | 从未完整显示的行 |
|---|---|---|---|
| 原生 / 归零 | 54.5%（77 / 154） | 77 | 77 |
| 固定一行高（v0.6.17） | 55.3%（88 / 159） | 81 | 0 |
| **按行网格对齐（v0.6.20）** | **4.1%（7 / 172）** | **0** | **0** |

竖屏（zoom 2.113）同一份文档集：原生 52.1% → 固定 54.6% → **网格对齐 6.7%，
略过第一屏后 0**，从未完整显示的行 **0**。

⇒ **从第二屏起，屏底切字率是 0，而且没有任何一行会被永久切掉。**
剩下那 7 / 9 屏全部是**打开文档后的第一屏** —— 见上一节，那是滚动阅读固有的。

- 📝 同时确认了三条前提（都用真实文件量过，不是推断）：
  · 16 份文档**全部是单页**（598.1pt 宽 × 1947~6893pt 高）⇒ 一屏永远只有
    `page_states[1]` 一块 ⇒ `#page_states == 1` 这条守卫对全库成立；
  · 全部 `CropBox` 原点 = (0,0) 且 `CropBox == MediaBox` ⇒ 无 used-bbox 偏移
    ⇒ `行顶 × zoom` 这个映射精确成立；
  · 横屏 `zoom = 1680 ÷ 598.08 = 2.809`、竖屏 `1264 ÷ 598.08 = 2.113`，
    与日志里那个"兜底 46px"完全对得上。

- 📝 新增诊断日志（每次开文档最多 12 条）：
  `[ima] 翻页对齐：页顶 Npx 屏高 Npx zoom=X 屏底 Ypt → 对齐到 Zpt（重叠 Wpx）`
  —— 一眼能看出 `y0` 到底动没动、`zoom` 是竖屏(2.113)还是横屏(2.809)。
- 🔧 版本号 0.6.19 → **0.6.20**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。
- 🧪 测试：session **172 → 183**（行网格新增行底数组、对齐新增强不变量「下一屏底
  必须落在行顶上」、连翻 20 屏全绿、「救回被切行」两条精确数值用例、
  「跨两页不动」「字段缺失不炸」）；swipe **166 → 175**（新增 4g 节：分页不环绕，
  含"原生确实会环绕"的反证）。

**v0.6.19**

实测反馈两条：「**不会打开文档不会自动旋转**」、「**页末字裁切的问题也没改**」。
两条都查到了确切原因，且**都不是"没部署"**（设备上 `_meta.lua` = 0.6.18、
关键文件 sha256 与工作副本一致、`crash.log` 里能看到插件日志）。

### ① 自动横屏不生效 —— 开关默认关

v0.6.18 把开关做成**默认关**（理由是"别悄悄改变阅读姿态"）。但用户要的就是
"打开 IMA 文档即横屏"，默认关 ⇒ 他不会去翻设置项 ⇒ 打开文档当然不转。
`settings/ima.lua` 里也确实没有 `pdf_auto_landscape` 这个键（时间戳停在 10-07，
说明这次测试期间一个设置都没写过）。

- 🟢 **默认值改为「开」。** 横屏在本库是刚需（竖屏 `contentwidth` 只等效 9.13pt
  正文，横屏 12.14pt），而且它是**文档级**设置、退出即恢复，不会影响别的书;
  不想要的人关掉开关即可（关掉时照旧把 `kopt_rotation_mode` 归还给 KOReader）。

### ② 页末字被切：方向对，但「固定重叠量」这条路走不通

v0.6.17 把重叠改成「恰好一行高」（`21.75pt × zoom` = 竖屏 46px），思路没错，
**但注定无效** —— 因为它假设"整份文档只有一个行距"：

- 🔴 **本库 PDF 的行距根本不统一。** 用 PyMuPDF 把设备上 16 份样本逐行量了一遍
  （`outputs/_tools/linegrid_probe.py`），相邻行顶差有**五种**：
  `21.75pt`（段内正文，最多）、`35.25` / `34.5`（正文↔标题）、`53.46`（标题前）、
  `21.0`。固定重叠只可能对齐其中一种。
- 🔴 **量化验证。** 又按真实行框做了离屏模拟（`outputs/_tools/overlap_sim.py`，
  16 份文档共 72~80 屏）：固定重叠取 `0 ~ 71pt` 里的**任何**值，
  "新屏顶部切字率"都稳定在 **59% ~ 73%**（`overlap = 0` 时 64%）。
  ⇒ 无论 47px 还是 KOReader 自己的 64px，用户看到的都是"有时切、有时不切"。

- 🟢 **正解：不要猜行距，直接问文档每一行在哪。**

  `PdfDocument:getPageTextBoxes(page)`（pdfdocument.lua:101）走的是 MuPDF 的
  **stext 设备**（ffi/mupdf.lua:503 的 `page_mt:getPageText`），**不经过
  k2pdfopt 重排引擎** —— 所以既不会踩到本设备上「重排 = 卡死」那颗雷
  （见 v0.6.5），结果还会被 `DocCache` 按 `file+page` 缓存一份。返回的每一行
  都带 `x0/y0/x1/y1`，单位是**页面坐标**（zoom = 1.0）。

  **对齐规则**（每次**向下**翻页前重算一次重叠量，见 `Session._alignOverlap`）：
  设当前屏顶 `y0`、屏高 `H`（屏幕像素），让下一屏底部落在**某个行顶 `f`** 上 ——
  `f` 取 `(y0+H, y0+2H]` 换算成页面坐标后区间内**最大**的行顶：

  ```
  overlap = y0 + 2H − f × zoom      ∈ [0, H)
  步长    = H − overlap
  ```

  ⇒ 屏底落在行顶 ⇒ **该屏最后一行永远是完整的**（这正是用户要的）；
  `f` 取区间内最大 ⇒ 重复量压到最小；新屏顶部会落在上一屏某行的中间，
  **但那一行在上一屏是完整显示过的**（上一屏底部正好是行顶），
  所以内容从头到尾都不会被切掉。

- 📝 **实现要点**
  - 包的是**实例**上的 `ReaderPaging.onScrollPageRel` —— 连续视图的翻页正是走它
    （readerpaging.lua:574-575：`view.page_scroll` 为真时 `onGotoViewRel` 直接
    转过去，点击/按键/滑动都从这里过）；不动类方法、不碰别的书。
  - 行网格按**页面 pt** 缓存（`state.line_grids`，按页号），查表前把区间 ÷ zoom、
    出结果后 × zoom。这样**旋屏不用重取** —— 旋屏只改 zoom。
  - 兜底：拿不到行网格（扫描件、无文本层、接口变了）或区间内没有行顶（整段空白 /
    一整张图）时，退回「恰好一行」的固定像素值，**绝不退回 0**。
  - 打开文档时**同步**把首页行网格算好（`_attach` 里，几十毫秒）。刻意不用
    `UIManager:scheduleIn` 预取：那会往全局定时器队列里塞一个与阅读无关的任务，
    而退出余波那条链（吞划窗口 / 钉顶层）是按队列顺序驱动的，会被它顶偏一拍。

- ⚠️ **代价：第一屏的底部仍可能切字。** 这是滚动阅读固有的 —— 要让第一屏
  （`y0 = 0`）底部也对齐，就得把页面顶部裁掉一截，那会丢掉文档开头。
  **从第二屏起就整齐了。**

- 📝 **同时纠正 v0.6.18 的一处注释**：`ReaderPaging.overlap` 的单位是
  **屏幕像素**，不是页面 pt —— `ReaderView.recalculate`（readerview.lua:761）
  用屏幕 `dimen` 给 `visible_area` 设尺寸，而 `overlap` 与它直接相减
  （readerpaging.lua:932-946）。所以"一行高"换算成像素是
  `21.75 × 2.113 = 46px`，v0.6.17 那个 46/47 的算法本身是对的 —— **无效的原因
  是"固定量"，不是单位。**

- 🔧 版本号 0.6.18 → **0.6.19**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / `ima/views/settings.lua` 的「关于」页）。

**v0.6.18**

用户要求：「把打开 ima 文档自动横屏 / 退出文档阅读自动竖屏恢复做进插件吧」。
（2026-10-08 曾讨论过一轮，当时结论是"保持手动、暂不做"；现在按用户要求实现。）

为什么值得做：本库文档是 **598pt 宽的固定版面 PDF** —— 竖屏 `contentwidth` 下缩放只有
`视口宽px ÷ 页宽pt = 1264 ÷ 598 = 2.113` → 18pt 正文等效 **9.13pt**；横屏则是
`1680 ÷ 598 = 2.809` → **12.14pt**，正好 **1.33×**，而且**完全不需要重排**。
这台设备上「重排 = 崩溃」（见 v0.6.5），所以横屏是放大正文**唯一安全**的手段。

- 🟢 **实现走 KOReader 自己的「文档级旋转」，不去拧屏幕的全局状态。**

  KOReader 的旋转本来就是文档级的：打开时 `ReaderView:onReadSettings`
  （readerview.lua:968-975）按 **`kopt_rotation_mode`(边车) > 全局同名键 > 竖屏**
  取值并应用；退出时 `ReaderView:onSaveSettings`（1219-1222）又把当前旋转写回边车。
  ⇒ 插件只要在**打开之前**把边车写成横屏（`prepare` → `seedDocumentDefaults`，
  这条链在 `showReader` 之前跑），KOReader 自己就横屏打开了。
  **只影响 IMA 打开的这一份文档**，别的书一点不受影响。

- 🟢 **退出恢复必须自己做。**

  KOReader 原生的恢复点是 `FileManager:showFiles`(filemanager.lua:1311) 里的
  `self:setRotationMode()` —— 但它**只在新建 FileManager 实例时才跑**，而 IMA 的退出
  路径刻意**不新建** FileManager（只调 `ReaderUI:onClose`，见 v0.6.13 的退出改道）。
  那条路永远不会执行。所以 `Session.installRotationRestore` 给 `onClose` 包一层，
  在**原函数返回之后**把屏幕恢复到「进入本次阅读之前」的旋转（不只是"竖屏" ——
  用户本来就横屏用文件浏览器时也能原样还原）。

  ⚠️ **时序是命门**：`ReaderUI:onClose` 内部才做 `saveSettings()`
  （readerui.lua:871；`dialog == self` 时由 `UIManager:close` 触发的
  `onFlushSettings` 代劳）→ `ReaderView:onSaveSettings` 把**当前屏幕旋转**写回边车。
  此刻屏幕还是横屏 ⇒ 边车记的也是横屏 ✓。要是提前恢复成竖屏，边车就被改写成竖屏，
  **下次打开不会自动横屏了**。测试里有一条断言专门盯这个顺序。

- 🟢 **打开后还有一道兜底校正**（`Session.enforceSeededRotation`）：
  开关开着但打开后**不是**横屏 → 发一次 KOReader 自己的 `SetRotationMode` 事件
  （`ReaderView:onSetRotationMode` 会一并重算布局 + 全屏重绘）。
  这条路是为**「跨视图保持当前旋转」(`lock_rotation`)** 准备的 —— 那个开关会让
  readerview 整个跳过边车取值（968 行），正是用户说的"读别的书时锁了竖屏"的场景。
  取不到当前旋转时**什么都不做**（不猜）。

- 📝 **三个"锁"要分清**（`screen_rotation_menu_table.lua`），这决定本功能会不会被挡：

  | 设置项 | 内部键 | 会不会挡住本功能 |
  | --- | --- | --- |
  | 忽略加速度计旋转事件 | `input_ignore_gsensor` | **不会**（只挡传感器） |
  | 把自动旋转锁定到当前方向 | `input_lock_gsensor` | **不会**（只挡传感器） |
  | 跨视图保持当前旋转 | `lock_rotation` | **会**（readerview 跳过边车读写）→ 靠上面那道兜底校正 |

- 📝 开关**默认关**（⚠️ **v0.6.19 已改为默认开** —— 默认关导致用户没去翻设置项，
  于是"打开文档不转"，被判定成功能没做。见 v0.6.19 章节）：它改变的是阅读姿态本身，
  属于"用户明确想要才开"的功能，不该让每个升级上来的人第二天发现文档自己横过来了。
  关掉时把边车里的 `kopt_rotation_mode` **归还**（删键），之后完全交给 KOReader ——
  用户自己转出来的横屏能被正常记住，插件不再多嘴。
- 📝 设置界面与「关于」页的说明同步更新（原来那句"想放大正文请横屏阅读"，
  现在补上"或开启「打开文档自动横屏」"）。
- 🔧 版本号 0.6.17 → **0.6.18**（`_meta.lua` / `ima/constants.lua` / `ima/views/settings.lua`）。

**v0.6.17**

> ⚠️ **已被 v0.6.19 取代，不要照这里的结论去做。** 本版把重叠改成「恰好一行高」，
> 思路对、**但"固定量"这条路注定无效** —— 本库 PDF 的行距不统一（五种），
> 固定值只可能对齐其中一种。上机实测用户反馈仍是「没改」（切字率 59%~73%，
> v0.6.19 章节有量化数据）。**真正的解见 v0.6.19：按行网格对齐。**
> 下面保留当时的排查过程，其中"恰好一行是唯一解"这句**是错的**。

实测反馈：「文档阅读界面，**有时**页面最下方的字不完整，字的一部分会显示在下一页」。

- 🔴 **根因：把重叠压成 0 是 v0.6.2 的矫枉过正。**

  翻页切字是**必然**的 —— 只要页间重叠小于一行高，跨越屏底边的那**一行**就会被切成
  两半：上半截留在上一屏、下半截掉到下一屏。v0.6.2 为了治「翻页与上一页重复」把重叠
  **归零**，于是翻页步长正好等于屏高，这种切断就从"偶发"变成了"每屏都在切"。

  为什么反馈里是「**有时**」：切口位置由「屏高 ÷ 行距」的余数决定，余数不为 0 时会
  逐屏漂移 —— 有些屏正好切在行间隙（看不出来），有些屏正好切在字中间（很明显）。

- 🟢 **修法：重叠 = 恰好一行高。**

  只有这一个值成立：要让被切的那一行在下一屏**完整**重现，重叠必须 **≥ 一行高**；
  而一旦超过一行，重复量就白白变大。所以「恰好一行」同时是「不切字」与「最少重复」的
  唯一解 —— 这不是折中，是解。

  一行高是**算出来**的：正文行距实测 **21.75pt**（样本 `nand` / `sanre` 两份互不相关的
  文档给出同一个数，说明这个库的行距统一），乘以当前缩放得到像素值：

  | 方向 | 缩放（视口宽px ÷ 页宽pt） | 一行高 | 连续视图重叠 |
  | --- | --- | --- | --- |
  | 竖屏 contentwidth | 1264 ÷ 598 = **2.113** | **47px** | `paging.overlap = 47` |
  | 横屏 | 1680 ÷ 598 = **2.809** | **62px** | `paging.overlap = 62` |

  连续视图（`ReaderPaging.overlap`）本来就是**像素**，直接给这个值；整页视图
  （`zoom_overlap_v`）是**百分比**，换算成「一行像素 ÷ 视口高 × 100」（竖屏约 3%）。
  两处都随**旋屏重算** —— 靠的仍是 v0.6.4 那道 `ReaderPaging:onViewRecalculate` 钉子。

- 📝 开关改名：「翻页内容连续（不重叠）」→ **「翻页不切断文字（重叠一行）」**
  （键名仍是 `pdf_continuous_paging`，老用户设置不会失效）。关掉仍退回 KOReader 原生重叠。
- 📝 开启档下文档级 `kopt_zoom_overlap_h/v` 仍写 0：它只对整页视图有意义，运行时那道
  钉子会把它覆盖成上表算出来的百分比。
- 🔧 版本号 0.6.16 → **0.6.17**（`_meta.lua` / `ima/constants.lua` / `ima/views/settings.lua`）。

**v0.6.16**

实测反馈：「这一版本已经好非常多了，可以正常返回文档列表，从文档列表返回知识库用户
界面时会闪现一下 KOReader 的 ima 缓存列表，**不是每一次都如此**，而且从文档列表返回
用户界面的**触摸不能过快，过快会失效**」。

先说好的那半：v0.6.15 的「钉 modal」**确实治好了主路径** —— 「打开文档 → 顶部下滑 →
返回文档列表」不再跳登录界面、不再被缓存列表盖住。下面两个是**新暴露出来的**问题，
而且都不是 v0.6.15 那套机制本身失效，是它的**作用范围**不够。

- 🔴 **现象 A：从「文档列表」再退一层到「知识库用户界面」时，闪一下 cache/ima（偶发）。**
  真因：v0.6.15 只把**最上面那一层**列表钉成了 modal。链路上的窗口其实是三层：
  `知识库用户界面（列表）→ 文档列表（列表）→ 觅阅补回的 FileManager 底座`。
  底座被插到最上层列表**之下**是对的，但**更下面那层列表仍在底座下面** ——
  所以关掉「文档列表」的那一刻，先露出来的是夹在中间的 cache/ima 底座。
  「偶尔才闪」是因为只有在那一刻觅阅的底座**恰好补回来了**才会露出来；补底座的时机
  是异步的，见下。
- 🟢 **修法 ①：要钉就钉全部。** `Session.pinMenu` 从"只钉 `state.menu`"改成遍历
  `Imenu.menus()` 把**每一层还活着的列表**都设成 `modal`；`is_foreign_overlay`
  与关闭闸口也都改用同一份登记表来排除我们自己的列表（否则被钉成 modal 的列表会
  自判成"该让位的模态对话框"，reclaim 直接自锁死）。
- 🟢 **修法 ②：关列表时同步收掉夹在中间的。** `UIManager:close` 闸口在关掉我们**任一**
  列表时，先 `sweep_file_managers()` 把整个窗口栈里的 FileManager 收干净，再放行原本的
  close。**为什么这样一定不闪，有两条源码依据**：
  `UIManager:close`（`uimanager.lua:232-280`）只改窗口栈 + `setDirty`，真正绘制被延后到
  `_repaint()`（`1237`）；而 `handleInput`（`1495-1522`）的循环是
  **「先 `_checkTasks()` + `_repaint()`，再 `Input:waitEvent`」**。两者一叠加
  ⇒ **在同一个同步调用里把某个窗口收掉，它一帧都不会被画出来**。所以"先收底座、再关
  列表"这一个同步块里，底座从来没有机会上屏。
- 🔴 **现象 B：从文档列表返回时"触摸不能过快，过快会失效"。这是上一版的锅，真因是
  我们对"退出余波"的判断错了。**
  v0.6.14 / v0.6.15 的核心假设是「退出阅读器后约 1s 飘来的第二个 south swipe = 同一次
  物理滑动被重复派发」，于是开了 4.0s 的免打扰窗去吞它。**这个假设是错的** ——
  那**是用户自己的下一划**。从设备 `crash.log` 取到 22:54~22:56 三轮完整数据：

  | 时刻 | 事件 | `dist` | `pos` |
  | --- | --- | --- | --- |
  | 22:54:27 | 退出动作（顶部下滑：返回知识库列表） | 72.56 | (446, **103**) |
  | 22:54:27 | 被"余波窗"吞掉的那一划 | **323.13** | (437, **31**) |
  | 22:55:43 | 退出动作 | 94.64 | (470, **124**) |
  | 22:55:43 | 被吞 | 260.12 | (459, **30**) |
  | 22:55:46 | 被吞（**这一划才是用户真正想返回的**） | 334.93 | (448, 68) |
  | 22:56:03 | 退出动作 | 82.76 | (506, **114**) |
  | 22:56:04 / 22:56:06 | 被吞 | 357.02 / 483.81 | (489, 33) / (493, 24) |

  **判据是 `Contact:handleSwipe` 的 `pos` 字段是"滑动的起点"而不是抬手点**
  （`gesturedetector.lua:891-941`，`927-933` 行有注释明说 `pos = start_pos`，因为
  hit-detection 用接触点更合理）。看退出动作与被吞那划：起点一个在屏幕**底部**
  （y≈103~124，顶部 zone 的下沿），一个在屏幕**顶部**（y≈24~37）。**起点差 70pt、
  距离差 4~6 倍**，物理形态完全不同 —— 一次真实的物理上滑不可能有这种数据。
  这与用户描述「触摸不能过快，过快会失效」完全吻合：窗口把用户**自己的返回手势**
  一起吞了，所以"慢慢来、等窗口过去"才有效。
- 🟢 **修法：吞划窗口压到 1.5s 且"一击即止"，并且不再拦关闭。**
  `HANDOVER_QUIET_SECONDS` 4.0 → **1.5**，且 `swallowHandoverSwipe` 吞掉一条后
  立刻 `state.handover = false` 并作废在途定时器（`HANDOVER_ONE_SHOT = true`）——
  只挡"紧跟在退出之后的那一下"，之后用户想怎么划都畅通。
  另外**删掉关闭闸口里"拦下对列表的关闭"那段**：那会连用户点标题栏 ✕ 一起拦掉。
  闸口现在只做"清缓存列表 + 记诊断栈"，不再否决任何关闭。
- 🟢 **两个窗口刻意做成不同长度**：吞划窗口 1.5s（一击即止）vs 钉顶层窗口 **4.0s**
  （`HANDOVER_PIN_SECONDS`）。合成一个会让两件事二选一 —— 要么"不吞用户手势"、
  要么"底座别盖上来"。钉子**必须活到觅阅补底座那一刻**：实测
  `[MiuRead][Home] FileManager base ready` + `[ReaderClosePerf] FileManager base
  created show_ms=132` 发生在退出后 **+2.3~2.6s**（日志 22:54:29 / 22:55:46 / 22:56:06
  三处 `rebuild candidate became real close wait_ms≈2494 / 2514 / 2454`）。
- 🔧 **顺手拆掉一个自伤**：`noteMenuClosed` 里那句 `Session.pinMenu(false)` 删了。
  这一版 `pinMenu` 改成"钉全部列表"之后，在"用户关掉了某一层列表"时调它，会把
  **下面那层列表**的钉子也一起拔掉。摘钉子只由 `prepare()` / `abort()` / 窗口到期
  三处负责。
- 🔧 **新增插件列表登记表**：`ima/ui/menu.lua` 里的 `Imenu.menus()`（返回所有创建过、
  且仍挂在窗口栈上的列表，顺手剔除已关掉的）与 `Imenu.isOurs(widget)`。
  `is_foreign_overlay`、关闭闸口、`pinMenu` 三处共用同一份判断，语义就一致了。
- 🔧 版本号 0.6.15 → **0.6.16**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.15**

换了思路重查。实测反馈：「依然如此，闪现一下知识库文档列表再跳到 ima 知识库用户
界面再闪现到 koreader 的 ima 缓存最后回到 ima 知识库用户界面」——注意这次**文档
列表已经能闪出来了**，说明 v0.6.14 有一半在起作用，但随后又被盖掉。

- 🔴 **「为什么总是闪一下 cache/ima 缓存列表」——找到真因，而且它不是我们造成的。**
  阅读器一关，觅阅必然跑一遍「恢复原生界面」（日志时序
  `[MiuRead][Navigation] reader -> native` → `[MiuRead][Startup] begin`（把 home
  插件整个重初始化）→ `native -> home` → `[MiuRead][Home] FileManager base ready`
  → `[MiuRead][Transition] complete native surface restored`）。其中
  `Plugin:_ensure_filemanager_base`（miuread `main.lua:17573-17614`）会**无条件
  `UIManager:show` KOReader 的文件管理器**，并把目录切到本次文档所在的 `cache/ima`。
  觅阅自己的注释写得很明白（`main.lua:16673-16675`）：
  *"Never suppress KOReader's native transition. It owns document teardown and
  FileManager creation; MiuRead only observes the stable docless surface and
  raises the parked home afterwards."*
  → 这一下**我们拦不住**，事后去关它永远慢一拍。**这就是"总是闪一下缓存列表"的
  来源**，也是为什么前四版"事后收掉它"的做法注定治不好。
- 🟢 **主修复：把知识库列表钉在窗口栈最上层（`Menu.modal = true`）。**
  `UIManager:show`（`uimanager.lua:186-199`）的插栈规则是「插在**最上面那个非
  modal 窗口之上**」。所以只要列表是 modal，觅阅随后 show / raise 的任何非 modal
  窗口（文件管理器底座、它随后 raise 的首页）都只能插到列表**下面** ——
  不是"抢得快"，而是**根本盖不上来**。纯 z-order 保证，与时间、与谁先谁后无关。
  只在「退出余波免打扰」期内钉；`Session.prepare()`（打开阅读器之前）必须摘，
  否则阅读器会被列表盖住。`modal` 在前端只被 `UIManager:show` 的插栈逻辑读，
  给 `Menu` 加这一字段没有别的副作用。
- 🟢 **「退出余波免打扰」不再依赖时钟。** v0.6.14 用「起始时刻 + `age < 1.6s`」，
  真机上四次实测**全部落空** —— 每次都走到 `noteMenuClosed` 的「用户关闭了知识库
  列表」那一支，而"免打扰窗内：忽略"那条日志从未出现。v0.6.15 改成
  `state.handover` 布尔 + `UIManager:scheduleIn` 定时清除（KOReader 自己的调度器），
  不存在"算出来不在窗口内"这种事。
- 🟢 **三道拦截，其中一道必然生效。** ① 列表实例 `onSwipe` 吞 south（v0.6.14 已有，
  实测被绕过）；② `noteMenuClosed` 不记成用户意图；③ **`UIManager:close` 闸口
  （新增）—— 免打扰期内对列表的关闭直接不放行**。这是唯一覆盖所有关闭路径的点：
  不管那一划从 `onSwipe`、`Menu:onClose` 还是谁直接调 `UIManager:close` 进来，
  都必须经过它。
- 🔧 **顺带纠正一个会误导排错的认知**：`Menu:onSwipe` 与 `EventListener:handleEvent`
  里的调用都是**尾调用**（`return native_swipe(...)`），`debug.traceback` 里
  **看不到**我们包装层那一帧 —— 不能据"调用栈里没有我们的文件"就断定包装没生效。
- 🔧 **文件管理器卫生改成扫全栈**：列表被钉成 modal 后，觅阅的文件管理器底座是插在
  列表**下面**的，`topmost_widget()` 永远看不到它。免打扰期内整个栈扫一遍收干净；
  期后退回旧行为（只收栈顶那个）。`is_foreign_overlay` 排除我们自己的列表，
  否则钉成 modal 的列表会被判成"不该抢的模态对话框"而自锁死。
- 🔧 版本号 0.6.14 → **0.6.15**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.14**

修的是 v0.6.13 依然没解决的那一跳。实测反馈：「文档下滑会先弹到 ima 知识库的用户
界面，再自动闪现到 KOReader 的 ima 缓存，然后自动弹到 ima 知识库用户界面静止不动，
期间未出现 ima 知识库文档列表」。

- 🟢 **12 层调用栈拿到了全貌，先纠正两轮前的错误结论。** 列表被关掉时的栈是
  `handleInput → handleInputEvent → sendEvent → 列表 handleEvent →
   InputContainer:onGesture（ges_events 派发）→ Menu:onSwipe（menu.lua:1486）
   → self:onClose()（1496）→ onCloseAllMenus → UIManager:close`。
  也就是说，**列表当时就是顶层窗口，收到了一条真正的 `Swipe` 事件** ——
  v0.6.12 的「手势泄漏给下层」说法到此彻底证伪。
- 🔍 **逐行核对 KOReader 源码，排除了「同一划被重复派发」**：
  `GestureRange:match`（`ui/gesturerange.lua:21-24`）要求 `gs.ges` 严格相等；
  `UIManager:sendEvent`（`uimanager.lua:901-930`）只把事件交给**派发那一刻**的
  顶层非 toast 窗口；`Contact:handleSwipe`（`gesturedetector.lua:891`，注释
  "Contact is up"）只在**抬手**时发一次 swipe。加上日志时序
  （`顶部下滑` → **阅读器关闭** → 400ms~1s 之后才 `诊断：知识库列表被关闭`），
  结论是：**这是退出阅读器之后飘来的第二个独立 south swipe**，物理上用户只
  划了一次 —— 它是「顶部下滑退出」这个动作的余波。
- 🟢 **修复：手势免打扰窗（1.6s）。** 顶部下滑退出阅读器时开窗，窗内
  ① 列表实例的 `onSwipe` 把 south 吞掉（不关列表）；
  ② `noteMenuClosed` 直接忽略（余波不能记成用户意图）；
  ③ `reclaim` 也不把 `user_closed` 当回事，照常把列表抬回来。
  窗口一过全部还原，用户之后主动下滑退出列表的手感分毫不变。
  做法与觅阅自己的 `_arm_reader_gesture_guard(0.75)`（`main.lua:16341`）同源。
- 🔍 **窗内附带手势探针**：把每一条送到 `UIManager:sendEvent` 的
  `swipe` / `multiswipe` / `two_finger_swipe` / `pan_release` / `hold*` 记一行
  （类型、方向、距离、落点、当时的顶层控件），并与 `顶部下滑` 那行记下的
  `dist`/`pos` 对照。平时零开销。万一还有残留手势，`crash.log` 里直接见分晓。
- 🔧 版本号 0.6.13 → **0.6.14**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.13**

修的是 v0.6.12 依然存在的老症状 —— 实测反馈：「文档下滑先弹回 IMA 用户登录界面，
再自动跳到 KOReader 的 `cache/ima` 缓存列表，知识库列表始终不出现」（与 v0.6.11
反馈相同）。v0.6.12 的「手势泄漏」理论被证伪：`UIManager:sendEvent` 在派发前就
锁定了 top_widget，同步关阅读器并不会让事件落到列表头上 —— 真凶另有其人。

- 🟢 **真正的根因：`close_callback` 在「选中条目」时也会触发。** KOReader 的
  `Menu:onMenuSelect`（`frontend/ui/widget/menu.lua:1374-1377`）对没有子菜单的
  条目是**先跑条目自己的 callback（= 打开文档）、后调 `close_callback`，但菜单
  并没有关、还留在窗口栈里**。v0.6.11 据此把 close_callback 当「用户主动关闭」
  的信号，于是**每次从列表点开文档都会把 `user_closed` 置位**，毒死整场阅读的
  抬回守护：退出后 `reclaim()` 第一行静默早退（日志里一条抬回记录都没有），
  列表虽自然露出来，随后仍被觅阅补回的 `cache/ima` 文件管理器整个盖住。
- 🟢 **修复①（ima/ui/menu.lua）：close_callback 只在「菜单已不在窗口栈」时才
  通知 `noteMenuClosed`** —— `Menu:onCloseAllMenus` 是先 `UIManager:close(self)`
  摘栈、后回调；`onMenuSelect` 那次菜单还在栈里，天然可区分，零歧义。
- 🟢 **修复②（prepare()）：打开新文档时复位 `user_closed`** —— 只要是 IMA
  发起的阅读，结束就必须抬回列表（双保险）。
- 🟢 **修复③（reclaim / noteMenuClosed）：「收掉外来文件管理器」不再受
  `user_closed` 门控，守护定时器也不再被一刀切作废** —— 用户下滑关掉列表后，
  露出的下一层（kb_list / 首页）不能被觅阅补回的 `cache/ima` 文件管理器盖死；
  但「抬回 / 重新显示列表」依然绝不复活用户刚关掉的界面。
- 🔍 **关闭探针的调用栈从 6 层加深到 12 层**：v0.6.12 日志显示列表刚露出
  ~1 秒后被一个 south swipe 关掉，栈正好在第 6 层被截断，看不到派发者是谁
  （用户补划 / KOReader `Input:waitEvent` 的 timer 延时手势 / 觅阅，均有可能）。
  下次复现即见分晓；修复③保证即使它再发生，下一层也不会被文件管理器劫持。
- ⚪ v0.6.12 引入的 `UIManager:nextTick(Session.returnNow)` 保留：它修的
  「泄漏」虽然不成立，但「不在手势派发中途动窗口栈」本身更稳。
- 🔧 版本号 0.6.12 → **0.6.13**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.12**

修的是 v0.6.11 最后一个「跳」—— 实测反馈：「文档下滑先弹回 IMA 用户登录界面，
再自动跳到 KOReader 的 `cache/ima` 缓存列表，知识库列表始终不出现。」

- 🟢 **顶部下滑不再把手势泄漏给列表。** 根因是手势派发顺序：一个下滑手势是一个
  `Event:new("Gesture", ges)`，经 `UIManager:sendEvent` 交给 top_widget（阅读器）。
  而 `onSwipeShowMenu` 在 `ReaderUI:onGesture` 的 zone 匹配里被调用；旧代码在这里
  **同步** `returnNow` → `ReaderUI:onClose` → `UIManager:close`，阅读器在
  `handleEvent` 返回 `true` 之前就被移出窗口栈，同一个 Gesture 事件继续往下走，
  落在刚露出来的知识库列表上。列表的 `Menu:onSwipe`（`menu.lua:1486`，
  south → onClose）把这划泄漏的下滑当成「返回上一层」关掉列表，v0.6.11 新增的
  `close_callback → noteMenuClosed` 又把它误判成「用户主动关」—— 于是列表
  再也不被救回。真机日志铁证：`顶部下滑：返回知识库列表` 与
  `诊断：知识库列表被关闭，调用栈 = … Menu:onSwipe → onClose → onCloseAllMenus`
  **同秒**出现。
  *（v0.6.13 勘误：此理论与 `sendEvent` 实现不符 —— 派发前已锁定 top_widget，
  事件不会「继续往下走」。该版真正的修复见 v0.6.13 的根因分析。）*
- 🟢 **修法：把关闭阅读器延后到下一 UI tick**（`UIManager:nextTick(Session.returnNow)`）。
  nextTick 的任务在下一轮 `_checkTasks` 才执行，必然晚于当前手势被 sendEvent
  消费之后 —— 手势不再泄漏，列表不会被误关，`noteMenuClosed` 也就只会在用户
  **真正**主动关列表时触发（语义恢复正确）。
- 🟢 菜单按钮「← 返回 IMA 知识库」保持同步不动：它走的是 tap +
  `Menu:onMenuChoice`，本身就会消费手势并关闭菜单，没有泄漏路径。
- 🔧 版本号 0.6.11 → **0.6.12**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.11**

修的是 v0.6.10 的两个「跳」—— 实测反馈：「文档下滑退出会返回知识库界面 → 自动跳到
`cache/ima` 缓存页 → 自动跳回知识库列表；若此时再次下滑，又是返回知识库界面后
自动跳回知识库列表。」

- 🟢 **用户自己关掉的列表不再被复活。**
  第二个「跳」的直接原因：用户在列表上下滑（`Menu:onSwipe → onClose`）把界面关掉后，
  守护定时器那一拍发现「列表不在窗口栈里」，就把它 `UIManager:show` 了回来。
  现在 `Imenu.show` **总是**装上 `close_callback` —— KOReader 的 `Menu:onCloseAllMenus`
  （`ui/widget/menu.lua:1471`）是**先** `UIManager:close(self)`、**后**调它的，
  所以这一手能把两种成因干净地分开：

  | 成因 | 走 `close_callback`？ | 处理 |
  | --- | --- | --- |
  | 用户下滑 / 点关闭 | **走** | `noteMenuClosed()`：停守护、推进令牌、作废在途定时器 |
  | 觅阅清场把窗口栈里的它关掉 | 不走 | 这才是 reclaim 该救的（重新显示） |

  调用方自己的 `opts.on_close` 仍然链在后面，不受影响。
- 🟢 **校正窗口加密到 10 拍**（0.8 / 1.6 / 2.4 / 2.9 / 3.4 / 4.0 / 4.8 / 5.8 / 7.0 / 8.5s）。
  第一个「跳」的成因就在拍点太稀：觅阅要 +2.55s 才确认「阅读器真的关闭了」
  （`wait_ms= 2552`）、+3.0s 才 `FileManager base created`，而旧序列里
  负责收它的是 5.0s 那一拍 —— 文件管理器在屏幕上停了近 3 秒
  （真机日志：`20:30:04 创建 → 20:30:07 收掉`）。加密后最坏暴露 < 0.5 秒。
- 🔧 **装了「关闭探针」（诊断）**：KOReader 的 `UIManager:close` 只用 `logger.dbg`
  记一行（`uimanager.lua:237`），而设备日志是 INFO 级 —— 「列表到底被谁关掉的」
  在 v0.6.10 的完整日志里一条证据都没有，只能推断。现在该方法的包装会在
  「被关掉的正是本列表」时用 warn 级补一条带调用栈的日志
  （`[ima] 诊断：知识库列表被关闭，调用栈 = ...`），其余一切原样透传。
- 🔧 已确认**与插件生命周期无关**：本插件 `main.lua` 没有任何
  `onCloseWidget` / `onPluginFinalized`，所以日志里那串
  `[Customisable Sleep Screen] v2.4.7 initialised` / `[MiuRead][Startup] begin`
  （觅阅重建 FileManager 时 KOReader 会重跑 `PluginLoader`）不会关掉列表。
- 🔧 `reclaim` 里「列表已在顶层」与「校正窗口已过」两条降到 `logger.dbg` ——
  拍点加密后它们会非常频繁，会淹没真正有用的那几条。
- 🔧 版本号 0.6.10 → **0.6.11**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.10**

修的是 v0.6.9 漏掉的那一半 —— 实测反馈：「打开文档下滑**直接**返回到
`cache/ima` 的文件列表」。

- 🟢 **退出后一定停在知识库列表，不会被觅阅的文件管理器顶掉。**
  根因：v0.6.9 让退出不再调 `showFileManager`，但**觅阅自己会把这个文件管理器
  建出来**。它把 KOReader 的文件管理器当桌面模式的「底座」，阅读器一关就调
  `Plugin:_ensure_filemanager_base`（miuread `main.lua:17572`）；当
  `FileManager.instance` 不存在时走**创建分支**，用 `HOME_RETURN_FILE`（刚读过
  的那本书）反推目录 —— 正是 `cache/ima` —— 然后
  `FileManager:showFiles(dir, target)` → `UIManager:show(file_manager)`
  （`frontend/apps/filemanager/filemanager.lua:1311-1330`），按插入规则落在
  知识库列表**上面**。
  - 为什么 v0.6.8 反而没事：那版退出走 `onHome`、KOReader 抢先建过 FileManager，
    觅阅随后走的是 `conceal_under_home` 分支，只把**它自己的首页** raise 上来，
    我们的 reclaim 再把列表盖上去就赢了。v0.6.9 一「省」，觅阅就改走了创建分支。
  - 真机日志的证据：`[MiuRead][Home] FileManager base ready` +
    `[MiuRead][ReaderClosePerf] FileManager base created show_ms= 242`，
    紧跟 `[MiuRead][Navigation] native -> home ... reason= home plugin initialized`。
- 🟢 **`Session.reclaim` 现在认三种覆盖层**，`is_foreign_overlay` 收窄到只剩
  `modal`：
  | 顶层 | 处理 |
  | --- | --- |
  | KOReader 文件管理器（`FileManager.instance`） | 收掉（`UIManager:close`） |
  | 觅阅的 `_miuread_transient` / `_miuread_modal_surface` | **越过**，照常抬列表 |
  | 真的 `modal` 对话框 | 让位 |
  第二条是关键修正：v0.6.9 正是被这两个标记挡住的 —— 而它们出现的时机恰好就是
  要把列表抬回顶层的时机，认它们等于永远抬不动。
- 🟢 **列表被整个移出窗口栈时改为重新显示**（`UIManager:show(menu)`），
  而不是静默放弃（觅阅桌面模式接管会清场）。
- 🔧 **校正窗口 3 拍 → 4 拍**（1.8 / 3.2 / 5.0 / 7.5s）：觅阅补回底座比它自己
  恢复首页更晚（实测退出后 2.4s 才确认关闭、~3.0s 才建 FileManager）。
- 🔧 **`scheduleReclaim` 加令牌**：`onCloseWidget` 与 `closeReader` 都会排定时器，
  两组交错会把 `state.step` 往前推 —— 吃掉 3.2s 那一拍、让窗口在 5.0s 就收口，
  正好落在觅阅建底座之后。带上令牌后只有最后排的那一组有效。
- 🔧 **reclaim 的每个早退点都写日志**（含窗口栈快照，跳过 toast）。这个方法以前
  全程静默，出问题时只能靠推测 —— 这条路整整查了两轮才定位。
- 🔧 版本号 0.6.9 → **0.6.10**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.9**

修的是 v0.6.8 引入的退出观感问题 —— 准确说，是 v0.6.8 让「退出」这条一直存在
的路径暴露在了下滑手势上。

- 🟢 **退出阅读器不再闪出 KOReader 的文件列表**。
  现象（实测反馈）：打开知识库文档后下滑，会**先闪一下 KOReader 的界面**
  再出现知识库列表；之后在别的文档上再下滑，就直接退到
  **KOReader 的 `cache/ima` 文件列表**了。
  根因（设备源码 + 真机日志）：退出走的是 `ReaderUI:onHome()`
  （`readerui.lua:929`）：
  ```lua
  function ReaderUI:onHome()
      local file = self.document.file
      self:onClose()
      self:showFileManager(file)   -- ← 问题在这一行
      return true
  end
  ```
  `showFileManager(file)` 会 `changeToPath(文档所在目录)`，而本插件的文档都在
  `cache/ima/` 下 —— 于是 KOReader 新建一个 FileManager 并切到缓存目录。
  日志里的证据：退出那一刻重跑了 `[MiuRead][Startup] begin`、
  `[Customisable Sleep Screen] initialised` 一整串（`PluginLoader:finalize()`
  刚在 `onClose` 里销毁过插件实例，所以这是 FileManager/插件被重新初始化）。
  又因为 `UIManager:show` 的插入规则是「插在**最上面那个非模态窗口**之上」
  （`uimanager.lua:185-198`），这个 FileManager 被 push 到**知识库列表上面**：
  - 列表要等 1.8s 后的 reclaim 才盖回来 → 中间那一眼就是「闪现」；
  - FileManager 从此留在窗口栈里 → 在知识库列表上再下滑
    （KOReader 自带的 `Menu:onSwipe` → `onClose()`）露出的就是 `cache/ima`
    的文件列表，而不是本该露出的觅阅首页。
  修法（`Session.closeReader` + `Session.installExitRouting`）：退出**只调
  `ReaderUI:onClose()`**，不调 `showFileManager`。落盘、阅读进度、
  `CloseDocument` 事件都在 `onClose` 里，与 `onHome` 的前半段完全一致，
  差别只有「要不要顺手把 FileManager 拉出来」；不拉的时候，阅读器关掉后露出的
  就是本来就压在下面的窗口 = 知识库列表本身。另外把 `readerui.onHome` 也改道到
  同一条路上（KOReader 里 `ReaderBack` 在文档开头再返回一次会发
  `Event:new("Home")`，`readerback.lua:173`），只在本次阅读由 IMA 发起时生效。
  - 时序上还占了个便宜：`UIManager:close` 是**同步**跑
    `handleEvent("CloseWidget")` 的，所以 `onClose` 一返回就可以**立刻**抬一次
    列表，不必等第一拍定时（原来那 1.8s 的空档正是"闪现"的时长）。
  - 改道时用**捕获下来的原生 `onHome`** 兜底，不写 `self.onHome` ——
    否则 `onClose` 一旦失败就是无限递归。全程 `pcall` + 幂等标记。
  - 这是与「顶部下滑返回列表」**相互独立**的一处：就算把下滑开关关掉，
    退出路径依然是"不拉 FileManager"的。
- 🔧 版本号 0.6.8 → **0.6.9**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.8**

修的是「同一个手势，两个界面里含义相反」。

- 🟢 **阅读界面顶部下滑 = 返回知识库列表**。
  现象（实测反馈）：在知识库列表里下滑是**返回上一层**（最后一层退回觅阅首页），
  手感很顺；但进到 PDF 阅读界面后，从顶部往下滑弹出的却是 **KOReader 的设置
  界面**，两处不一致。
  取证（都在设备源码里可复核）：
  - 列表侧的下滑来自 KOReader 自带的 `Menu:onSwipe`
    （`ui/widget/menu.lua:1492-1497`）：`south → self:onClose()`；
  - 阅读器侧的下滑来自 `defaults.lua:59`
    `DTAP_ZONE_MENU = {x = 0, y = 0, w = 1, h = 1/8}` —— 屏幕**顶部 12.5%
    满宽条带**，由 `readermenu.lua:98-174` 用 `registerTouchZones` 注册成
    `readermenu_swipe`（`overrides = {"rolling_swipe","paging_swipe"}`，
    并连带同区的两个 `pan`），全部指向
    `ReaderMenu:onSwipeShowMenu`（`readermenu.lua:478`）—— 它只要
    `ges.direction == "south"` 就 `onShowMenu()`。
  做法：把 **ReaderMenu 实例**上的 `onSwipeShowMenu` 包一层 —— `south` 且
  本次阅读由 IMA 发起时改走 `Session.returnNow()`，**与阅读器菜单里的
  「← 返回 IMA 知识库」完全同一条退出路径**（所以阅读进度、文档设置照常
  落盘，退出后的「抬回列表 + 给觅阅首页解冻」也复用现成的 reclaim 链）；
  其它方向原样交回 KOReader。
  - **顶部「点按」不受影响**：`tap` 与 `swipe` 是两组独立 zone
    （`readermenu_tap` → `onTapShowMenu`），所以阅读器菜单照样打得开。
  - 顺序上一个坑：原文是在 `onShowMenu()` **之后**才发
    `Event:new("HandledAsSwipe")`（取消原生滚动/翻页）；我们要退出阅读器，
    必须**先发**再退出，否则 `self.ui` 已是拆掉后的残骸。
  - 为什么包实例方法、而不是重新 `registerTouchZones`：原 zone 的 handler 是
    闭包（`self:onSwipeShowMenu(ges)`，方法名调用时才解析），实例赋值能活过
    `ReaderMenu:onSetDimensions`（旋屏 / ReaderReady 会再注册一遍 zone）；
    自己去注册同名 zone 则会被下一次 `initGesListener` 覆盖掉。详见
    「实现要点」第 8 条。
  - 全程 `pcall` + 类型检查 + 幂等标记：没有 `menu`、`onSwipeShowMenu`
    被改名、退出路径抛错 → 都不会崩（最坏是「下滑没反应」）。
    另外只在 `state.active` 为真时接管，**普通书籍的下滑行为一点没变**。
  - 新增开关「设置与凭证 → 阅读界面顶部下滑 = 返回列表」（`pdf_swipe_back`，
    **默认开**）；关掉即恢复 KOReader 原生行为。
  - 首次打开的提示文案也跟着更新（现在会说明「顶部下滑返回列表、
    点顶部开菜单」）。
- 🔧 版本号 0.6.7 → **0.6.8**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.7**

新增两个「不必先钻进主菜单」的入口，都围绕「怎么最快打开知识库」。

- 🟢 **觅阅首页下拉快捷面板里增加「IMA 知识库」**（新增
  `ima/miuread_bridge.lua`）。
  先说实话：觅阅的下拉面板是**白名单式**的 —— 条目池是它 `main.lua` 里一张
  **硬编码**的 `definitions` 表（Wi-Fi／方向锁定／截图／下载／觅阅设置／
  KO设置／重启…，共 17 项），再由 `home.panel_items[key]==true` 过滤、
  `home.panel_order` 排序，上限 `HOME_PANEL_MAX_VISIBLE = 8`；它**没有**给
  第三方插件留注册接口，也**不读** KOReader 的 Dispatcher。所以做法是
  **包装面板模块的 `show(opts)`**，在最后渲染前把 IMA 条目插进
  `opts.buttons`（`Plugin:show_home_quick_panel()` 组装好 buttons 后正是
  交给它渲染的）：
  - 面板有空位 → **追加在末尾**，用户已勾选项的相对顺序完全不动；
  - 面板已满 8 项 → 插到**最前**。渲染层是 `math.min(8, #buttons)`，
    因此只会挤掉最后一格，其余各项次序不变，入口始终可见；
  - 全程 `pcall` + 类型检查：觅阅没装／模块进不了 `package.path`／接口改名
    → 静默跳过。最坏结果是「入口不出现」，**绝不会崩**；
  - 只在启动完成之后（+4s / +10s / +25s 三次尝试，`_G` 标记保证幂等）
    才 `require` 觅阅的面板模块，不把它的控件树拖进启动路径；
  - 图标直接复用觅阅自带的 `library.svg`（Lucide），不新增任何资源文件；
  - **不改觅阅任何文件、不写觅阅任何设置**，只替换一次函数引用。
- 🟢 **注册 KOReader 的「动作」（Dispatcher）**：`main.lua` 新增
  `onDispatcherRegisterActions()` / `onImaOpenKnowledgeBase()`，动作名
  「IMA 知识库」、`general = true`。注册后可在**手势管理器**、**热键**、
  **Profiles** 里把「打开 IMA 知识库」绑到任意手势或按键。
  > 这条与上面那条是**两套独立机制**：觅阅面板不读 Dispatcher，
  > 所以手势动作**不会**出现在下拉面板里，反之亦然。两个都做，
  > 是为了「下拉一格」和「任意手势」两种习惯都能覆盖。
- 🔧 版本号 0.6.6 → **0.6.7**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。

**v0.6.6**

针对实测反馈「从 ima 返回觅阅首页后页面卡死，任何点击都没反应」修复。

- 🔴 **修复「退回觅阅首页后点不动」**。根因在觅阅那边，链条是：
  打开任何阅读器时觅阅会 `HomeView.park()` 把首页停放在阅读器下面，其中一行是
  `_miu_input_suspended = true`（`home_view.lua:2095`）；而
  `HomeWidget:handleEvent` 的第一行就是
  `if self._miu_input_suspended == true then return true end`
  （`home_view.lua:836`）—— **把一切输入原样吞掉**。
  唯一能解除它的是 `HomeView.unpark()`，而觅阅**只在自己那两条「恢复首页」的
  路径里**调用它（`_complete_reader_close` `main.lua:17108`、
  `_restore_home_after_reader_close` `main.lua:17685`）。
  本插件从 v0.6.1 起为了「能单独退出阅读器」把觅阅的返回流程整条绕过了，于是这
  两次 unpark 都不会发生；首页带着「吞输入」标志留在窗口栈里，等觅阅自己的手势桥
  把它 `raise` 到顶层，就成了一个**看得见、点不动的首页** —— 就是用户看到的卡死。
  日志上可直接对照：正常从觅阅开书退出会有
  `[ReaderClose] state home_surface_ready restoring parked MiuRead home`，
  IMA 这条路没有，取而代之的是 `home -> native reason= foreground native`。
- 🟢 **修法：调用觅阅自己的公开 API `HomeView.unpark()`**，而不是去包装它的
  `HomeWidget:handleEvent` 强行放行输入。后者是窄修补，会造成「输入放行了、但
  列表 raise 被 `is_foreign_overlay` 挡住」的双输局；而 `unpark()` 会顺带恢复
  觅阅自己的 `_register_top_swipe`，且**不动窗口顺序**，所以既保住列表在顶层，
  也不会被「home 挡住了」的判定误伤。仍然坚持「不改觅阅文件、不写觅阅设置」，
  只做一次内存里的 API 调用。
  - **时机**：退出后的 reclaim 三拍（1.8s / 3.2s / 5.0s）每拍都补一次解冻；
    第三拍不再指望抬列表，纯粹是「再确认一次解冻」的兜底（觅阅的过渡在 +2s
    之后才收尾）。
  - **幂等且安全**：阅读器还开着 / `is_parked()` 为假 / 觅阅没装 /
    `miuread.home_view` 还没被 require / 接口改名 —— 全部安全跳过，整段包在
    `pcall` 里。
  - **兜底**：`Session.abort()`（打开失败这条路不走 `watchClose`）也补一次延迟
    2.0s 的解冻，避免失败后首页一直卡在 park 状态。
- 🔧 版本号 0.6.4 → **0.6.6**（`_meta.lua` / `ima/constants.lua` /
  `ima/views/settings.lua` / 本 README）。v0.6.5 是已归档的重排实验版、未发布
  （见 `outputs/_archive_ima_v065_reflow_crash/`）。
- 📝 顺带把「不重排怎么把字放大」的调研结论写进上文第 6/7 条
  （横屏正好 1.329×，零风险、无需插件介入）。
  ⚠️ 那句"无需插件介入"到 **v0.6.18** 就不再完整了 —— v0.6.18 加了
  「打开文档自动横屏（退出恢复）」，v0.6.19 起**默认开**，打开 IMA 文档即自动替你转。
  见 v0.6.18 / v0.6.19 章节。

**v0.6.4**

针对实测反馈「让你设置字体字号都很灾难 / 这篇文档里出现很多空格」回退：
**版面回到不插手的状态**（即你记忆中「文档显示都正常」的那一版），
只保留并加固「翻页内容不重复」。

- 🔴 **整档移除「正文重排」及其四个字号参数**（v0.6.2 引入、v0.6.3 调整过）。
  「打开文档时的版面」现在只有四档：**跟随系统默认（默认）** / 适应内容宽度 /
  适应页宽 / 整页显示；设置里不再有任何字号、行距、字间距、页边距。
- 🔴 **查清「满屏空格」的根因，并写进文档**（这样以后不会再重复踩）：
  `kopt_doc_language` 默认是 `"eng"`，而 `KoptInterface:createContext` 只有在
  语言是 `chi_sim`/`chi_tra`/`jpn`/`kor` 时才调 `kc:setCJKChar()`。
  于是 k2pdfopt 把中文当拉丁文排版、按"词"断行，再叠加默认的
  `justification = 3`（full / 两端对齐）—— 中文被拆成一格一格的空隙。
  这不是参数没调好，是**语言判定错**；要修就得再接管一堆排版键，
  所以本版直接不碰重排。
- 🔴 **回退历史版本写进边车的重排残留**。只把档位移出是不够的：
  边车里残留的 `kopt_text_wrap = 1` 会继续生效，文档照样按重排打开。
  现在套用版面时会显式写 `kopt_text_wrap = 0`，并把
  `kopt_font_size` / `kopt_line_spacing` / `kopt_word_spacing` /
  `kopt_page_margin` 以及 `zoom_mode` / `normal_zoom_mode` /
  `kopt_zoom_mode_genus` / `kopt_zoom_mode_type` **一并删掉**。
  后两个是关键：v0.6.2/v0.6.3 写过 `zoom_mode = "page"` 时，ReaderZooming 会
  顺手把 genus/type 改成 `4/2`（page 的组合），只删 `zoom_mode` 的话
  `onReadSettings` 会退回 genus/type 再算一次 —— 依旧是「整页显示」。
- 🟢 **加固「翻页内容不重复」**（这是本版唯一主动改文档设置的地方）：
  ⚠️ 本版是**归零**。v0.6.17 发现归零会让跨越屏底的行被切成两半，先改成
  **恰好一行高**（v0.6.19 又证明固定量不管用、改为**按行网格对齐**，见 v0.6.17 /
  v0.6.19 章节）—— 下面几条的**机制**不变，只是目标值变了。
  - 文档级 `kopt_zoom_overlap_h/v = 0`（治整页视图的 36% 重叠）；
  - 运行时把 `readerui.paging.overlap` 归零（治连续视图的固定 30px 重叠，
    它不是文档设置项，写盘写不进去）；
  - 追加在 `ReaderPaging:onViewRecalculate` 上**再钉一道** —— 旋屏、在「排版」
    里换模式都会重算布局，一次赋值不敢保证活到最后；
  - 关掉开关时把重叠**归还** KOReader 自己的默认 36（不是 0、也不是类默认 40）。
- 🔧 **修掉一个自己埋的隐患**：`enforceSeededZoom` 以前会拿「跟随系统默认」
  这个档位名去调 `ReaderZooming:setZoomMode("default")`，而
  `ReaderZooming:onSetZoomMode` **不校验取值** —— 会把 `view.zoom_mode`
  真的改成 `"default"` 这个非法模式。现在只对三种真实模式做现场校正。
- 📝 设备上那份被重排污染的边车（碳酸锂 2026Q4 展望）已就地回退，
  原件备份在 `outputs/_backup_polluted_sidecars_v2/`。

> **要更大的字怎么办**：用阅读器菜单里的「排版」面板（`Font Size` 等），
> 那层被觅阅接管的入口本插件已经摘掉了，打得开。
> 想连重排一起开也在这里开 —— 但请预期本库研报会慢、且中文间距不正常。

**v0.6.3**

针对实测反馈「打开很慢 / 字太大 / 内容只占屏幕中间、像丢字 / 字号该按 24 设」修复。

- 🔴 **修复「重排后内容只显示在屏幕中间、四周的字像丢了」**。
  v0.6.2 我在边车里写了 `zoom_mode = "contentwidth"`，那是错的 ——
  **重排模式下 zoom 只能是 `page`**。KOReader 有两处会设 zoom，而且后者会盖掉前者：

  ```lua
  -- ReaderKoptListener:setZoomMode —— 重排时强制 page（唯一合法值）
  if self.document.configurable.text_wrap == 1 then
      self.ui:handleEvent(Event:new("SetZoomMode", "page", "koptlistener"))

  -- ReaderZooming:onReadSettings —— 照着**边车里的 zoom_mode** 再设一次
  local is_reflowed = config:readSetting("kopt_text_wrap") == 1
  self:setZoomMode(zoom_mode, true, is_reflowed)
  ```

  实测日志正是这两条打架：

  ```
  setting zoom mode to page            ← KoptListener（重排要的）
  setting zoom mode to contentwidth    ← ReaderZooming 照边车覆盖（22 秒后）
  ```

  一旦变回 `contentwidth`，重排出来的虚拟页会被按"内容宽度"**再次缩放**，
  于是内容挤在屏幕中间、四周被裁掉。现在改写 `zoom_mode = "page"`
  （`normal_zoom_mode` 仍留 `contentwidth`，那是「关掉重排后回到哪一档」）。
- 🔴 **修复「切回跟随系统默认不生效」**。以前选「跟随系统默认」时**什么都不写**，
  边车里上一次留下的 `kopt_text_wrap = 1` 会继续生效 —— 文档照样按重排打开，
  依旧慢、依旧大字号。现在会显式写 `kopt_text_wrap = 0`，并把
  `zoom_mode` / `normal_zoom_mode` **删掉**（`delSetting`）真正交还给系统默认。
- 🔧 **字号按你给的 24 调**：`kopt_font_size` 1.5 → **1.3**。
  这个键是「**原文字号的倍数**」（不是 pt），研报正文实测 18pt，
  18 × 1.3 ≈ 23.4pt。顺带纠正：1.5 甚至**不是 KOReader 的合法档位**
  （`FONT_SCALE_FACTORS = {…, 1.1, 1.3, 1.6, 2.0}`），面板上会判为非法值。
  设置里现在显示成 `1.3 倍 · ≈23pt`，方便和平时读书的字号对照。
- 📝 **把重排的代价写进档位名**：「正文重排（字号可调，**打开较慢**）」。
  KOReader 重排要处理整页（本库的研报是单页 5548pt 高、含大量矢量图），
  首次打开要几十秒，这是重排的固有代价，插件层消不掉。

> **嫌慢怎么办**：「设置与凭证 → 打开文档时的版面」切到**「跟随系统默认」**。
> 那一档不写任何重排键，打开速度回到平时的水平 —— 代价是 PDF 上就没有字号可调了
> （非重排的 PDF 根本没有字号设置项，`Font Size` / `Line Spacing` / `Word Gap` /
> `Margin` 只在 Reflow 打开时才有）。
> 这是「字大 vs 打开快」的二选一，插件把两档都做成了一键可切，由你定。

**v0.6.2**

针对实测反馈「正文太小」「翻页有内容重复」两项修复。

- 🔴 **修复「翻页时有一部分内容和上一页重复，不同文档重复量还不一样」**。
  根因是**固定像素**的页间重叠，而且有两个来源，都归零了：
  - **连续视图**（本机 `kopt_page_scroll = 1`）→ 走
    `ReaderPaging:onScrollPageRel`，重叠量取 `ReaderPaging.overlap`，
    它在 `init` 时被赋成 `Screen:scaleBySize(DOVERLAPPIXELS)`（默认 **30**）。
    于是每一屏只前进「屏高 − 30px」，那 30px 就是重复的那一条。
    而且是**固定像素** —— 高字号文档里只盖一两行、低字号文档里能盖三四行，
    这正是「不同文档重复量不一致」的来源。
  - **整页视图**（`kopt_page_scroll = 0`）→ 重叠量是百分比
    `1 − zoom_overlap_v/100`，边车里是 **36%**。

  现在两处都置 0：文档级写 `kopt_zoom_overlap_h/v = 0`，
  运行时再把 `readerui.paging.overlap` / `readerui.zooming.zoom_overlap_*` 归零。
  两处都要，因为：`paging.overlap` 压根不是文档设置项（写盘写不进去），
  而历史文档早就带着边车了、不会再走写盘那一步。
  可在「设置与凭证 → 翻页内容连续（不重叠）」里关掉。
  ⚠️ **v0.6.17：归零是矫枉过正** —— 它会让跨越屏底的那一行被切成两半。先改成
  「恰好一行高」，v0.6.19 又改为「按行网格对齐」，开关也改名为
  「翻页不切断文字（自动对齐整行）」。见 v0.6.17 / v0.6.19 章节。

- 🔴 **正文太小 → 默认档位改为「正文重排」**。
  先纠正一个早期误判：知识库里的研报**不是**公众号长图截图，而是
  **浏览器打印**出来的 PDF（实测 `Producer = "Skia/PDF m154"`、
  `Creator = "Mozilla/5.0 (Windows NT 10.0)"`）：纯文字 + 矢量图表，
  位图对象 0 个，**有 ToUnicode 映射**（重排不会乱码）。
  正文实测 **18pt**、页面宽 **598pt**，按内容宽铺满后落到 1264px 屏上只有
  **9.1pt（约 3.2mm）** 高 —— 能看，但吃力。
  而**非重排模式下 PDF 根本没有字号可调**：`Font Size` / `Line Spacing` /
  `Word Gap` / `Margin` 这四项只在 Reflow 打开时才有
  （见 `frontend/ui/data/koptoptions.lua`）。
  所以默认档位改为**正文重排**：写 `kopt_text_wrap = 1` 并带上四项参数。

- ➕ 「设置与凭证」新增四项可调参数（**字号 / 行距 / 字间距 / 页边距**），
  默认值按「照抄觅阅阅读界面」的思路折过来：

  | 参数 | 默认 | 依据 |
  | --- | --- | --- |
  | 字号 `kopt_font_size` | **1.5** → v0.6.3 改为 **1.3** | 原文字号倍数；原文字号在屏上只有 9.1pt 太小，需要放大 |
  | 行距 `kopt_line_spacing` | **1.4** | 觅阅 `copt_line_spacing = 140`（%）；两边都是倍数，可直接照抄 |
  | 字间距 `kopt_word_spacing` | **-0.2** | 觅阅 `copt_word_spacing = 100%`（正常）；kopt 的 `-0.2` 即「auto」，最接近 |
  | 页边距 `kopt_page_margin` | **0.05** | 觅阅 `copt_h_page_margins = 15px`（≈1.2% 屏宽）；取默认 0.10 的一半，正文更宽又不贴边 |

  > ⚠️ **觅阅的「字体」（仓耳今楷）无法照抄**：PDF 重排走 K2pdfopt，
  > 只有内置字形，不接受自选字体。所以 PDF 上不存在「字体」这一项。
  >
  > 另外要说明：觅阅那套「字体与排版」面板
  > （`miuread/reader_typography_dialog.lua` + `_reader_apply_typography_defaults`）
  > 实际写的是 KOReader 全局的 **CREngine** 键（`cre_font` / `copt_font_size`
  > / `copt_font_base_weight` / `copt_line_spacing`），**只对 EPUB 生效**。
  > CREngine 与 K2pdfopt 是两套单位体系，数值不能直接搬，只能按语义折过来。

- 🔧 版面档位改用**指纹**记录（边车里的 `ima_layout`），而不是「有没有边车文件」：
  档位或参数一变就重新套用（否则用户改了设置没反应），
  只在阅读器里手动调过、没动插件设置的话则原样保留（尊重用户的调整）。

- ⚠️ **重排会重排版面**：研报里的表格与图表是**矢量对象**，
  重排后位置可能变化（文字本身不会丢）。不接受就在
  「设置与凭证 → 打开文档时的版面」里换回**跟随系统默认** ——
  那时一个 zoom 键都不写，跟平时读书完全一致。

> **关于「用觅阅阅读时的文档格式」**：觅阅只是把书交给 KOReader 的
> ReaderUI，它自己**没有任何 PDF 排版设置**（插件源码里 `kopt_` 出现 0 次）。
> 所以「觅阅的 PDF 格式」= KOReader 全局默认；要改 PDF 的正文可读性，
> 只能从 KOReader 这一侧入手，也就是 Reflow。

**v0.6.1**

- 🔴 **修复「文档被压缩到只有一页，内容看不清」**（v0.6.0 引入）。
  v0.6.0 为 PDF 强制写入了「整页显示」，而知识库里的 PDF 是**单页超长**
  的研报（实测 `MediaBox` 598×5548pt，宽高比 **1:9.3**）。
  整页塞进 7 寸屏 = 把宽度压到 1/9 屏，字当然看不清。
  现在**默认一个键都不写**，文档按 KOReader / 系统默认打开 ——
  也就是跟平时在 KOReader、觅阅里打开一本书完全一样。
  > （当时把成因写成「公众号长图导出」，后经内容流分析证实是
  > **浏览器打印**的纯文字 PDF，见 v0.6.2。）
- ➕ 「设置与凭证 → 打开文档时的版面」，四档可循环切换：
  **跟随系统默认（默认）** / 适应内容宽度 / 适应页宽 / 整页显示。
  只有选了后三档才会写入 `zoom_mode` + `normal_zoom_mode`。
- 🔧 顺手修掉一处自己引入的 `_` 遮蔽：新的版面校验代码里写了
  `for _, name in ipairs(...)`，而本模块的 `_` 是 gettext 函数 ——
  这正是 v0.4.0 崩溃的同款写法，已改为字面量查找表。

> **为什么 v0.6.1 的默认必须是「不覆盖」**：知识库里的研报既不能整页显示
> （压得看不清），也没有一种固定缩放对所有人都合适。
> 替用户决定版面的那次尝试（v0.6.0）当场就被实测推翻了。

**v0.6.0**

这一版把「在线阅读」从「能打开」推进到**真正好用**——阅读器交还给 KOReader 原生界面，
并把上一版实测出的四个问题一次修掉。

- 🔴 **修复「物理翻页键失效 / 点屏幕翻页只显示半页」**。
  根因**不在插件**：那其实是觅阅接管阅读器造成的（见下一条）——
  点按/按键都被引到了觅阅的快捷面板，页面自然不动。
  > ⚠️ 这一版同时还做了一件**错事**：为 PDF 强制写入「整页显示」，
  > 结果把长图压得看不清，v0.6.1 已撤销。此处保留记录，避免重蹈覆辙。
  >
  > 顺带记下一个仍然成立的关键点：KOReader 的缩放设置会被读两次 ——
  > `ReaderZooming:onReadSettings` 先按 `zoom_mode` 设一次，紧接着
  > `ReaderKoptListener:onReadSettings` 用 **`normal_zoom_mode`** 再覆盖一次
  > （缺省回落到全局默认）。**只写 `zoom_mode` 会被盖掉，必须同时写
  > `normal_zoom_mode`。** v0.6.1 里用户显式选版面时仍然遵循这条。
- 🔴 **修复「无法更改字体大小」**。根因是觅阅（miuread）在 desktop 模式下
  **接管了整个 ReaderUI**：顶部中部 tap 区 + `ReaderMenu` 的
  `onTapShowMenu / onSwipeShowMenu / onPressMenu / onKeyPressShowMenu`
  全部改接到觅阅快捷面板，原生排版/字体菜单从任何入口都打不开。
  现在打开 IMA 外部文档时会摘除这层接管
  （调用觅阅自己的 `_uninstall_reader_toolbar_hooks`），
  并包装 `_sync_reader_toolbar_hooks`，让它在
  `reader ready` / 旋屏 / `resume into reader` 三处再同步时不再重装。
  **阅读器内部一切回到原生行为**：翻页键、点按翻页、字体、排版、阅读器菜单全部可用。
- 🔴 **修复「无法单独退出返回知识库列表」**。觅阅把 `readerui.onHome` /
  `readerui.showFileManager` 接回了自己的首页（日志 `native bookshelf redirected`），
  所以退出只能回觅阅。现在：
  1. 还原 `_miuread_original_onHome` / `_miuread_original_showFileManager`；
  2. 阅读器菜单里新增一条 **「← 返回 IMA 知识库」**（`sorting_hint = "main"`）；
  3. 关闭阅读器后（1.8s + 3.2s 两次）把已存在的知识库列表重新抬回栈顶，
     因为觅阅停靠首页的恢复耗时实测约 1690ms。
- ➕ 新增 `ima/reader_session.lua`：把「打开前准备 → 打开后接管 → 关闭后抬回」
  收成一个模块级的会话状态机。
  > 为什么必须是模块级状态？KOReader **每开一次阅读器就新建一份插件实例**，
  > 实例字段活不过一次打开；而 `after_open_callback` 又在
  > `ReaderUI.instance` 赋值**之前**调用，所以实例只能靠参数传进去。

**v0.5.0**

- ✨ **点条目在线阅读**。新增 `ima/downloader.lua` 与 `ima/views/reader.lua`：
  `get_media_info` 取临时签名 URL → 流式下载到 `cache/ima/` → `ReaderUI:showReader()`。
  带下载进度提示、缓存命中秒开、失败清理半截文件。
- 🔴 **修复「点文件就崩溃」**（v0.4.0 引入）：
  `kb_browser.lua` 里写了 `for _, entry in ipairs(entries)`，把 gettext 的翻译函数
  `_` 覆盖成了数字下标，循环体内 `_("条目：")` 于是抛出
  `attempt to call upvalue '_' (a number value)`。已修，并把项目里所有
  `for _,` 写法一并改掉。
- 🔧 **修正 `media_type` 映射**。首版按顺序硬猜（`[4]=Excel`、`[5]=PPT`），
  扫全库 678 条实测后确认是 **1=PDF、3=Word、5=Excel、9=图片、99=文件夹**。
  无法确认的取值现在返回 `nil`（界面只是不显示类型后缀），不再瞎猜。
- ➕ 笔记正文读取（`get_doc_content`），落成 `.txt` 交给文本阅读器。
- ➕ 「清理下载缓存」入口。
- ➕ 下载前按扩展名预判格式，不支持的直接告知，不白耗流量。

**v0.4.0**

- 🔴 **修复首屏必挂的 bug**：v0.3.0 把三个接口的 `limit` 统一写成了 50，
  而 `search_knowledge_base`（列库走的就是它）上限只有 **20**。
  服务端返回 HTTP 200 + `code=51`，插件把它当成失败，
  于是打开插件直接弹「请求失败」。设备实测确认。
- 各接口改为按自己的上限传参（`constants.lua` 的 `LIMIT_*`）。
- 新增 `api.lua` 的 `call_with_autolimit`：服务端若用
  `value must be inside range (0, N]` 拒了请求，自动解析 N 并重放一次。
- 新增失败日志：`http.lua` 在请求失败时记录 URL / HTTP 码 / 错误文案 /
  响应片段（凭证不外泄），可直接从 `crash.log` 定位。
- ⚠️ 此版本引入了下面 v0.5.0 修掉的那个 `_` 遮蔽崩溃。

**v0.3.0**

- 移除臆测的 `get_knowledge_base_list`（实测 404），改用
  `search_knowledge_base` 传空 `query` 列库。
- 加入游标分页；错误信息在 HTTP 非 2xx 时也能读出 body。

**v0.2.0** —— 菜单改为单一 callback 条目，一级点击直进列表。

**v0.1.0** —— 骨架首版。

---

## 许可与声明

非官方社区项目，与腾讯、ima、KOReader 官方无隶属关系。
所有产品名称与商标归各自所有者。
